<?php 
	$key_api='7t78b78jbjy8778ygjhjhhkgu';
 ?>