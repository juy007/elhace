<table border="1">
    <tr>
      <th>Judul</th>
      <th>Deskripsi</th>
      <th>URL SLUG</th>
    </tr>
    <?php
    foreach ($dat->news as $kontak){
    ?><tr>
              <td><?php echo $kontak->news_title; ?></td>
              <td><?php echo $kontak->meta_description; ?></td>
              <td><?php echo $kontak->url_slug; ?></td>
      </tr>
    <?php
    }
    ?>
</table>