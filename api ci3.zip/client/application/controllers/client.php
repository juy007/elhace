<?php 
if (!defined('BASEPATH'))exit('No direct script access allowed');

class Client extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->database();
      $this->load->library('upload');
      $this->load->library('encryption');
      $this->load->helper('security');
      $this->load->helper('url');
      $this->load->library('curl');
      $this->load->library('session');
      $this->load->model('M_admin');
      $this->load->helper(array('url','form'));

      /*cache control*/
      $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
      $this->output->set_header('Pragma: no-cache');

       date_default_timezone_set('Asia/Jakarta');
   }
//BERANDA START====================================================================
   function index()
   {  
      $data['dat'] = json_decode($this->curl->simple_get('http://localhost/elhace/back/api/news/7t78b78jbjy8778ygjhjhhkgu'));
      $this->load->view('client',$data);

   }  
}


?>