<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cron extends CI_Controller {
	function __construct()
	{
		parent::__construct();
		$this->load->database();
        $this->load->library('upload');
        $this->load->library('encryption');
        $this->load->helper('security');
        $this->load->helper('url');
        $this->load->library('session');
        $this->load->model('Website');
        $this->load->model('M_user');
        $this->load->helper(array('url','form'));
    }
	function index()
	{
		//redirect(base_url().'home');
		 $this->load->view('frontend/maintenance');
	}
	function pembayaran_produk()
	{
		/*$this->db->select('*');
        $this->db->from('order_invoice');
        $this->db->join('order','order_invoice.id_invoice = order.id_invoice');
        $this->db->where('status_pembayaran', 'menunggu_verifikasi');
        $cek = $this->db->get()->result_array();*/

        $pembelian =$this->db->get_where('order_invoice', array('status_pembayaran'=>'menunggu_pembayaran'))->result_array();

        foreach ($pembelian as $key => $value) { 
			$rentang = strtotime(date("Y-m-d")) - strtotime($value['input_invoice']);
			$hari = $rentang / 60 / 60 / 24;
			if ($hari > 7) {
				
		        $this->db->where('id' , $value['id']);
		        $this->db->update('order_invoice' , array('status_pembayaran'=>'batal'));

		        $this->db->where('id_invoice' , $value['id_invoice']);
		        $this->db->update('order' , array('status_order'=>'batal','tanggal_selesai' => date("Y-m-d"),'jam_selesai' => date("H:i:s")));
			}
			
        }
	}
	function pembayaran_teknisi()
	{
		$penawaran =$this->db->get_where('pemasang_penawaran', array('status_penawaran'=>'menunggu_pembayaran'))->result_array();

        foreach ($penawaran as $key => $value) { 
			$rentang = strtotime(date("Y-m-d")) - strtotime($value['input_penawaran']);
			$hari = $rentang / 60 / 60 / 24;
			if ($hari > 7) {
				
		        $this->db->where('id_penawaran' , $value['id_penawaran']);
		        $this->db->update('pemasang_penawaran' , array('status_penawaran'=>'batal'));
			}
			
        }
	}
	function pembayaran_lelang()
	{
        $lelang =$this->db->get_where('bidding_take', array('status_bidding_take'=>'menunggu_pembayaran'))->result_array();

        foreach ($lelang as $key => $value) { 
			$rentang = strtotime(date("Y-m-d")) - strtotime($value['terpilih']);
			$hari = $rentang / 60 / 60 / 24;
			if ($hari > 7) {
				
		        $this->db->where('id_bidding_take' , $value['id_bidding_take']);
		        $this->db->update('bidding_take' , array('status_bidding_take'=>'batal'));

		        $this->db->where('id_bidding' , $value['id_bidding']);
		        $this->db->update('bidding' , array('status_bidding'=>'batal','tanggal_selesai'=>date('Y-m-d')));
			}
			
        }
	}

	function pembayaran_iklan()
	{
        $iklan =$this->db->get_where('iklan', array('status_iklan'=>'menunggu_pembayaran'))->result_array();

        foreach ($iklan as $key => $value) { 
			$rentang = strtotime(date("Y-m-d")) - strtotime($value['input_iklan']);
			$hari = $rentang / 60 / 60 / 24;
			if ($hari > 7) {
		        $this->db->where('id_iklan' , $value['id_iklan']);
		        $this->db->update('iklan' , array('status_iklan'=>'batal'));
			}
			
        }
	}

}

/* End of file Setadmin.php */
/* Location: ./application/controllers/Setadmin.php */