<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Perusahaan extends CI_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->database();
        $this->load->library('upload');
        $this->load->library('encryption');
        $this->load->helper('security');
        $this->load->library('session');
        $this->load->model('Website');
        $this->load->model('M_perusahaan');
        $this->load->helper(array('url','form'));

        /*cache control*/
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
        $this->output->set_header('Pragma: no-cache');

        if ($this->session->userdata('dev')!='success') {
           // redirect(base_url().'maintenance');
        }
        
        if ($this->session->userdata('user_login') != 'TRUE')
            redirect(base_url(), 'refresh');

        $get_id_perusahaan = $this->db->get_where('perusahaan', array('id_user'=>$this->session->userdata('id_user')));
        $value_get_id = $get_id_perusahaan->row();
        $query = $this->db->get_where('perusahaan_medsos', array('id_perusahaan' => $value_get_id->id_perusahaan));
        $query2 = $this->db->get_where('perusahaan_jadwal', array('id_perusahaan' => $value_get_id->id_perusahaan));
        $query3 = $this->db->get_where('perusahaan_portofolio', array('id_perusahaan' => $value_get_id->id_perusahaan));
        if ($query->num_rows() <= 0) {
            redirect(base_url().'user/form_kontak','refresh');
        }elseif ($query2->num_rows() <= 0) {
            redirect(base_url().'user/form_jadwal','refresh');
        }elseif ($query3->num_rows() <= 0) {
            redirect(base_url().'user/form_portofolio','refresh');
        }elseif($value_get_id->pembayaran_cash == 'false' && $value_get_id->pembayaran_kredit=='false'){
            redirect(base_url().'user/form_pembayaran','refresh');
        }
        date_default_timezone_set('Asia/Jakarta');
    }
    //=======================================DASHBOARD ADMIN=================================================
    public function index()
    {
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();
        $data['perusahaan'] = $this->M_perusahaan->perusahaan();

        if ($this->session->userdata('jenis_perusahaan') == 'komersial') {

            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
              $this->load->view('frontend/perusahaan/index');
        }elseif ($this->session->userdata('jenis_perusahaan') =='individu') {
            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header_1', $data);
             $this->load->view('frontend/perusahaan/index_1');
        }
       
        $this->load->view('frontend/perusahaan/footer');
    }
    function ok(){
        $this->load->view('frontend/perusahaan/ok');
    }
    //========================================================================================================
    ////=======================================PRODUK=================================================
    public function produk()
    {
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();

        $data['produk'] = $this->M_perusahaan->tampil_produk();
        
        
        if ($this->session->userdata('jenis_perusahaan') == 'komersial') {
            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        }elseif ($this->session->userdata('jenis_perusahaan') =='individu') {
            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header_1', $data);
        }
        $this->load->view('frontend/perusahaan/produk');
        $this->load->view('frontend/perusahaan/footer');
    }
    //////=======================================DASHBOARD ADMIN=================================================
    public function edit_produk($id_produk)
    {
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();

        $get_produk = $this->db->get_where('perusahaan_produk', array('id_produk'=>$id_produk));
        $data['produk']=  $get_produk->row();
        
        if ($this->session->userdata('jenis_perusahaan') == 'komersial') {

            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        }elseif ($this->session->userdata('jenis_perusahaan') =='individu') {
            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header_1', $data);
        }
        $this->load->view('frontend/perusahaan/produk_form_edit');
        $this->load->view('frontend/perusahaan/footer');
    }
    //========================================================================================================
      ////=======================================DASHBOARD ADMIN=================================================
    function simpan_edit_produk2()//halaman verifikasi OTP
    {
        if (!isset($_POST['nama'])){
            redirect(base_url()."perusahaan/tambah_produk");
        }
        $id = $this->input->post('id');
        $nama = $this->input->post('nama');
        $kategori = $this->input->post('kategori');
        $ukuran_sistem = $this->input->post('ukuran_sistem');
        $deskripsi = $this->input->post('deskripsi');
        $harga = $this->input->post('harga');
        $garansi = $this->input->post('garansi');

        if (!isset($_FILES["foto"]["name"])) {

            $folder = $this->input->post('folder');
            unlink('upload_file/'.$this->session->userdata('folder').'/img/perusahaan/produk/'.$folder.'/coverProduk.png');
            $_FILES["foto"]["name"];

            $config['upload_path'] = './upload_file/'.$this->session->userdata('folder').'/img/perusahaan/produk/'.$folder.'/';
            $config['allowed_types'] = 'jpg|jpeg|png|gif|bmp';
            $config['file_name'] = 'coverProduk.png';
            $this->upload->initialize($config);
            $this->upload->do_upload('foto');
            $data = $this->upload->data();
                //Compress Image
            $config['image_library']='gd2';
            $config['source_image']='./upload_file/'.$this->session->userdata('folder').'/img/perusahaan/produk/'.$folder.'/'.$data['file_name'];
            $config['create_thumb']= FALSE;
            $config['maintain_ratio']= TRUE;
            $config['quality']= '100%';
                //$config['width']= 720;
                //$config['height']= 300;
            $config['new_image']= './upload_file/'.$this->session->userdata('folder').'/img/perusahaan/produk/'.$folder.'/'.$data['file_name'];
            $this->load->library('image_lib', $config);
            $this->image_lib->resize();
                //  echo base_url().'./upload_file/'.$this->session->userdata('folder').'/img/perusahaan/'.$data['file_name'];      
                //______________________________________________________________________________________________
        }    
        if($this->M_perusahaan->simpan_edit_produk($id, $nama, $kategori, $ukuran_sistem, $deskripsi, $harga, $garansi) == TRUE){
            redirect(base_url()."perusahaan/produk");
        }else{
            redirect(base_url()."perusahaan/produk");
        }
    }
    //========================================================================================================
    //////=======================================DASHBOARD ADMIN=================================================
    public function detail_produk($id_produk)
    {
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();

        $get_produk = $this->db->get_where('perusahaan_produk', array('id_produk'=>$id_produk));
        $data['produk']=  $get_produk->row();
        
        if ($this->session->userdata('jenis_perusahaan') == 'komersial') {

            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        }elseif ($this->session->userdata('jenis_perusahaan') =='individu') {
            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header_1', $data);
        }
        $this->load->view('frontend/perusahaan/produk_detail');
        $this->load->view('frontend/perusahaan/footer');
    }
    //========================================================================================================
    ////=======================================DASHBOARD ADMIN=================================================
    public function tambah_produk()
    {
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();

        $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        $this->load->view('frontend/perusahaan/produk_form');
        $this->load->view('frontend/perusahaan/footer');
    }
    //========================================================================================================
    ////=======================================DASHBOARD ADMIN=================================================
    function simpan_produk()//halaman verifikasi OTP
    {
        if (!isset($_POST['nama'])){
            redirect(base_url()."perusahaan/tambah_produk");
        }
        $nama = $this->input->post('nama');
        $kategori = $this->input->post('kategori');
        $ukuran_sistem = $this->input->post('ukuran_sistem');
        $solarpanel = $this->input->post('solarpanel');
        $inverter = $this->input->post('inverter');
        $estimated = $this->input->post('estimated');
        $accessories = $this->input->post('accessories');
        $operation = $this->input->post('operation');
        $pengajuan_pln = $this->input->post('pengajuan_pln');
        $deskripsi = $this->input->post('deskripsi');
        $harga = $this->input->post('harga');
        $garansi = $this->input->post('garansi');

        $folder = substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz123456789'), 0, 7);
        date_default_timezone_set('Asia/Jakarta');
        $new_folder = 'produk_'.$folder.'_'.date("d").''.date("m").''.date("y").''.date("H").''.date("i").''.date("s");
        //mkdir("upload_file/".$this->session->userdata('folder')."/img/perusahaan/produk");
        mkdir("upload_file/".$this->session->userdata('folder')."/img/perusahaan/produk/".$new_folder);
        //chmod("upload_file/".$this->session->userdata('folder')."/img/perusahaan/produk/".$new_folder, 0777, true);
        mkdir("upload_file/".$this->session->userdata('folder')."/img/perusahaan/produk/".$new_folder."/slide");
        //chmod("upload_file/".$this->session->userdata('folder')."/img/perusahaan/produk/".$new_folder."/slide", 0777, true);

        if($this->M_perusahaan->simpan_produk($nama, $kategori, $ukuran_sistem, $deskripsi, $solarpanel, $inverter, $estimated, $accessories, $operation, $pengajuan_pln, $harga, $garansi, $new_folder) == TRUE){

            $_FILES["foto"]["name"];

            $config['upload_path'] = './upload_file/'.$this->session->userdata('folder').'/img/perusahaan/produk/'.$new_folder.'/';
            $config['allowed_types'] = 'jpg|jpeg|png|gif|bmp';
            $config['file_name'] = 'coverProduk.png';
            $this->upload->initialize($config);
            $this->upload->do_upload('foto');
            $data = $this->upload->data();
                //Compress Image
            $config['image_library']='gd2';
            $config['source_image']='./upload_file/'.$this->session->userdata('folder').'/img/perusahaan/produk/'.$new_folder.'/'.$data['file_name'];
            $config['create_thumb']= FALSE;
            $config['maintain_ratio']= TRUE;
            $config['quality']= '100%';
                //$config['width']= 720;
                //$config['height']= 300;
            $config['new_image']= './upload_file/'.$this->session->userdata('folder').'/img/perusahaan/produk/'.$new_folder.'/'.$data['file_name'];
            $this->load->library('image_lib', $config);
            $this->image_lib->resize();
                //  echo base_url().'./upload_file/'.$this->session->userdata('folder').'/img/perusahaan/'.$data['file_name'];      
                //______________________________________________________________________________________________
            $this->session->set_flashdata('notif' , true);
            $this->session->set_flashdata('teks_notif' , "Produk berhasil ditambah");
            redirect(base_url()."perusahaan/tambah_produk");
        }else{
            $this->session->set_flashdata('notif' , false);
            $this->session->set_flashdata('teks_notif' , "Produk gagal ditambah");
            redirect(base_url()."perusahaan/tambah_produk");
        }
    }
    //========================================================================================================
     ////=======================================DASHBOARD ADMIN=================================================
    function simpan_edit_produk()//halaman verifikasi OTP
    {
        if (!isset($_POST['nama'])){
            redirect(base_url()."perusahaan/tambah_produk");
        }
        $id = $this->input->post('id');
        $nama = $this->input->post('nama');
        $kategori = $this->input->post('kategori');
        $ukuran_sistem = $this->input->post('ukuran_sistem');
        $deskripsi = $this->input->post('deskripsi');
        $harga = $this->input->post('harga');
        $garansi = $this->input->post('garansi');

        if($this->M_perusahaan->simpan_edit_produk($id, $nama, $kategori, $ukuran_sistem, $deskripsi, $harga, $garansi) == TRUE){
            redirect(base_url()."perusahaan/detail_produk/".$id);
        }else{
            redirect(base_url()."perusahaan/detail_produk/".$id);
        }
    }
    //========================================================================================================
    //=======================================DASHBOARD ADMIN=================================================
    function simpan_edit_gambar_produk(){

     $id = $this->input->post('id');
     $folder = $this->input->post('folder');
     unlink('upload_file/'.$this->session->userdata('folder').'/img/perusahaan/produk/'.$folder.'/coverProduk.png');
     $_FILES["foto"]["name"];

     $config['upload_path'] = './upload_file/'.$this->session->userdata('folder').'/img/perusahaan/produk/'.$folder.'/';
     $config['allowed_types'] = 'jpg|jpeg|png|gif|bmp';
     $config['file_name'] = 'coverProduk.png';
     $this->upload->initialize($config);
     $this->upload->do_upload('foto');
     $data = $this->upload->data();
                //Compress Image
     $config['image_library']='gd2';
     $config['source_image']='./upload_file/'.$this->session->userdata('folder').'/img/perusahaan/produk/'.$folder.'/'.$data['file_name'];
     $config['create_thumb']= FALSE;
     $config['maintain_ratio']= TRUE;
     $config['quality']= '100%';
                //$config['width']= 720;
                //$config['height']= 300;
     $config['new_image']= './upload_file/'.$this->session->userdata('folder').'/img/perusahaan/produk/'.$folder.'/'.$data['file_name'];
     $this->load->library('image_lib', $config);
     $this->image_lib->resize();
                //  echo base_url().'./upload_file/'.$this->session->userdata('folder').'/img/perusahaan/'.$data['file_name'];      
                //______________________________________________________________________________________________

     redirect(base_url()."perusahaan/detail_produk/".$id);
 }
    //========================================================================================================
     //=======================================DASHBOARD ADMIN=================================================
 function simpan_slide_produk(){

    $id = $this->input->post('id');
    $folder = $this->input->post('folder');
    $_FILES["slide"]["name"];

    $filesCount = count($_FILES['slide']['name']);
    for($i = 0; $i < $filesCount; $i++){
        $new_name_generate = substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz123456789'), 0, 5);
        date_default_timezone_set('Asia/Jakarta');
        $new_name = 'slide_'.$new_name_generate.'_'.date("d").''.date("m").''.date("y").''.date("H").''.date("i").''.date("s");

        $_FILES['file']['name']     = $_FILES['slide']['name'][$i];
        $_FILES['file']['type']     = $_FILES['slide']['type'][$i];
        $_FILES['file']['tmp_name'] = $_FILES['slide']['tmp_name'][$i];
        $_FILES['file']['error']     = $_FILES['slide']['error'][$i];
        $_FILES['file']['size']     = $_FILES['slide']['size'][$i];

            // File upload configuration
        $config['upload_path'] = './upload_file/'.$this->session->userdata('folder').'/img/perusahaan/produk/'.$folder.'/slide/';

        $config['allowed_types'] = 'jpg|jpeg|png|gif|bmp';
        $config['file_name'] = $new_name.'.png';
        $config['create_thumb']= FALSE;
        $config['maintain_ratio']= TRUE;
        $config['quality']= '100%';

        $this->load->library('upload', $config);
        $this->upload->initialize($config);

        if($this->upload->do_upload('file')){
            $fileData = $this->upload->data();
            $uploadData[$i]['file_name'] = $fileData['file_name'];
            $uploadData[$i]['uploaded_on'] = date("Y-m-d H:i:s");

            $data = array(
                'id_produk' => $id,
                'slide' => $fileData['file_name'],
                'input_slide' => date('Y-m-d')
            );
            //  $insert = $this->file->insert($uploadData);
        }
    }

    if(!empty($uploadData)){
            //  $insert = $this->file->insert($uploadData);

        $this->session->set_flashdata('notif' , true);
        $this->session->set_flashdata('teks_notif' , "Slide Berhasil ditambah");
    }

    redirect(base_url()."perusahaan/detail_produk/".$id);
}
    //========================================================================================================
    // //=======================================DASHBOARD ADMIN=================================================
function hapus_slide_produk($id, $folder, $slide){

    unlink('upload_file/'.$this->session->userdata('folder').'/img/perusahaan/produk/'.$folder.'/slide/'.$slide);
    redirect(base_url()."perusahaan/detail_produk/".$id);
}
    //========================================================================================================
    //=======================================DASHBOARD ADMIN=================================================
function hapus_produk($id_produk, $folder)
{   
    $this->db->where('id_produk' , $id_produk);
    $this->db->update('perusahaan_produk' , array('status_hapus' => 'true'));
    if ($this->db->affected_rows() > 0){

        $files =glob('upload_file/'.$this->session->userdata('folder').'/img/perusahaan/produk/'.$folder.'/slide/*');
        foreach ($files as $file) {
            if (is_file($file))
                unlink($file); // hapus file
        }
        rmdir('upload_file/'.$this->session->userdata('folder').'/img/perusahaan/produk/'.$folder.'/slide');

        $this->session->set_flashdata('notif' , true);
        $this->session->set_flashdata('teks_notif' , "Produk berhasil dihapus");
        redirect(base_url()."perusahaan/produk");
    }else{
        $this->session->set_flashdata('notif' , false);
        $this->session->set_flashdata('teks_notif' , "Produk gagal dihapus");
        redirect(base_url()."perusahaan/produk");
    }
}
    //========================================================================================================
    //=======================================DASHBOARD ADMIN=================================================
public function produk_telah_dihapus()
{
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();

        $data['produk'] = $this->M_perusahaan->tampil_produk_dihapus();
        
        if ($this->session->userdata('jenis_perusahaan') == 'komersial') {

            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        }elseif ($this->session->userdata('jenis_perusahaan') =='individu') {
            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header_1', $data);
        }
        $this->load->view('frontend/perusahaan/produk_dihapus');
        $this->load->view('frontend/perusahaan/footer');
    }
    //========================================================================================================
     //=======================================DASHBOARD ADMIN=================================================
    function status_publish($id_produk, $status)
    {   
        if ($status == 'true') {
            $status_publish = 'false';
            $status_notif = 'tidak dipublish';
        }elseif ($status == 'false'){
            $status_publish = 'true';
            $status_notif = 'dipublish';
        }
        $this->db->where('id_produk' , $id_produk);
        $this->db->update('perusahaan_produk' , array('status_publis' => $status_publish));
        if ($this->db->affected_rows() > 0){
            $this->session->set_flashdata('notif' , true);
            $this->session->set_flashdata('teks_notif' , "Produk ".$status_notif);
            redirect(base_url()."perusahaan/detail_produk/".$id_produk);
        }else{
            $this->session->set_flashdata('notif' , false);
            redirect(base_url()."perusahaan/detail_produk/".$id_produk);
            $this->session->set_flashdata('teks_notif' , "Gagal merubah status publish");
        }
    }
    //========================================================================================================
    //=======================================PEMASANG=================================================
    public function pemasang()
    {
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();

        $data['pemasang'] = $this->M_perusahaan->tampil_pemasang();
        
        
        if ($this->session->userdata('jenis_perusahaan') == 'komersial') {

            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        }elseif ($this->session->userdata('jenis_perusahaan') =='individu') {
            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header_1', $data);
        }
        $this->load->view('frontend/perusahaan/pemasang');
        $this->load->view('frontend/perusahaan/footer');
    }
    //========================================================================================================
     //=======================================PEMASANG=================================================
    public function detail_pemasang($id_pemasang)
    {
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();

        $get_pemasang = $this->db->get_where('perusahaan_pemasang', array('id_pemasang'=>$id_pemasang));
        $data['pemasang']=  $get_pemasang->row();
        $get = $get_pemasang->row();
        $get_send = $get->id_pemasang;
        $data['provinsi'] = $this->M_perusahaan->tampil_provinsi();

        $data['portofolio'] = $this->M_perusahaan->tampil_portofolio_pemasang($get_send);
        $data['sertifikat'] = $this->M_perusahaan->tampil_sertifikat_pemasang($get_send);
        $data['keahlian'] = $this->M_perusahaan->tampil_keahlian_pemasang($id_pemasang);
        $data['area'] = $this->M_perusahaan->tampil_area_pemasang($id_pemasang);

        
        
        if ($this->session->userdata('jenis_perusahaan') == 'komersial') {

            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        }elseif ($this->session->userdata('jenis_perusahaan') =='individu') {
            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header_1', $data);
        }
        $this->load->view('frontend/perusahaan/pemasang_detail');
        $this->load->view('frontend/perusahaan/footer');
    }
    //========================================================================================================
    //=======================================DASHBOARD ADMIN=================================================
    public function tambah_pemasang()
    {
        $data['provinsi'] = $this->M_perusahaan->tampil_provinsi();
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();
        $cek_pemasang = $this->db->get_where('perusahaan_pemasang', array('id_perusahaan'=> $this->session->userdata('id_perusahaan'),'status_hapus_pemasang' => 'false'))->result();

        if ($this->session->userdata('jenis_perusahaan') == 'komersial') {

            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        }elseif ($this->session->userdata('jenis_perusahaan') =='individu') {
            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header_1', $data);
        }
    if ($this->session->userdata('jenis_perusahaan') == 'individu' && count($cek_pemasang) > 0) {
        $this->load->view('frontend/perusahaan/pemasang_form_stop');
    }else{
        $this->load->view('frontend/perusahaan/pemasang_form');
    }

    $this->load->view('frontend/perusahaan/footer');
}
public function edit_pemasang($id_pemasang)
{
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();

        $get_pemasang = $this->db->get_where('perusahaan_pemasang', array('id_pemasang'=>$id_pemasang));
        $data['pemasang']=  $get_pemasang->row();
        $data['provinsi'] = $this->M_perusahaan->tampil_provinsi();
        
        if ($this->session->userdata('jenis_perusahaan') == 'komersial') {

            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        }elseif ($this->session->userdata('jenis_perusahaan') =='individu') {
            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header_1', $data);
        }
        $this->load->view('frontend/perusahaan/pemasang_form_edit');
        $this->load->view('frontend/perusahaan/footer');
    }
    function ambil_data_kota()
    {
        $provinsi=$this->input->post('provinsi');
        $data=$this->M_perusahaan->tampil_cari_kota($provinsi)->result();
        echo json_encode($data);
    }
    function ambil_data_kecamatan()
    {
        $kabupaten=str_replace("_", " ", $this->input->post('kabupaten'));
        $data=$this->M_perusahaan->tampil_cari_kecamatan($kabupaten)->result();
        echo json_encode($data);
    }
    function ambil_data_kelurahan()
    {
        $kecamatan=str_replace("_", " ", $this->input->post('kecamatan'));
        $data=$this->M_perusahaan->tampil_cari_kelurahan($kecamatan)->result();
        echo json_encode($data);
    }
    function ambil_data_pos()
    {
        $kelurahan=str_replace("_", " ", $this->input->post('kelurahan'));
        $kecamatan=str_replace("_", " ", $this->input->post('kecamatan'));
        $kabupaten=str_replace("_", " ", $this->input->post('kabupaten'));
        $provinsi=str_replace("_", " ",$this->input->post('provinsi'));
        $data=$this->M_perusahaan->tampil_cari_kodepos($kelurahan, $kecamatan, $kabupaten, $provinsi)->row();
        echo json_encode($data);
    }
    //========================================================================================================
    function simpan_pemasang()
    {
        $get_id_perusahaan = $this->db->get_where('perusahaan', array('id_user'=>$this->session->userdata('id_user')));
        $value_get_id = $get_id_perusahaan->row();


    //    if (isset($_POST['nama_pemasang'])){
        $nama_pemasang = $this->input->post('nama_pemasang');
        $tanggal_lahir = $this->input->post('tanggal_lahir');
        $jenis_kelamin = $this->input->post('jenis_kelamin');
        $alamat = $this->input->post('alamat');
        $kelurahan =  str_replace("_", " ", $this->input->post('kelurahan'));
        $kecamatan =  str_replace("_", " ", $this->input->post('kecamatan'));
        $kabupaten =  str_replace("_", " ", $this->input->post('kabupaten'));
        $provinsi =  str_replace("_", " ", $this->input->post('provinsi'));
        $kodepos = $this->input->post('kodepos');
        $keahlian = $this->input->post('keahlian');
        $harga = $this->input->post('harga');
        $telepon = $this->input->post('telepon');
        $area = $this->input->post('areaOperasi',TRUE);

        $folder = substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz123456789'), 0, 5);
        date_default_timezone_set('Asia/Jakarta');
        $new_folder = 'pemasang_'.$folder.'_'.date("d").''.date("m").''.date("y").''.date("H").''.date("i").''.date("s");

            //mkdir("upload_file/".$this->session->userdata('folder')."/img/perusahaan/produk");
        mkdir("upload_file/".$this->session->userdata('folder')."/img/perusahaan/pemasang/".$new_folder);
            //chmod("upload_file/".$this->session->userdata('folder')."/img/perusahaan/pemasang/".$new_folder, 0777, true);
        mkdir("upload_file/".$this->session->userdata('folder')."/img/perusahaan/pemasang/".$new_folder."/slide");
            //chmod("upload_file/".$this->session->userdata('folder')."/img/perusahaan/pemasang/".$new_folder."/slide", 0777, true);
        mkdir("upload_file/".$this->session->userdata('folder')."/img/perusahaan/pemasang/".$new_folder."/portofolio");
            //chmod("upload_file/".$this->session->userdata('folder')."/img/perusahaan/pemasang/".$new_folder."/portofolio", 0777, true);
        mkdir("upload_file/".$this->session->userdata('folder')."/img/perusahaan/pemasang/".$new_folder."/sertifikat");
            //chmod("upload_file/".$this->session->userdata('folder')."/img/perusahaan/pemasang/".$new_folder."/sertifikat", 0777, true);

        if($this->M_perusahaan->simpan_pemasang($nama_pemasang, $tanggal_lahir, $jenis_kelamin, $alamat, $kelurahan, $kecamatan, $kabupaten, $provinsi, $kodepos, $harga, $telepon, $new_folder) == TRUE){

                //mkdir("upload_file/".$this->session->userdata('folder')."/img/perusahaan");

            $_FILES["gambar_ktp"]["name"];

            $config['upload_path'] = './upload_file/'.$this->session->userdata('folder').'/img/perusahaan/pemasang/'.$new_folder.'/';
            $config['allowed_types'] = 'jpg|jpeg|png|gif|bmp';
            $config['file_name'] = 'ktp.png';
            $this->upload->initialize($config);
            $this->upload->do_upload('gambar_ktp');
            $data = $this->upload->data();
                //Compress Image
            $config['image_library']='gd2';
            $config['source_image']='./upload_file/'.$this->session->userdata('folder').'/img/perusahaan/pemasang/'.$new_folder.'/'.$data['file_name'];
            $config['create_thumb']= FALSE;
            $config['maintain_ratio']= TRUE;
            $config['quality']= '100%';
                //$config['width']= 720;
                //$config['height']= 300;
            $config['new_image']= './upload_file/'.$this->session->userdata('folder').'/img/perusahaan/pemasang/'.$new_folder.'/'.$data['file_name'];
            $this->load->library('image_lib', $config);
            $this->image_lib->resize();
                //  echo base_url().'./upload_file/'.$this->session->userdata('folder').'/img/perusahaan/'.$data['file_name'];      
                //______________________________________________________________________________________________
            $_FILES["foto_profil"]["name"];

            $config1['upload_path'] = './upload_file/'.$this->session->userdata('folder').'/img/perusahaan/pemasang/'.$new_folder.'/';
            $config1['allowed_types'] = 'jpg|jpeg|png|gif|bmp';
            $config1['file_name'] = 'profil.png';
            $this->upload->initialize($config1);
            $this->upload->do_upload('foto_profil');
            $data = $this->upload->data();
                //Compress Image
            $config1['image_library']='gd2';
            $config1['source_image']='./upload_file/'.$this->session->userdata('folder').'/img/perusahaan/pemasang/'.$new_folder.'/'.$data['file_name'];
            $config1['create_thumb']= FALSE;
            $config1['maintain_ratio']= TRUE;
            $config1['quality']= '100%';
            $config1['width']= 720;
            $config1['height']= 300;
            $config1['new_image']= './upload_file/'.$this->session->userdata('folder').'/img/perusahaan/pemasang/'.$new_folder.'/'.$data['file_name'];
            $this->load->library('image_lib', $config1);
            $this->image_lib->resize();
                //______________________________________________________________________________________________

            $this->M_perusahaan->simpan_keahlian_pemasang($keahlian);
            $this->M_perusahaan->simpan_area_pemasang(array_unique($area));

            $this->session->set_flashdata('notif' , true);
            $this->session->set_flashdata('teks_notif' , "Teknisi berhasil ditambah");
            redirect(base_url()."perusahaan/tambah_pemasang");
        }else{

            $this->session->set_flashdata('notif' , true);
            $this->session->set_flashdata('teks_notif' , "Teknisi Gagal ditambah");
            redirect(base_url()."perusahaan/tambah_pemasang");
        }
    //    }else{

    //    } 
    }

     ////=======================================DASHBOARD ADMIN=================================================
    function simpan_edit_pemasang()//halaman verifikasi OTP
    {
     $id = $this->input->post('id');
     $nama_pemasang = $this->input->post('nama_pemasang');
     $tanggal_lahir = $this->input->post('tanggal_lahir');
     $jenis_kelamin = $this->input->post('jenis_kelamin');
     $alamat = $this->input->post('alamat');
     $kelurahan =  str_replace("_", " ", $this->input->post('kelurahan'));
     $kecamatan =  str_replace("_", " ", $this->input->post('kecamatan'));
     $kabupaten =  str_replace("_", " ", $this->input->post('kabupaten'));
     $provinsi =  str_replace("_", " ", $this->input->post('provinsi'));
     $kodepos = $this->input->post('kodepos');
     $harga = $this->input->post('harga');
     $telepon = $this->input->post('telepon');



     if($this->M_perusahaan->simpan_edit_pemasang($id, $nama_pemasang, $tanggal_lahir, $jenis_kelamin, $alamat, $kelurahan, $kecamatan, $kabupaten, $provinsi, $kodepos, $harga, $telepon) == TRUE){
        redirect(base_url()."perusahaan/pemasang/");
    }else{
        redirect(base_url()."perusahaan/pemasang/");
    }
}
    //========================================================================================================
function status_publish_pemasang($id_pemasang, $status)
{   
    if ($status == 'true') {
        $status_publish = 'false';
        $status_notif = 'tidak dipublish';
    }elseif ($status == 'false'){
        $status_publish = 'true';
        $status_notif = 'dipublish';
    }
    $this->db->where('id_pemasang' , $id_pemasang);
    $this->db->update('perusahaan_pemasang' , array('status_publis_pemasang' => $status_publish));
    if ($this->db->affected_rows() > 0){
        $this->session->set_flashdata('notif' , true);
        $this->session->set_flashdata('teks_notif' , "Pemasang ".$status_notif);
        redirect(base_url()."perusahaan/detail_pemasang/".$id_pemasang);
    }else{
        $this->session->set_flashdata('notif' , false);
        redirect(base_url()."perusahaan/detail_pemasang/".$id_pemasang);
        $this->session->set_flashdata('teks_notif' , "Gagal merubah status publish");
    }
}
     //=======================================DASHBOARD ADMIN=================================================
function simpan_edit_gambar_pemasang(){

 $id = $this->input->post('id');
 $folder = $this->input->post('folder');
 unlink('upload_file/'.$this->session->userdata('folder').'/img/perusahaan/pemasang/'.$folder.'/profil.png');
 $_FILES["foto"]["name"];

 $config['upload_path'] = './upload_file/'.$this->session->userdata('folder').'/img/perusahaan/pemasang/'.$folder.'/';
 $config['allowed_types'] = 'jpg|jpeg|png|gif|bmp';
 $config['file_name'] = 'profil.png';
 $this->upload->initialize($config);
 $this->upload->do_upload('foto');
 $data = $this->upload->data();
                //Compress Image
 $config['image_library']='gd2';
 $config['source_image']='./upload_file/'.$this->session->userdata('folder').'/img/perusahaan/pemasang/'.$folder.'/'.$data['file_name'];
 $config['create_thumb']= FALSE;
 $config['maintain_ratio']= TRUE;
 $config['quality']= '100%';
                //$config['width']= 720;
                //$config['height']= 300;
 $config['new_image']= './upload_file/'.$this->session->userdata('folder').'/img/perusahaan/pemasang/'.$folder.'/'.$data['file_name'];
 $this->load->library('image_lib', $config);
 $this->image_lib->resize();
                //  echo base_url().'./upload_file/'.$this->session->userdata('folder').'/img/perusahaan/'.$data['file_name'];      
                //______________________________________________________________________________________________

 redirect(base_url()."perusahaan/detail_pemasang/".$id);
}
    //========================================================================================================
    //=======================================DASHBOARD ADMIN=================================================
function hapus_pemasang($id_pemasang, $folder)
{   

    $this->db->where('id_pemasang' , $id_pemasang);
    $this->db->update('perusahaan_pemasang' , array('status_hapus_pemasang' => 'true'));

    $this->db->where('id_pemasang' , $id_pemasang);
    $this->db->delete('pemasang_keahlian');

    $this->db->where('id_pemasang' , $id_pemasang);
    $this->db->delete('pemasang_medsos');

    $this->db->where('id_pemasang' , $id_pemasang);
    $this->db->delete('pemasang_portofolio');

    $this->db->where('id_pemasang' , $id_pemasang);
    $this->db->delete('pemasang_sertifikat');

    $this->db->where('id_pemasang' , $id_pemasang);
    $this->db->delete('pemasang_area_kerja');

    $files =glob('upload_file/'.$this->session->userdata('folder').'/img/perusahaan/pemasang/'.$folder.'/slide/*');
    foreach ($files as $file) {
        if (is_file($file))
                unlink($file); // hapus file
        }
        rmdir('upload_file/'.$this->session->userdata('folder').'/img/perusahaan/pemasang/'.$folder.'/slide');

        $files1 =glob('upload_file/'.$this->session->userdata('folder').'/img/perusahaan/pemasang/'.$folder.'/sertifikat/*');
        foreach ($files1 as $file1) {
            if (is_file($file1))
                unlink($file1); // hapus file
        }
        rmdir('upload_file/'.$this->session->userdata('folder').'/img/perusahaan/pemasang/'.$folder.'/sertifikat');
        

        $dir = 'upload_file/'.$this->session->userdata('folder').'/img/perusahaan/pemasang/'.$folder.'/portofolio/';

        if(is_dir($dir)){
            if($handle = opendir($dir)){
                while(($file = readdir($handle)) !== false){
                    if ($file!='.' && $file!='..') {
                        $subhendle = opendir($dir.$file);
                        while(($subfile = readdir($subhendle)) !== false){
                            if ($subfile!='.' && $subfile!='..') {
                                unlink($dir.$file.'/'.$subfile);
                            }
                        }
                        rmdir($dir.$file);
                        closedir($subhendle);
                    }
                }
                closedir($handle);
            }
        }

        rmdir('upload_file/'.$this->session->userdata('folder').'/img/perusahaan/pemasang/'.$folder.'/portofolio');

        unlink('upload_file/'.$this->session->userdata('folder').'/img/perusahaan/pemasang/'.$folder.'/ktp.png');

       // if ($this->db->affected_rows() > 0){



        $this->session->set_flashdata('notif' , true);
        $this->session->set_flashdata('teks_notif' , "Pemasang berhasil dihapus");
        redirect(base_url()."perusahaan/Pemasang");
      /*  }else{
            $this->session->set_flashdata('notif' , false);
            $this->session->set_flashdata('teks_notif' , "Pemasang gagal dihapus");
            redirect(base_url()."perusahaan/Pemasang");
        }*/
    }

   function simpan_keahlian()
   {
      $id_pemasang = $this->input->post('id_pemasang');
      $keahlian = $this->input->post('keahlian');
     
      //$result = array();
      foreach ($keahlian as $key => $val) {
         $cek_keahlian=$this->db->get_where('pemasang_keahlian', array('id_pemasang'=>$id_pemasang, 'keahlian'=>$_POST['keahlian'][$key]))->result_array();
         if (count($cek_keahlian) < 1) {
              $result = array(      
                 'id_pemasang' => $id_pemasang,        
                 'keahlian' => $_POST['keahlian'][$key],
                 'input_keahlian' => date('Y-m-d')

              );  
              $this->db->insert('pemasang_keahlian',$result);
              
         }
      

      }       
 
      redirect(base_url().'perusahaan/detail_pemasang/'.$id_pemasang);
   }
   function hapus_keahlian($id, $id_pemasang)
   {   
      $cek_keahlian=$this->db->get_where('pemasang_keahlian', array('id_pemasang'=>$id_pemasang))->result_array();
      if (count($cek_keahlian) > 1) {
         $this->db->where('id_keahlian', $id);
         $this->db->delete('pemasang_keahlian');
      }

      redirect(base_url().'perusahaan/detail_pemasang/'.$id_pemasang);
   }
   function simpan_area()
   {
      $id_pemasang = $this->input->post('id_pemasang');
      $area = $this->input->post('areaOperasi',TRUE);
      $cek=array_unique($area);
      //$result = array();
      foreach ($cek as $key => $val) {
         $cek_keahlian=$this->db->get_where('pemasang_area_kerja', array('id_pemasang'=>$id_pemasang, 'area_pemasang'=>$cek[$key]))->result_array();

         if (count($cek_keahlian) < 1) {
            $result = array(      
               'id_pemasang' => $id_pemasang,
               'area_pemasang' => $cek[$key],
               'input_area_kerja' => date('Y-m-d')

            );  
            $this->db->insert('pemasang_area_kerja',$result); 
              
         }
      

      }       
 
      redirect(base_url().'perusahaan/detail_pemasang/'.$id_pemasang);
   }
   function hapus_area($id, $id_pemasang)
   {   
      $cek_area=$this->db->get_where('pemasang_area_kerja', array('id_pemasang'=>$id_pemasang))->result_array();
      if (count($cek_area) > 1) {
         $this->db->where('id_area_kerja', $id);
         $this->db->delete('pemasang_area_kerja');
      }

      redirect(base_url().'perusahaan/detail_pemasang/'.$id_pemasang);
   }
    //==================================================================================================
    function simpan_portofolio_pemasang(){

        $id = $this->input->post('id');
        $nama_pekerjaan = $this->input->post('nama_pekerjaan');
        $ukuran_sistem = $this->input->post('ukuran_sistem');
        $folder_pemasang = $this->input->post('folder_pemasang');
        $_FILES["slide"]["name"];
        $new_folder_portofolio = substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz123456789'), 0, 7);
        date_default_timezone_set('Asia/Jakarta');
        $new_folder = 'portofolio_'.$new_folder_portofolio.'_'.date("d").''.date("m").''.date("y").''.date("H").''.date("i").''.date("s");



        mkdir("upload_file/".$this->session->userdata('folder')."/img/perusahaan/pemasang/".$folder_pemasang."/portofolio/".$new_folder);
        //chmod("upload_file/".$this->session->userdata('folder')."/img/perusahaan/pemasang/".$folder_pemasang."/portofolio/".$new_folder, 0777, true);

        $filesCount = count($_FILES['slide']['name']);
        for($i = 0; $i < $filesCount; $i++){
            $new_name_generate = substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz123456789'), 0, 5);
            date_default_timezone_set('Asia/Jakarta');
            $new_name = 'portofolio_'.$new_name_generate.'_'.date("d").''.date("m").''.date("y").''.date("H").''.date("i").''.date("s");

            $_FILES['file']['name']     = $_FILES['slide']['name'][$i];
            $_FILES['file']['type']     = $_FILES['slide']['type'][$i];
            $_FILES['file']['tmp_name'] = $_FILES['slide']['tmp_name'][$i];
            $_FILES['file']['error']     = $_FILES['slide']['error'][$i];
            $_FILES['file']['size']     = $_FILES['slide']['size'][$i];

            // File upload configuration
            $config['upload_path'] = './upload_file/'.$this->session->userdata('folder').'/img/perusahaan/pemasang/'.$folder_pemasang.'/portofolio/'.$new_folder;

            $config['allowed_types'] = 'jpg|jpeg|png|gif|bmp';
            $config['file_name'] = $new_name.'.png';
            $config['create_thumb']= FALSE;
            $config['maintain_ratio']= TRUE;
            $config['quality']= '100%';

            $this->load->library('upload', $config);
            $this->upload->initialize($config);

            if($this->upload->do_upload('file')){
                $fileData = $this->upload->data();
                $uploadData[$i]['file_name'] = $fileData['file_name'];
                $uploadData[$i]['uploaded_on'] = date("Y-m-d H:i:s");

            //  $insert = $this->file->insert($uploadData);
            }
        }

        if(!empty($uploadData)){

         $data = array(
            'id_pemasang' => $id,
            'nama_pekerjaan' => $nama_pekerjaan,
            'ukuran_sistem' => str_replace(",",".",$ukuran_sistem),
            'folder' => $new_folder,
            'input_portofolio' => date('Y-m-d')
        );
         $this->db->insert('pemasang_portofolio',$data);

         $this->session->set_flashdata('notif' , true);
         $this->session->set_flashdata('teks_notif' , "Slide Berhasil ditambah");
     }

     redirect(base_url()."perusahaan/detail_pemasang/".$id);
 }
     //=======================================DASHBOARD ADMIN=================================================
 function simpan_edit_portofolio()
 {
    $id = $this->input->post('id');
    $id_portofolio = $this->input->post('id_portofolio');
    $nama_pekerjaan = $this->input->post('nama_pekerjaan');
    $ukuran_sistem = $this->input->post('ukuran_sistem');
    $data =array(
        'nama_pekerjaan' => $nama_pekerjaan,
        'ukuran_sistem' => str_replace(",",".",$ukuran_sistem)
    );
    $this->db->where('id_portofolio' , $id_portofolio);
    $this->db->update('pemasang_portofolio' , $data);
    if ($this->db->affected_rows() > 0){
        $this->session->set_flashdata('notif' , true);
        $this->session->set_flashdata('teks_notif' , "Portofolio berhasil diupdate");
        redirect(base_url()."perusahaan/detail_pemasang/".$id);
    }else{
        $this->session->set_flashdata('notif' , false);
        $this->session->set_flashdata('teks_notif' , "Portofolio gagal diupdate");
        redirect(base_url()."perusahaan/detail_pemasang/".$id);
    }
}
function simpan_slide_portofolio(){

    $id = $this->input->post('id');
    $folder = $this->input->post('folder');
    $_FILES["slide"]["name"];

    $filesCount = count($_FILES['slide']['name']);
    for($i = 0; $i < $filesCount; $i++){
        $new_name_generate = substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz123456789'), 0, 5);
        date_default_timezone_set('Asia/Jakarta');
        $new_name = 'portofolio_'.$new_name_generate.'_'.date("d").''.date("m").''.date("y").''.date("H").''.date("i").''.date("s");

        $_FILES['file']['name']     = $_FILES['slide']['name'][$i];
        $_FILES['file']['type']     = $_FILES['slide']['type'][$i];
        $_FILES['file']['tmp_name'] = $_FILES['slide']['tmp_name'][$i];
        $_FILES['file']['error']     = $_FILES['slide']['error'][$i];
        $_FILES['file']['size']     = $_FILES['slide']['size'][$i];

            // File upload configuration
        $config['upload_path'] = $folder;

        $config['allowed_types'] = 'jpg|jpeg|png|gif|bmp';
        $config['file_name'] = $new_name.'.png';
        $config['create_thumb']= FALSE;
        $config['maintain_ratio']= TRUE;
        $config['quality']= '100%';

        $this->load->library('upload', $config);
        $this->upload->initialize($config);

        if($this->upload->do_upload('file')){
            $fileData = $this->upload->data();
            $uploadData[$i]['file_name'] = $fileData['file_name'];
            $uploadData[$i]['uploaded_on'] = date("Y-m-d H:i:s");

            //  $insert = $this->file->insert($uploadData);
        }
    }

    if(!empty($uploadData)){

        $this->session->set_flashdata('notif' , true);
        $this->session->set_flashdata('teks_notif' , "Slide Berhasil ditambah");
    }

    redirect(base_url()."perusahaan/detail_pemasang/".$id);
}
function simpan_sertifikat_pemasang()
{

    $id_pemasang = $this->input->post('id_pemasang');
    $nama_sertifikat = $this->input->post('nama_sertifikat');
    $folder_pemasang = $this->input->post('folder_pemasang');
    $_FILES["sertifikat"]["name"];
    $new_name_generate = substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz123456789'), 0, 5);
    date_default_timezone_set('Asia/Jakarta');
    $new_name = 'sertifikat_'.$new_name_generate.'_'.date("d").''.date("m").''.date("y").''.date("H").''.date("i").''.date("s").'.png';

    if($this->M_perusahaan->simpan_sertifikat_pemasang($id_pemasang, $nama_sertifikat, $new_name) == TRUE){

        $config['upload_path'] = './upload_file/'.$this->session->userdata('folder').'/img/perusahaan/pemasang/'.$folder_pemasang.'/sertifikat/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif|bmp';
        $config['file_name'] = $new_name;
        $this->upload->initialize($config);
        $this->upload->do_upload('sertifikat');
        $data = $this->upload->data();
                //Compress Image
        $config['image_library']='gd2';
        $config['source_image']='./upload_file/'.$this->session->userdata('folder').'/img/perusahaan/pemasang/'.$folder_pemasang.'/sertifikat/'.$data['file_name'];
        $config['create_thumb']= FALSE;
        $config['maintain_ratio']= TRUE;
        $config['quality']= '100%';
            //$config['width']= 720;
            //$config['height']= 300;
        $config['new_image']= './upload_file/'.$this->session->userdata('folder').'/img/perusahaan/pemasang/'.$folder_pemasang.'/sertifikat/'.$data['file_name'];
        $this->load->library('image_lib', $config);
        $this->image_lib->resize();
                    //  echo base_url().'./upload_file/'.$this->session->userdata('folder').'/img/perusahaan/'.$data['file_name'];      
                    //__________________________________________________________________________________________
        $this->session->set_flashdata('notif' , true);
        $this->session->set_flashdata('teks_notif' , "Sertifikat berhasil ditambah");
        redirect(base_url()."perusahaan/detail_pemasang/".$id_pemasang);
    }else{
        $this->session->set_flashdata('notif' , false);
        $this->session->set_flashdata('teks_notif' , "Sertifikat Gagal ditambahs");
        redirect(base_url()."perusahaan/detail_pemasang/".$id_pemasang);
    }
}
    //========================================================================================================
function hapus_sertifikat($id_pemasang, $id_sertifikat, $folder_pemasang, $sertifikat )
{   
    $this->db->where('id_sertifikat', $id_sertifikat);
    $this->db->delete('pemasang_sertifikat');

    unlink("./upload_file/".$this->session->userdata('folder')."/img/perusahaan/pemasang/".$folder_pemasang."/sertifikat/".$sertifikat);

    redirect(base_url()."perusahaan/detail_pemasang/".$id_pemasang);
}


public function penawaran_masuk()
{
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();

        $data['penawaran'] = $this->M_perusahaan->penawaran_masuk('menunggu_tanggapan');
        
        
        if ($this->session->userdata('jenis_perusahaan') == 'komersial') {

            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        }elseif ($this->session->userdata('jenis_perusahaan') =='individu') {
            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header_1', $data);
        }
        $this->load->view('frontend/perusahaan/penawaran_masuk');
        $this->load->view('frontend/perusahaan/footer');
    }
    function penawaran_ditanggapi()
    {
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();

        $data['penawaran'] = $this->M_perusahaan->penawaran_ditanggapi();
        
        
        if ($this->session->userdata('jenis_perusahaan') == 'komersial') {

            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        }elseif ($this->session->userdata('jenis_perusahaan') =='individu') {
            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header_1', $data);
        }
        $this->load->view('frontend/perusahaan/penawaran_ditanggapi');
        $this->load->view('frontend/perusahaan/footer');
    }
    public function riwayat_penawaran()
    {
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();

        $data['penawaran'] = $this->M_perusahaan->penawaran_riwayat();
        
        
        if ($this->session->userdata('jenis_perusahaan') == 'komersial') {

            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        }elseif ($this->session->userdata('jenis_perusahaan') =='individu') {
            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header_1', $data);
        }
        $this->load->view('frontend/perusahaan/penawaran_riwayat');
        $this->load->view('frontend/perusahaan/footer');
    }

    public function penawaran_detail($id_penawaran)
    {
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();

        $data['penawaran'] = $this->M_perusahaan->penawaran_detail($id_penawaran);
        
        
        if ($this->session->userdata('jenis_perusahaan') == 'komersial') {

            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        }elseif ($this->session->userdata('jenis_perusahaan') =='individu') {
            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header_1', $data);
        }
        $this->load->view('frontend/perusahaan/penawaran_detail');
        $this->load->view('frontend/perusahaan/footer');
    }
    function tanggapi_penawaran($id)
    {
        $this->db->where('id_penawaran' , $id);
        $this->db->update('pemasang_penawaran' , array('status_penawaran'=> 'ditanggapi'));

        $this->session->set_flashdata('notif' , true);
        $this->session->set_flashdata('teks_notif' , "Berhasil ditanggapi");

        redirect(base_url() . "perusahaan/penawaran_masuk", "refresh");
    }
    function kerjakan_penawaran($id='')
    {

       $this->db->where('id_penawaran' , $id);
       $this->db->update('pemasang_penawaran' , array('status_penawaran'=> 'dikerjakan'));

       $this->session->set_flashdata('notif' , true);
       $this->session->set_flashdata('teks_notif' , "Berhasil dikerjakan");

       redirect(base_url() . "perusahaan/penawaran_ditanggapi", "refresh");
   }
   function penawaran_selesai()
   {

    $id=$this->input->post('id_penawaran', true);
    $this->db->where('id_penawaran' , $id);
    $this->db->update('pemasang_penawaran' , array('status_penawaran'=> 'selesai'));

      $data2 = array(
            'id_penawaran' => $id,
            'status_bukti'=> 'menunggu_verifikasi',
            'input_bukti' => date("Y-m-d")
        );
        $this->db->insert('penawaran_bukti' , $data2);

        mkdir('./upload_file/bukti/penawaran/'.$id);

        $filesCount = count($_FILES['bukti']['name']);
          for($i = 0; $i < $filesCount; $i++){
          
            $_FILES['file']['name']     = $_FILES['bukti']['name'][$i];
            $_FILES['file']['type']     = $_FILES['bukti']['type'][$i];
            $_FILES['file']['tmp_name'] = $_FILES['bukti']['tmp_name'][$i];
            $_FILES['file']['error']     = $_FILES['bukti']['error'][$i];
            $_FILES['file']['size']     = $_FILES['bukti']['size'][$i];

                // File upload configuration
            $config['upload_path'] = './upload_file/bukti/penawaran/'.$id.'/';

            $config['allowed_types'] = 'jpg|jpeg|png|gif|bmp';
            $config['create_thumb']= FALSE;
            $config['maintain_ratio']= TRUE;
            $config['quality']= '100%';

            $this->load->library('upload', $config);
            $this->upload->initialize($config);

            if($this->upload->do_upload('file')){
                $fileData = $this->upload->data();
                $uploadData[$i]['file_name'] = $fileData['file_name'];
                $uploadData[$i]['uploaded_on'] = date("Y-m-d H:i:s");
            }
        }

       $this->session->set_flashdata('notif' , true);
       $this->session->set_flashdata('teks_notif' , "Berhasil diselesaikan");

       redirect(base_url() . "perusahaan/riwayat_penawaran", "refresh");
   }
   function bukti_penawaran()
   {
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();

        $data['penawaran'] = $this->M_perusahaan->penawaran_bukti();
        
        
        if ($this->session->userdata('jenis_perusahaan') == 'komersial') {

            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        }elseif ($this->session->userdata('jenis_perusahaan') =='individu') {
            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header_1', $data);
        }
        $this->load->view('frontend/perusahaan/penawaran_bukti');
        $this->load->view('frontend/perusahaan/footer');
   }

   function upload_bukti_penawaran()
   {
        $id=$this->input->post('id_penawaran', true);
        $this->db->where('id_penawaran' , $id);
        $this->db->update('penawaran_bukti' , array('status_bukti'=> 'menunggu_verifikasi'));

          $files = glob('upload_file/bukti/penawaran/'.$id.'/*'); //get all file names
            foreach($files as $file){
                if(is_file($file))
                unlink($file); //delete file
            }

        $filesCount = count($_FILES['bukti']['name']);
          for($i = 0; $i < $filesCount; $i++){
          
            $_FILES['file']['name']     = $_FILES['bukti']['name'][$i];
            $_FILES['file']['type']     = $_FILES['bukti']['type'][$i];
            $_FILES['file']['tmp_name'] = $_FILES['bukti']['tmp_name'][$i];
            $_FILES['file']['error']     = $_FILES['bukti']['error'][$i];
            $_FILES['file']['size']     = $_FILES['bukti']['size'][$i];

                // File upload configuration
            $config['upload_path'] = './upload_file/bukti/penawaran/'.$id.'/';

            $config['allowed_types'] = 'jpg|jpeg|png|gif|bmp';
            $config['create_thumb']= FALSE;
            $config['maintain_ratio']= TRUE;
            $config['quality']= '100%';

            $this->load->library('upload', $config);
            $this->upload->initialize($config);

            if($this->upload->do_upload('file')){
                $fileData = $this->upload->data();
                $uploadData[$i]['file_name'] = $fileData['file_name'];
                $uploadData[$i]['uploaded_on'] = date("Y-m-d H:i:s");
            }
        }

       $this->session->set_flashdata('notif' , true);
       $this->session->set_flashdata('teks_notif' , "Berhasil diselesaikan");

       redirect(base_url() . "perusahaan/bukti_penawaran");
   }
   function bukti_transfer_penawaran()
   {
         $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();

        $data['penawaran'] = $this->M_perusahaan->penawaran_transfer();
        
        
        if ($this->session->userdata('jenis_perusahaan') == 'komersial') {

            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        }elseif ($this->session->userdata('jenis_perusahaan') =='individu') {
            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header_1', $data);
        }
        $this->load->view('frontend/perusahaan/penawaran_transfer');
        $this->load->view('frontend/perusahaan/footer');
   }

    ////=======================================Pembelian=================================================
   function pembelian()
   {
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();

        $data['pembelian'] = $this->M_perusahaan->tampil_pembelian();
        
        
        if ($this->session->userdata('jenis_perusahaan') == 'komersial') {

            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        }elseif ($this->session->userdata('jenis_perusahaan') =='individu') {
            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header_1', $data);
        }
        $this->load->view('frontend/perusahaan/pembelian');
        $this->load->view('frontend/perusahaan/footer');
    }
    function detail_pembelian($id_order = null, $nomor_invoice = null)
    {
        //==========================================================================
        if (empty($id_order)) {redirect(base_url().'perusahaan/pembelian');}
        //$no_invoice = str_replace('-', '/',$no_invoice);

        $validasi = $this->db->get_where('order', array('id_order'=> $id_order))->result_array();
        if (count($validasi)<1) {redirect(base_url().'perusahaan/pembelian');}
        //==========================================================================  
        $data['nomor_invoice']=  str_replace('-', '/',$nomor_invoice);         
        $data['invoice'] = $this->M_perusahaan->tampil_detail_invoice($id_order);
        $data['daftar_invoice'] = $this->M_perusahaan->tampil_daftar_invoice($id_order);

        
        if ($this->session->userdata('jenis_perusahaan') == 'komersial') {

            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        }elseif ($this->session->userdata('jenis_perusahaan') =='individu') {
            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header_1', $data);
        }
        $this->load->view('frontend/perusahaan/pembelian_detail');
        $this->load->view('frontend/perusahaan/footer');
    }
    function proses_pembelian($id_order)
    {
        $this->db->where('id_order' , $id_order);
        $this->db->update('order' , array('status_order'=> 'proses'));

        $this->session->set_flashdata('notif' , true);
        $this->session->set_flashdata('teks_notif' , "Skema Pembiayaan Berhasil di Update");

        redirect(base_url() . "perusahaan/pembelian", "refresh");
    }
    function pengemasan()
    {
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();

        $data['proses'] = $this->M_perusahaan->tampil_proses_pembelian();
        
        
        if ($this->session->userdata('jenis_perusahaan') == 'komersial') {

            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        }elseif ($this->session->userdata('jenis_perusahaan') =='individu') {
            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header_1', $data);
        }
        $this->load->view('frontend/perusahaan/pembelian_proses');
        $this->load->view('frontend/perusahaan/footer');
    }
    function pengiriman_pembelian($id_order)
    {
        $this->db->where('id_order' , $id_order);
        $this->db->update('order' , array('status_order'=> 'kirim'));

        $this->session->set_flashdata('notif' , true);
        $this->session->set_flashdata('teks_notif' , "Skema Pembiayaan Berhasil di Update");

        redirect(base_url() . "perusahaan/pengemasan", "refresh");
    }
    function pengiriman()
    {
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();

        $data['pengiriman'] = $this->M_perusahaan->tampil_pengiriman_pembelian();
        
        
        if ($this->session->userdata('jenis_perusahaan') == 'komersial') {

            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        }elseif ($this->session->userdata('jenis_perusahaan') =='individu') {
            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header_1', $data);
        }
        $this->load->view('frontend/perusahaan/pembelian_pengiriman');
        $this->load->view('frontend/perusahaan/footer');
    }
    function pengiriman_selesai()
    {
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();

        $data['pengiriman'] = $this->M_perusahaan->tampil_pembelian_selesai();
        
        
        if ($this->session->userdata('jenis_perusahaan') == 'komersial') {

            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        }elseif ($this->session->userdata('jenis_perusahaan') =='individu') {
            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header_1', $data);
        }
        $this->load->view('frontend/perusahaan/pembelian_selesai');
        $this->load->view('frontend/perusahaan/footer');
    }
      function upload_bukti_pembelian()
    {
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();

        $data['pembelian'] = $this->M_perusahaan->tampil_pembelian_upload();
        
        
        if ($this->session->userdata('jenis_perusahaan') == 'komersial') {

            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        }elseif ($this->session->userdata('jenis_perusahaan') =='individu') {
            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header_1', $data);
        }
        $this->load->view('frontend/perusahaan/pembelian_upload_bukti');
        $this->load->view('frontend/perusahaan/footer');
    }
    function upload_buktiPembelian()
    {
        $id_order = $this->input->post('id_order',TRUE);
        $status = $this->input->post('status',TRUE);

        $this->db->where('id_order' , $id_order);
        $this->db->update('order_bukti' , array('status_bukti' => 'menunggu_verifikasi'));

        if ($status=='upload') {
            mkdir('./upload_file/bukti/produk/'.$id_order);
        }else if($status=='upload_ulang'){
            $files = glob('upload_file/bukti/produk/'.$id_order.'/*'); //get all file names
            foreach($files as $file){
                if(is_file($file))
                unlink($file); //delete file
            }
        }

        $filesCount = count($_FILES['bukti']['name']);
          for($i = 0; $i < $filesCount; $i++){
          
            $_FILES['file']['name']     = $_FILES['bukti']['name'][$i];
            $_FILES['file']['type']     = $_FILES['bukti']['type'][$i];
            $_FILES['file']['tmp_name'] = $_FILES['bukti']['tmp_name'][$i];
            $_FILES['file']['error']     = $_FILES['bukti']['error'][$i];
            $_FILES['file']['size']     = $_FILES['bukti']['size'][$i];

                // File upload configuration
            $config['upload_path'] = './upload_file/bukti/produk/'.$id_order.'/';

            $config['allowed_types'] = 'jpg|jpeg|png|gif|bmp';
            $config['create_thumb']= FALSE;
            $config['maintain_ratio']= TRUE;
            $config['quality']= '100%';

            $this->load->library('upload', $config);
            $this->upload->initialize($config);

            if($this->upload->do_upload('file')){
                $fileData = $this->upload->data();
                $uploadData[$i]['file_name'] = $fileData['file_name'];
                $uploadData[$i]['uploaded_on'] = date("Y-m-d H:i:s");
            }
        }

       
        redirect(base_url()."perusahaan/upload_bukti_pembelian");
       
    }
    function bukti_transfer_pembelian()
    {
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();

        $data['pembelian'] = $this->M_perusahaan->tampil_transfer_pembelian();
        
        
        if ($this->session->userdata('jenis_perusahaan') == 'komersial') {

            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        }elseif ($this->session->userdata('jenis_perusahaan') =='individu') {
            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header_1', $data);
        }
        $this->load->view('frontend/perusahaan/pembelian_bukti_transfer');
        $this->load->view('frontend/perusahaan/footer');
    }
    //==================================================================================================
      ////=======================================Pembelian==============================================
    function banner()
    {
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();

        $data['banner'] = $this->M_perusahaan->tampil_banner();
        
        
        if ($this->session->userdata('jenis_perusahaan') == 'komersial') {

            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        }elseif ($this->session->userdata('jenis_perusahaan') =='individu') {
            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header_1', $data);
        }
        $this->load->view('frontend/perusahaan/banner');
        $this->load->view('frontend/perusahaan/footer');
    }
    function hapus_banner($id_banner, $banner)
    {
        $this->db->where('id_banner', $id_banner);
        $this->db->delete('perusahaan_banner');
        unlink('upload_file/'.$this->session->userdata('folder').'/img/perusahaan/banner/'.$banner);
        redirect(base_url().'perusahaan/banner');
    }
    function simpan_banner()
    {
       if (isset($_POST['banner'])){
        redirect(base_url()."perusahaan/banner");
    }
    $ket_banner = $this->input->post('ket_banner');

    $generate = substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz123456789'), 0, 7);
    date_default_timezone_set('Asia/Jakarta');
    $new_name = 'banner_'.$generate.'_'.date("d").''.date("m").''.date("y").''.date("H").''.date("i").''.date("s").'.png';

    if($this->M_perusahaan->simpan_banner($ket_banner, $new_name) == TRUE){

        $_FILES["banner"]["name"];

        $config['upload_path'] = './upload_file/'.$this->session->userdata('folder').'/img/perusahaan/banner/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif|bmp';
        $config['file_name'] = $new_name;
        $this->upload->initialize($config);
        $this->upload->do_upload('banner');
        $data = $this->upload->data();
                //Compress Image
        $config['image_library']='gd2';
        $config['source_image']='./upload_file/'.$this->session->userdata('folder').'/img/perusahaan/banner/'.$data['file_name'];
        $config['create_thumb']= FALSE;
        $config['maintain_ratio']= TRUE;
        $config['quality']= '100%';
                //$config['width']= 720;
                //$config['height']= 300;
        $config['new_image']= './upload_file/'.$this->session->userdata('folder').'/img/perusahaan/banner/'.$data['file_name'];
        $this->load->library('image_lib', $config);
        $this->image_lib->resize();
                //  echo base_url().'./upload_file/'.$this->session->userdata('folder').'/img/perusahaan/'.$data['file_name'];      
                //______________________________________________________________________________________________
        $this->session->set_flashdata('notif' , true);
        $this->session->set_flashdata('teks_notif' , "Banner berhasil ditambah");
        redirect(base_url()."perusahaan/banner");
    }else{
        $this->session->set_flashdata('notif' , false);
        $this->session->set_flashdata('teks_notif' , "Banner gagal ditambah");
        redirect(base_url()."perusahaan/banner");
    }
}
function portofolio()
{
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();

        $data['portofolio'] = $this->M_perusahaan->tampil_portofolio_perusahaan();
        
        
        if ($this->session->userdata('jenis_perusahaan') == 'komersial') {

            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        }elseif ($this->session->userdata('jenis_perusahaan') =='individu') {
            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header_1', $data);
        }
        $this->load->view('frontend/perusahaan/portofolio');
        $this->load->view('frontend/perusahaan/footer');
    }
    function simpan_portofolio()
    {
      $get_id_perusahaan = $this->db->get_where('perusahaan', array('id_user'=>$this->session->userdata('id_user')));
      $value_get_id = $get_id_perusahaan->row();

      $nama_projek = $this->input->post('nama_projek');
      $kapasitas = $this->input->post('kapasitas');
      $informasi_tambahan = $this->input->post('informasi_tambahan');
      $folder = substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz123456789'), 0, 8);
      $_FILES["slide"]["name"];

      mkdir("./upload_file/".$this->session->userdata('folder')."/img/perusahaan/portofolio/".$folder);
        //chmod("./upload_file/".$this->session->userdata('folder')."/img/perusahaan/portofolio/".$folder, 0777, true);

      $filesCount = count($_FILES['slide']['name']);
      for($i = 0; $i < $filesCount; $i++){
        $new_name = substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz123456789'), 0, 5);

        $_FILES['file']['name']     = $_FILES['slide']['name'][$i];
        $_FILES['file']['type']     = $_FILES['slide']['type'][$i];
        $_FILES['file']['tmp_name'] = $_FILES['slide']['tmp_name'][$i];
        $_FILES['file']['error']     = $_FILES['slide']['error'][$i];
        $_FILES['file']['size']     = $_FILES['slide']['size'][$i];

            // File upload configuration
        $config['upload_path'] = './upload_file/'.$this->session->userdata('folder').'/img/perusahaan/portofolio/'.$folder.'/';

        $config['allowed_types'] = 'jpg|jpeg|png|gif|bmp';
        $config['file_name'] = 'slide_'.$new_name.'.png';
        $config['create_thumb']= FALSE;
        $config['maintain_ratio']= TRUE;
        $config['quality']= '100%';

        $this->load->library('upload', $config);
        $this->upload->initialize($config);

        if($this->upload->do_upload('file')){
            $fileData = $this->upload->data();
            $uploadData[$i]['file_name'] = $fileData['file_name'];
            $uploadData[$i]['uploaded_on'] = date("Y-m-d H:i:s");


            //  $insert = $this->file->insert($uploadData);
        }
    }

    if(!empty($uploadData)){
        $data = array(
            'id_perusahaan' => $value_get_id->id_perusahaan,
            'projek' => $nama_projek,
            'kapasitas' => str_replace(",",".",$kapasitas),
            'informasi_tambahan' => $informasi_tambahan,
            'folder' => $folder,
            'input_portofolio_perusahaan' => date('Y-m-d')
        );
        $this->db->insert('perusahaan_portofolio',$data);

        $this->session->set_flashdata('notif' , true);
        $this->session->set_flashdata('teks_notif' , "Slide Berhasil ditambah");
    }
    redirect(base_url()."perusahaan/portofolio");

}
function hapus_portofolio($id_portofolio, $folder)
{
    $this->db->where('id_portofolio', $id_portofolio);
    $this->db->delete('perusahaan_portofolio');

        $files = glob('./upload_file/'.$this->session->userdata('folder').'/img/perusahaan/portofolio/'.$folder.'/*'); //get all file names
        foreach($files as $file){
            if(is_file($file))
            unlink($file); //delete file
    }
    rmdir('./upload_file/'.$this->session->userdata('folder').'/img/perusahaan/portofolio/'.$folder);

    redirect(base_url()."perusahaan/portofolio");
}
function hapus_slide_portofolio($folder_portofolio, $slide_portofolio)
{
      // echo base_url()."upload_file/".$this->session->userdata('folder')."/img/perusahaan/portofolio/".$folder_portofolio."/".$slide_portofolio;
   unlink("./upload_file/".$this->session->userdata('folder')."/img/perusahaan/portofolio/".$folder_portofolio."/".$slide_portofolio);
   redirect(base_url()."perusahaan/portofolio");
}

     //========================================================================================================


function chat()
{
    $data['id_user']= '0';
    $data['jenis_chat']= 'text';
    $data['pengirim']= 'perusahaan';

        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();
        $data['perusahaan'] = $this->M_perusahaan->perusahaan();
        $data['daftar_chat'] = $this->M_perusahaan->daftar_chat();

          if ($this->session->userdata('jenis_perusahaan') == 'komersial') {

            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        }elseif ($this->session->userdata('jenis_perusahaan') =='individu') {
            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header_1', $data);
        }
        $this->load->view('frontend/perusahaan/chat');
        $this->load->view('frontend/perusahaan/footer');
    }
    function view_chat()
    {
       $id_user = $this->input->post('id_user');

       $daftarChat = $this->M_perusahaan->daftar_chat();                       
       $chatView = $this->M_perusahaan->view_chat($id_user);

       $daftar_chat =  $this->load->view('frontend/perusahaan/chat_daftar', array('daftar_chat'=>$daftarChat), true);
       $chat_view = $this->load->view('frontend/perusahaan/chat_view', array('chat_view'=>$chatView), true);

       $callback = array(
        'daftar_chat' => $daftar_chat,
        'chat_view' => $chat_view,
        'count_chat'=>count($chatView)
    );
       echo json_encode($callback);
   }

   function send_chat()
   {
    $chat = $this->input->post('chat');
    $id_user = $this->input->post('id_user');
    $jenis = $this->input->post('jenis');
    $pengirim = $this->input->post('pengirim');                         

    $this->M_perusahaan->send_chat($chat, $id_user, $jenis, $pengirim);

    $daftarChat = $this->M_perusahaan->daftar_chat();                       
    $chatView = $this->M_perusahaan->view_chat($id_user);

    $daftar_chat =  $this->load->view('frontend/perusahaan/chat_daftar', array('daftar_chat'=>$daftarChat), true);
    $chat_view = $this->load->view('frontend/perusahaan/chat_view', array('chat_view'=>$chatView), true);

    $callback = array(
        'daftar_chat' => $daftar_chat,
        'chat_view' => $chat_view
    );
    echo json_encode($callback);

}

function send_chat_bidding()
{
    $chat = $this->input->post('chat');
    $id_user = $this->input->post('id_user');
    $id_perusahaan = $this->input->post('id_perusahaan');
    $pengirim = $this->input->post('pengirim');
    $jenis = $this->input->post('jenis');
    $id = $this->input->post('id_bidding');

        $this->M_perusahaan->send_chat_bidding($id, $id_user, $id_perusahaan, $pengirim, $jenis);//chat bidding
        $this->M_perusahaan->send_chat_bidding($chat, $id_user, $id_perusahaan, $pengirim, 'text');//chat text      
        redirect(base_url().'perusahaan/lelang_berlangsung');
    }

   /* function chat_perusahaan($id_perusahaan, $jenis_chat, $pengirim)
    {
        $data['id_perusahaan']= $id_perusahaan;
        $data['jenis_chat']= $jenis_chat;
        $data['pengirim']= $pengirim;
        
        $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
        $data['medsos'] = $this->Website->medsosweb();

        $data['daftar_chat'] = $this->M_user->tampil_chat();

        $this->load->view('frontend/user/header_user',$data);
        $this->load->view('frontend/user/chat');
        $this->load->view('frontend/user/footer');
    }*/

    function jadwal()
    {
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
       // $data['medsos'] = $this->Website->medsosweb();

        $data['jadwal'] = $this->M_perusahaan->tampil_jadwal();
        
        
        if ($this->session->userdata('jenis_perusahaan') == 'komersial') {

            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        }elseif ($this->session->userdata('jenis_perusahaan') =='individu') {
            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header_1', $data);
        }
        $this->load->view('frontend/perusahaan/jadwal');
        $this->load->view('frontend/perusahaan/footer');
    }
    function simpan_jadwal()
    {
        $id_jadwal = $this->input->post('id_jadwal');

        $result = array();
        foreach ($id_jadwal as $key => $val) {
            $result[] = array(    
                'id_jadwal' => $id_jadwal[$key],  
                'kondisi' => $_POST['kondisi'][$key],
                'jam_buka' => $_POST['jam_buka'][$key],
                'jam_tutup' => $_POST['jam_tutup'][$key],
            );  

        }       

        $this->db->update_batch('perusahaan_jadwal', $result, 'id_jadwal');


      /*  if($this->M_perusahaan->simpan_jadwal($id_jadwal, $kondisi, $jam_buka, $jam_tutup) == TRUE){

            $this->session->set_flashdata('notif' , true);
            $this->session->set_flashdata('teks_notif' , "Jadwal berhasil diupdate");
        }else{
            $this->session->set_flashdata('notif' , false);
            $this->session->set_flashdata('teks_notif' , "Jadwal gagal diupdate");
        }*/

        redirect(base_url()."perusahaan/jadwal");
    }
    function area_operasi()
    {
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); 
        $data['medsos'] = $this->M_perusahaan->tampil_media_sosial();
        $data['area_operasi'] = $this->M_perusahaan->tampil_area_operasi();
        $data['provinsi'] = $this->M_perusahaan->tampil_provinsi();
        if ($this->session->userdata('jenis_perusahaan') == 'komersial') {

            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        }elseif ($this->session->userdata('jenis_perusahaan') =='individu') {
            $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header_1', $data);
        }
        $this->load->view('frontend/perusahaan/area_operasi');
        $this->load->view('frontend/perusahaan/footer');
    }
    function tambah_area_operasi()
    {
        $kabupaten = $this->input->post('kabupaten');

        $get_id_perusahaan = $this->db->get_where('perusahaan', array('id_user'=>$this->session->userdata('id_user')));
        $value_get_id = $get_id_perusahaan->row();

        $get_area_operasi = $this->db->get_where('perusahaan_area_operasi', array('id_perusahaan'=> $value_get_id->id_perusahaan, 'kabupaten'=> $kabupaten))->result_array();
        
        if (count($get_area_operasi) < 1) {
         $data = array(
            'id_perusahaan' => $value_get_id->id_perusahaan,
            'kabupaten' => $kabupaten,
            'input_area_operasi' => date('Y-m-d')
        );
         $this->db->insert('perusahaan_area_operasi',$data);

         $area_operasi = $this->M_perusahaan->tampil_area_operasi_perusahaan($value_get_id->id_perusahaan);

         $hasil = $this->load->view('frontend/perusahaan/area_operasi_view', array('area_operasi'=>$area_operasi), true);

         $callback = array(
              'hasil' => $hasil // Set array hasil dengan isi dari view.php yang diload tadi
          );
         echo json_encode($callback);

     }else{
        $hasil = 'no';

        $callback = array(
              'hasil' => $hasil // Set array hasil dengan isi dari view.php yang diload tadi
          );
        echo json_encode($callback);
    }

}

function hapus_area_operasi()
{
    $id_area_operasi = $this->input->post('id_area_operasi');
    $get_id_perusahaan = $this->db->get_where('perusahaan', array('id_user'=>$this->session->userdata('id_user')));
    $value_get_id = $get_id_perusahaan->row();

    $this->db->where('id_area_operasi', $id_area_operasi);
    $this->db->delete('perusahaan_area_operasi');

    $area_operasi = $this->M_perusahaan->tampil_area_operasi_perusahaan($value_get_id->id_perusahaan);

    $hasil = $this->load->view('frontend/perusahaan/area_operasi_view', array('area_operasi'=>$area_operasi), true);

    $callback = array(
           'hasil' => $hasil // Set array hasil dengan isi dari view.php yang diload tadi
       );
    echo json_encode($callback);
}
function media_sosial()
{
    $data['lang'] = $this->Website->lang($this->session->userdata('lang')); 
    $data['medsos'] = $this->M_perusahaan->tampil_media_sosial();


    if ($this->session->userdata('jenis_perusahaan') == 'komersial') {

        $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
    }elseif ($this->session->userdata('jenis_perusahaan') =='individu') {
        $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header_1', $data);
    }
    $this->load->view('frontend/perusahaan/media_sosial');
    $this->load->view('frontend/perusahaan/footer');
}
    function update_medsos()// update medsos
    {
       $email = $this->M_perusahaan->update_medsos('email', $this->input->post('email',TRUE));
       $facebook = $this->M_perusahaan->update_medsos('facebook', $this->input->post('facebook',TRUE));
       $instagram = $this->M_perusahaan->update_medsos('instagram', $this->input->post('instagram',TRUE));
       $linkedin = $this->M_perusahaan->update_medsos('linkedin', $this->input->post('linkedin',TRUE));
       $pinterest = $this->M_perusahaan->update_medsos('pinterest', $this->input->post('pinterest',TRUE));
       $telegram = $this->M_perusahaan->update_medsos('telegram', $this->input->post('telegram',TRUE));
       $twitter = $this->M_perusahaan->update_medsos('twitter', $this->input->post('twitter',TRUE));
       $whatsapp = $this->M_perusahaan->update_medsos('whatsapp', $this->input->post('whatsapp',TRUE));
       $video = $this->M_perusahaan->update_medsos('video', $this->input->post('video',TRUE));
       $website = $this->M_perusahaan->update_medsos('website', $this->input->post('website',TRUE));

       if ($email == TRUE || $facebook == TRUE || $instagram == TRUE || $linkedin == TRUE || $pinterest == TRUE || $telegram == TRUE || $telepon == TRUE || $twitter == TRUE || $whatsapp == TRUE || $video == TRUE || $website == TRUE) {  

        $this->session->set_flashdata('notif' , true);
        $this->session->set_flashdata('teks_notif' , "Media Sosial & Kontak berhasil diupdate");
    }else{
        $this->session->set_flashdata('notif' , false);
        $this->session->set_flashdata('teks_notif' , "Media Sosial & Kontak gagal diupdate");
    }

    redirect(base_url() . "perusahaan/media_sosial");
}
function skema_pembiayaan()
{
    $data['lang'] = $this->Website->lang($this->session->userdata('lang')); 
    $data['medsos'] = $this->M_perusahaan->tampil_media_sosial();
    $data['perusahaan'] = $this->M_perusahaan->tampil_pembiayaan();


    if ($this->session->userdata('jenis_perusahaan') == 'komersial') {

        $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
    }elseif ($this->session->userdata('jenis_perusahaan') =='individu') {
        $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header_1', $data);
    }
    $this->load->view('frontend/perusahaan/skema_pembiayaan');
    $this->load->view('frontend/perusahaan/footer');
}
function simpan_skema_pembiayaan()
{

    $cash = $this->input->post('cash',TRUE);
    $this->db->update('perusahaan' , array('id_perusahaan'=> $this->session->userdata('id_perusahaan')  , 'pembayaran_cash' => $cash));

    $bca = $this->input->post('bca',TRUE);
    $bri = $this->input->post('bri',TRUE);
    $bni = $this->input->post('bni',TRUE);
    $mandiri = $this->input->post('mandiri',TRUE);
    $permata = $this->input->post('permata',TRUE);
    $uob = $this->input->post('uob',TRUE);

    if ($bca == '0' && $bri == '0' && $bni == '0' && $mandiri == '0' && $permata == '0' && $uob == '0') {
        $this->db->update('perusahaan' , array('id_perusahaan'=> $this->session->userdata('id_perusahaan')  , 'pembayaran_kredit' => 'false'));
    }else{
        $this->db->update('perusahaan' , array('id_perusahaan'=> $this->session->userdata('id_perusahaan')  , 'pembayaran_kredit' => 'true'));
    }

    $this->session->set_flashdata('notif' , true);
    $this->session->set_flashdata('teks_notif' , "Skema Pembiayaan Berhasil di Update");


    redirect(base_url() . "perusahaan/skema_pembiayaan");

}

function profil()
{
    $data['lang'] = $this->Website->lang($this->session->userdata('lang')); 
    $data['medsos'] = $this->M_perusahaan->tampil_media_sosial();

    $data['perusahaan'] = $this->M_perusahaan->profil_perusahaan();
    $data['medsos'] = $this->M_perusahaan->profil_medsos();
    $data['produk'] = $this->M_perusahaan->profil_produk();
    $data['teknisi'] = $this->M_perusahaan->profil_teknisi();


    if ($this->session->userdata('jenis_perusahaan') == 'komersial') {

        $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
    }elseif ($this->session->userdata('jenis_perusahaan') =='individu') {
        $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header_1', $data);
    }
    $this->load->view('frontend/perusahaan/profil');
    $this->load->view('frontend/perusahaan/footer');
}
function rekening()
{
    $data['lang'] = $this->Website->lang($this->session->userdata('lang')); 
    $data['medsos'] = $this->M_perusahaan->tampil_media_sosial();

    $data['perusahaan'] = $this->M_perusahaan->profil_perusahaan();
    $data['medsos'] = $this->M_perusahaan->profil_medsos();
    $data['produk'] = $this->M_perusahaan->profil_produk();
    $data['teknisi'] = $this->M_perusahaan->profil_teknisi();


    if ($this->session->userdata('jenis_perusahaan') == 'komersial') {

        $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
    }elseif ($this->session->userdata('jenis_perusahaan') =='individu') {
        $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header_1', $data);
    }
    $this->load->view('frontend/perusahaan/rekening');
    $this->load->view('frontend/perusahaan/footer');
}
 function update_rekening()
    {
        $nama_bank=$this->input->post('nama_bank', TRUE);
        $pemilik_rekening=$this->input->post('pemilik_rekening', TRUE);
        $no_rekening=$this->input->post('no_rekening', TRUE);

        $this->db->where('id_perusahaan' , $this->session->userdata('id_perusahaan'));
        $this->db->update('perusahaan' , array('nama_bank' => $nama_bank,'pemilik_rekening'=>$pemilik_rekening,'no_rekening'=>$no_rekening));

         $this->session->set_flashdata('notif' , true);
        $this->session->set_flashdata('teks_notif' , "Rekening berhasil disimpan");
        redirect(base_url().'perusahaan/rekening');
    }
function ubah_profil()
{
    $data['provinsi'] = $this->M_perusahaan->tampil_provinsi();
    $data['perusahaan'] = $this->M_perusahaan->profil_perusahaan();


    if ($this->session->userdata('jenis_perusahaan') == 'komersial') {

        $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
    }elseif ($this->session->userdata('jenis_perusahaan') =='individu') {
        $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header_1', $data);
    }
    $this->load->view('frontend/perusahaan/profil_form');
    $this->load->view('frontend/perusahaan/footer');
}
function simpan_update_profil()
{
    $get_perusahaan=$this->db->get_where('perusahaan', array('id_perusahaan'=>$this->session->userdata('id_perusahaan')))->row();
    $namaPerusahaan = $this->input->post('namaPerusahaan');
    $taglinePerusahaan = $this->input->post('taglinePerusahaan');
    $alamatPerusahaan = $this->input->post('alamatPerusahaan');
    $kelurahanPerusahaan = str_replace("_", " ", $this->input->post('kelurahanPerusahaan'));
    $kecamatanPerusahaan = str_replace("_", " ", $this->input->post('kecamatanPerusahaan'));
    $kabupatenPerusahaan = str_replace("_", " ", $this->input->post('kabupatenPerusahaan'));
    $provinsiPerusahaan = str_replace("_", " ", $this->input->post('provinsiPerusahaan'));
    $posPerusahaan = $this->input->post('posPerusahaan');
    $latitudePerusahaan = $this->input->post('latitudePerusahaan');
    $longitudePerusahaan = $this->input->post('longitudePerusahaan');
    $deskripsiPerusahaan = $this->input->post('deskripsiPerusahaan');
    $jenisPerusahaan = $this->input->post('jenisPerusahaan');
    $get_perusahaan->jenis_perusahaan;
    if ($jenisPerusahaan == 'individu') {
        $data =array(
            'nama_perusahaan' => $namaPerusahaan,
            'tagline' => $taglinePerusahaan,
            'alamat_perusahaan' => $alamatPerusahaan,
            'kelurahan_perusahaan' => $kelurahanPerusahaan,
            'kecamatan_perusahaan' => $kecamatanPerusahaan,
            'kabupaten_perusahaan' => $kabupatenPerusahaan,
            'provinsi_perusahaan' => $provinsiPerusahaan,
            'pos_perusahaan' => $posPerusahaan,
            'latitude' => $latitudePerusahaan,
            'longitude' => $longitudePerusahaan,
            'deskripsi' => $deskripsiPerusahaan,
            'jenis_perusahaan' => $jenisPerusahaan,
        );
    }elseif ($jenisPerusahaan == 'komersial') {
            if($jenisPerusahaan==$get_perusahaan->jenis_perusahaan)
            {
               $statusPer='aktiv';
            }else{
               $statusPer='menunggu_verifikasi';
            }
            $data =array(
                'nama_perusahaan' => $namaPerusahaan,
                'tagline' => $taglinePerusahaan,
                'alamat_perusahaan' => $alamatPerusahaan,
                'kelurahan_perusahaan' => $kelurahanPerusahaan,
                'kecamatan_perusahaan' => $kecamatanPerusahaan,
                'kabupaten_perusahaan' => $kabupatenPerusahaan,
                'provinsi_perusahaan' => $provinsiPerusahaan,
                'pos_perusahaan' => $posPerusahaan,
                'latitude' => $latitudePerusahaan,
                'longitude' => $longitudePerusahaan,
                'deskripsi' => $deskripsiPerusahaan,
                'jenis_perusahaan' => $jenisPerusahaan,
                'status_perusahaan' => $statusPer
            );
        }

    $this->db->where('id_perusahaan' , $this->session->userdata('id_perusahaan'));
    $this->db->update('perusahaan' , $data);
    if ($this->db->affected_rows() > 0){
        $this->session->set_userdata('nama_perusahaan', $namaPerusahaan);
        $this->session->set_userdata('tagline', $taglinePerusahaan);
        $this->session->set_userdata('alamat_perusahaan', $alamatPerusahaan);
        $this->session->set_userdata('kelurahan_perusahaan', $kelurahanPerusahaan);
        $this->session->set_userdata('kecamatan_perusahaan', $kecamatanPerusahaan);
        $this->session->set_userdata('kabupaten_perusahaan', str_replace("_", " ", $this->input->post('kabupatenPerusahaan')));
        $this->session->set_userdata('provinsi_perusahaan', $provinsiPerusahaan);
        $this->session->set_userdata('pos_perusahaan', $posPerusahaan);
        $this->session->set_userdata('latitude', $latitudePerusahaan);
        $this->session->set_userdata('longitude', $longitudePerusahaan);
        $this->session->set_userdata('deskripsi', $deskripsiPerusahaan);
        $this->session->set_userdata('jenis_perusahaan', $jenisPerusahaan);

        $this->session->set_flashdata('notif' , true);
        $this->session->set_flashdata('teks_notif' , "Profil berhasil diupdate");
        redirect(base_url()."perusahaan/profil");
    }else{
        $this->session->set_flashdata('notif' , false);
        $this->session->set_flashdata('teks_notif' , "Profil gagal diupdate");
        redirect(base_url()."perusahaan/profil");
    }

}
function simpan_update_banner()
{
    unlink('./upload_file/'.$this->session->userdata('folder').'/img/perusahaan/bannerPerusahaan.png');
    $_FILES["bannerPerusahaan"]["name"];

    $config1['upload_path'] = './upload_file/'.$this->session->userdata('folder').'/img/perusahaan/';
    $config1['allowed_types'] = 'jpg|jpeg|png|gif|bmp';
    $config1['file_name'] = 'bannerPerusahaan.png';
    $this->upload->initialize($config1);
    $this->upload->do_upload('bannerPerusahaan');
    $data = $this->upload->data();
        //Compress Image
    $config1['image_library']='gd2';
    $config1['source_image']='./upload_file/'.$this->session->userdata('folder').'/img/perusahaan/'.$data['file_name'];
    $config1['create_thumb']= FALSE;
    $config1['maintain_ratio']= TRUE;
    $config1['quality']= '100%';
    $config1['width']= 720;
    $config1['height']= 300;
    $config1['new_image']= './upload_file/'.$this->session->userdata('folder').'/img/perusahaan/'.$data['file_name'];
    $this->load->library('image_lib', $config1);
    $this->image_lib->resize();

    $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
    $this->output->set_header('Pragma: no-cache');

    $this->session->set_flashdata('notif' , true);
    $this->session->set_flashdata('teks_notif' , "Banner berhasil diupdate");
    redirect(base_url()."perusahaan/profil");

}
function simpan_update_logo()
{
    unlink('./upload_file/'.$this->session->userdata('folder').'/img/perusahaan/logoPerusahaan.png');

    $_FILES["logoPerusahaan"]["name"];

    $config['upload_path'] = './upload_file/'.$this->session->userdata('folder').'/img/perusahaan/';
    $config['allowed_types'] = 'jpg|jpeg|png|gif|bmp';
    $config['file_name'] = 'logoPerusahaan.png';
    $this->upload->initialize($config);
    $this->upload->do_upload('logoPerusahaan');
    $data = $this->upload->data();
        //Compress Image
    $config['image_library']='gd2';
    $config['source_image']='./upload_file/'.$this->session->userdata('folder').'/img/perusahaan/'.$data['file_name'];
    $config['create_thumb']= FALSE;
    $config['maintain_ratio']= TRUE;
    $config['quality']= '100%';
        //$config['width']= 720;
        //$config['height']= 300;
    $config['new_image']= './upload_file/'.$this->session->userdata('folder').'/img/perusahaan/'.$data['file_name'];
    $this->load->library('image_lib', $config);
    $this->image_lib->resize();

    $this->session->set_flashdata('notif' , true);
    $this->session->set_flashdata('teks_notif' , "Logo berhasil diupdate");
    redirect(base_url()."perusahaan/profil");
}

function lelang_berlangsung()
{
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();
        $data['bidding'] = $this->M_perusahaan->lelang_berlangsung();
        $data['kabupaten'] = $this->M_perusahaan->tampilkan_kota();
        $data['provinsi'] = $this->M_perusahaan->tampilkan_provinsi();

        if ($this->session->userdata('jenis_perusahaan') =='individu') {
            redirect(base_url().'user','refresh');
        }
        $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        $this->load->view('frontend/perusahaan/bidding_berlangsung');
        $this->load->view('frontend/perusahaan/footer');
    }
    function ajukan_penawaran($id=null)
    {
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();
        $data['id']=$id;
        if ($this->session->userdata('jenis_perusahaan') =='individu') {
            redirect(base_url().'user','refresh');
        }
        $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        $this->load->view('frontend/perusahaan/bidding_form');
        $this->load->view('frontend/perusahaan/footer');
    }
    function daftar_penawaran()
    {
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();
        $data['bidding'] = $this->M_perusahaan->lelang_ajukan();
        if ($this->session->userdata('jenis_perusahaan') =='individu') {
            redirect(base_url().'user','refresh');
        }
        $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        $this->load->view('frontend/perusahaan/bidding_ajukan');
        $this->load->view('frontend/perusahaan/footer');
    }
    function ubah_harga_bidding_take()
    {
        $id_bidding_take=$this->input->post('id_bidding_take', TRUE);
        $harga=$this->input->post('harga', TRUE);

        $this->db->where('id_bidding_take' , $id_bidding_take);
        $this->db->update('bidding_take' , array('harga' => $harga));

         $this->session->set_flashdata('notif' , true);
        $this->session->set_flashdata('teks_notif' , "Harga diubah");
        redirect(base_url().'perusahaan/daftar_penawaran');
    }
    function penawaran_diproses()
    {
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();
        $data['bidding'] = $this->M_perusahaan->lelang_diproses();
        if ($this->session->userdata('jenis_perusahaan') =='individu') {
            redirect(base_url().'user','refresh');
        }
        $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        $this->load->view('frontend/perusahaan/bidding_diproses');
        $this->load->view('frontend/perusahaan/footer');
    }
    function lelang_dikerjakan($id_bidding)
    {
        $this->db->where('id_bidding' , $id_bidding);
        $this->db->update('bidding' , array('status_bidding' => 'dikerjakan'));
       
        redirect(base_url()."perusahaan/penawaran_diproses");
       
    }
    function penawaran_dikerjakan()
    {
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();
        $data['bidding'] = $this->M_perusahaan->lelang_dikerjakan();
        if ($this->session->userdata('jenis_perusahaan') =='individu') {
            redirect(base_url().'user','refresh');
        }
        $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        $this->load->view('frontend/perusahaan/bidding_dikerjakan');
        $this->load->view('frontend/perusahaan/footer');
    }
       function lelang_selesai()
    {

        $id_bidding = $this->input->post('id_bidding',TRUE);

        $this->db->where('id_bidding' , $id_bidding);
        $this->db->update('bidding' , array('status_bidding' => 'selesai','tanggal_selesai'=>date('Y-m-d')));


        $data2 = array(
            'id_bidding' => $id_bidding,
            'status_bukti'=> 'menunggu_verifikasi',
            'input_bukti' => date("Y-m-d")
        );
        $this->db->insert('bidding_bukti' , $data2);

         mkdir('./upload_file/bukti/lelang/'.$id_bidding);

        $filesCount = count($_FILES['bukti']['name']);
          for($i = 0; $i < $filesCount; $i++){
          
            $_FILES['file']['name']     = $_FILES['bukti']['name'][$i];
            $_FILES['file']['type']     = $_FILES['bukti']['type'][$i];
            $_FILES['file']['tmp_name'] = $_FILES['bukti']['tmp_name'][$i];
            $_FILES['file']['error']     = $_FILES['bukti']['error'][$i];
            $_FILES['file']['size']     = $_FILES['bukti']['size'][$i];

                // File upload configuration
            $config['upload_path'] = './upload_file/bukti/lelang/'.$id_bidding.'/';

            $config['allowed_types'] = 'jpg|jpeg|png|gif|bmp';
            $config['create_thumb']= FALSE;
            $config['maintain_ratio']= TRUE;
            $config['quality']= '100%';

            $this->load->library('upload', $config);
            $this->upload->initialize($config);

            if($this->upload->do_upload('file')){
                $fileData = $this->upload->data();
                $uploadData[$i]['file_name'] = $fileData['file_name'];
                $uploadData[$i]['uploaded_on'] = date("Y-m-d H:i:s");
            }
        }

       
        redirect(base_url()."perusahaan/penawaran_dikerjakan");
       
    }
    function bukti_lelang()
    {
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();
        $data['bidding'] = $this->M_perusahaan->bukti_lelang();
        if ($this->session->userdata('jenis_perusahaan') =='individu') {
            redirect(base_url().'user','refresh');
        }
        $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        $this->load->view('frontend/perusahaan/bidding_bukti');
        $this->load->view('frontend/perusahaan/footer');
    }
      function upload_bukti_lelang()
    {

        $id_bidding = $this->input->post('id_bidding',TRUE);

        $this->db->where('id_bidding' , $id_bidding);
        $this->db->update('bidding_bukti' , array('status_bukti' => 'menunggu_verifikasi'));

        
            $files = glob('upload_file/bukti/lelang/'.$id_bidding.'/*'); //get all file names
            foreach($files as $file){
                if(is_file($file))
                unlink($file); //delete file
            }
        

        $filesCount = count($_FILES['bukti']['name']);
          for($i = 0; $i < $filesCount; $i++){
          
            $_FILES['file']['name']     = $_FILES['bukti']['name'][$i];
            $_FILES['file']['type']     = $_FILES['bukti']['type'][$i];
            $_FILES['file']['tmp_name'] = $_FILES['bukti']['tmp_name'][$i];
            $_FILES['file']['error']     = $_FILES['bukti']['error'][$i];
            $_FILES['file']['size']     = $_FILES['bukti']['size'][$i];

                // File upload configuration
            $config['upload_path'] = './upload_file/bukti/lelang/'.$id_bidding.'/';

            $config['allowed_types'] = 'jpg|jpeg|png|gif|bmp';
            $config['create_thumb']= FALSE;
            $config['maintain_ratio']= TRUE;
            $config['quality']= '100%';

            $this->load->library('upload', $config);
            $this->upload->initialize($config);

            if($this->upload->do_upload('file')){
                $fileData = $this->upload->data();
                $uploadData[$i]['file_name'] = $fileData['file_name'];
                $uploadData[$i]['uploaded_on'] = date("Y-m-d H:i:s");
            }
        }

       
        redirect(base_url()."perusahaan/bukti_lelang");
       
    }
    function riwayat_lelang()
    {
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();
        $data['bidding'] = $this->M_perusahaan->riwayat_lelang();
        if ($this->session->userdata('jenis_perusahaan') =='individu') {
            redirect(base_url().'user','refresh');
        }
        $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        $this->load->view('frontend/perusahaan/bidding_riwayat');
        $this->load->view('frontend/perusahaan/footer');
    }
    function bukti_transfer_lelang()
    {
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();
        $data['transfer'] = $this->M_perusahaan->tampil_transfer_lelang();
        if ($this->session->userdata('jenis_perusahaan') =='individu') {
            redirect(base_url().'user','refresh');
        }
        $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        $this->load->view('frontend/perusahaan/bidding_transfer');
        $this->load->view('frontend/perusahaan/footer');
    }
    function simpan_ajukan()
    {
        $harga = $this->input->post('harga',TRUE);
        $keterangan = $this->input->post('keterangan',TRUE);
        $id_bidding = $this->input->post('id',TRUE);
        $get_bidding=$this->db->get_where('bidding', array('id_bidding'=>$id_bidding))->row();
        $link=$get_bidding->link_dokumen;

        $new_name = $this->session->userdata('id_perusahaan').'_EPC_'.date("d").''.date("m").''.date("y").''.date("H").''.date("i").''.date("s").'_'.substr($_FILES["dokumen"]["name"], -7);

        
        if ($this->M_perusahaan->simpan_ajukan($id_bidding, $harga, $keterangan, $link, $new_name) == TRUE) {

            $_FILES["dokumen"]["name"];

            $config['upload_path'] = './'.$link;
            $config['allowed_types'] = 'pdf|jpeg|jpg|png|docx';
            $config['file_name'] = $new_name;
            $this->upload->initialize($config);
            $this->upload->do_upload('dokumen');
            $data = $this->upload->data();
                    //Compress Image
            $config['image_library']='gd2';
            $config['source_image']='./'.$link.'/'.$data['file_name'];
            $config['create_thumb']= FALSE;
            $config['maintain_ratio']= TRUE;
            $config['quality']= '100%';
                    //$config['width']= 720;
                    //$config['height']= 300;
            $config['new_image']= './'.$link.'/'.$data['file_name'];
            $this->load->library('image_lib', $config);
            $this->image_lib->resize();

        }

        $this->session->set_flashdata('notif' , true);
        $this->session->set_flashdata('teks_notif' , "Berhasil diajukan ".$notif_session);
        redirect(base_url() . "perusahaan/lelang_berlangsung");
    }
     function batal_ajukan($id_bidding_take)
    {
       
        $get_bidding_take=$this->db->get_where('bidding_take', array('id_bidding_take'=>$id_bidding_take))->row();
       
        unlink('./'.$get_bidding_take->link.'/'.$get_bidding_take->dokumen);
        $this->db->where('id_bidding_take' , $id_bidding_take);
        $this->db->delete('bidding_take');

        $this->session->set_flashdata('notif' , true);
        $this->session->set_flashdata('teks_notif' , "Batal Diajukan ".$notif_session);
        redirect(base_url() . "perusahaan/daftar_penawaran");
    }
    function filter_lelang()
    {

        $nama_bidding = $this->input->post('nama_bidding'); 
        $lokasi_area = $this->input->post('lokasi_area');
        $kategori = $this->input->post('kategori');   
        $harga = $this->input->post('harga');      
        $ukuran_sistem = $this->input->post('ukuran_sistem');   

        $areaArray = $this->input->post('lokasi_area');
        if (!empty($areaArray)) {
            $this->db->select("*");
            $this->db->where_in('lokasi', $areaArray);
            $this->db->group_by('id_bidding');
            $data_area= $this->db->get('bidding_area')->result_array();

            if (count($data_area) > 0)
            {
                foreach ($data_area as $key => $valueAO) {
                  $area[] = $valueAO['id_bidding'];
              }
          }else{
            $area ='cc';
        }
    }else{
        $area ='';
    }   

    $bidding = $this->M_perusahaan->filter_lelang($nama_bidding,$kategori,$area, $harga, $ukuran_sistem);


    $hasil = $this->load->view('frontend/perusahaan/bidding_filter', array('bidding'=>$bidding,'nama_bidding'=>$nama_bidding), true);
        //$hasil= implode(",",$area);
    $callback = array(
          'hasil' => $hasil // Set array hasil dengan isi dari view.php yang diload tadi
      );
        echo json_encode($callback); // konversi varibael $callback menjadi JSON

    }
    function reset_filter()
    {

        $nama_bidding = $this->input->post('nama_bidding');        

        $bidding = $this->M_perusahaan->reset_filter($nama_bidding);


        $hasil = $this->load->view('frontend/perusahaan/bidding_filter', array('bidding'=>$bidding,'nama_bidding'=>$nama_bidding), true);

        $callback = array(
          'hasil' => $hasil // Set array hasil dengan isi dari view.php yang diload tadi
      );
        echo json_encode($callback); // konversi varibael $callback menjadi JSON

    }

    function eksport_pdf($jenis_eks=null)
    {

        $this->load->library('pdf');
        $this->pdf->setPaper('A4', 'landscape');
        $this->pdf->filename = date("d-m-Y")."-".$jenis_eks.".pdf";
       // $this->pdf->load_view('frontend/perusahaan/eksport_produk');
        
        if ($jenis_eks=='produk') {
            $get_produk=$this->db->get_where('perusahaan_produk',array('id_perusahaan'=>$this->session->userdata('id_perusahaan'),'status_hapus'=>'false'))->result_array();
            $this->pdf->load_view('frontend/perusahaan/eksport_produk',array('produk'=>$get_produk),true);
        }elseif ($jenis_eks=='teknisi') {
            $get_teknisi=$this->db->get_where('perusahaan_pemasang',array('id_perusahaan'=>$this->session->userdata('id_perusahaan'),'status_hapus_pemasang'=>'false'))->result_array();
            $this->pdf->load_view('frontend/perusahaan/eksport_teknisi',array('teknisi'=>$get_teknisi),true);
        }elseif ($jenis_eks=='pembelian') {
            $data=$this->M_perusahaan->ekspor_pdf_pembelian();
            $this->pdf->load_view('frontend/perusahaan/eksport_pembelian', array('pembelian'=>$data), true);
        }elseif ($jenis_eks=='pengiriman') {
            $data=$this->M_perusahaan->ekspor_pdf_pengiriman();
            $this->pdf->load_view('frontend/perusahaan/eksport_pengiriman',array('pengiriman'=>$data), true);
        }

    }
    function eksport_csv($jenis_eks=null)
    {

        // Load plugin PHPExcel nya
        include APPPATH.'libraries/PHPExcel/PHPExcel.php';
         $csv = new PHPExcel();
             // Settingan awal fil excel
            $csv->getProperties()->setCreator('Solarhub')
            ->setLastModifiedBy('Solarhub')
            ->setTitle("Data")
            ->setSubject("EPC")
            ->setDescription("Laporan Data EPC")
            ->setKeywords("Data EPC");
                // Panggil class PHPExcel nya
       
        if ($jenis_eks=='produk') {
                // Buat header tabel nya pada baris ke 1

            $csv->setActiveSheetIndex(0)->setCellValue('A1', "NO");
            $csv->setActiveSheetIndex(0)->setCellValue('B1', "NAMA PRODUK"); 
            $csv->setActiveSheetIndex(0)->setCellValue('C1', "KATEGORI");
            $csv->setActiveSheetIndex(0)->setCellValue('D1', "UKURAN SISTEM");
            $csv->setActiveSheetIndex(0)->setCellValue('E1', "SOLARPANEL");
            $csv->setActiveSheetIndex(0)->setCellValue('F1', "INVERTER"); 
            $csv->setActiveSheetIndex(0)->setCellValue('G1', "ACCESSORIES");
            $csv->setActiveSheetIndex(0)->setCellValue('H1', "OPERASI & MAINTENANCE");
            $csv->setActiveSheetIndex(0)->setCellValue('I1', "PENGAJUAN PLN");
            $csv->setActiveSheetIndex(0)->setCellValue('J1', "HARGA");
            $csv->setActiveSheetIndex(0)->setCellValue('K1', "GARANSI");
            $csv->setActiveSheetIndex(0)->setCellValue('L1', "DIINPUT");
            $get_produk=$this->db->get_where('perusahaan_produk',array('id_perusahaan'=>$this->session->userdata('id_perusahaan'),'status_hapus'=>'false'))->result();
                $no = 1; // Untuk penomoran tabel, di awal set dengan 1
                $numrow = 2; // Set baris pertama untuk isi tabel adalah baris ke 2
                foreach($get_produk as $data){ // Lakukan looping pada variabel siswa
                  $csv->setActiveSheetIndex(0)->setCellValue('A'.$numrow, $no);
                  $csv->setActiveSheetIndex(0)->setCellValue('B'.$numrow, $data->nama_produk);
                  $csv->setActiveSheetIndex(0)->setCellValue('C'.$numrow, $data->kategori);
                  $csv->setActiveSheetIndex(0)->setCellValue('D'.$numrow, $data->ukuran_sistem);
                  $csv->setActiveSheetIndex(0)->setCellValue('E'.$numrow, $data->solarpanel);
                  $csv->setActiveSheetIndex(0)->setCellValue('F'.$numrow, $data->inverter);
                  $csv->setActiveSheetIndex(0)->setCellValue('G'.$numrow, $data->accessories);
                  $csv->setActiveSheetIndex(0)->setCellValue('H'.$numrow, $data->operation);
                  $csv->setActiveSheetIndex(0)->setCellValue('I'.$numrow, $data->pengajuan_pln);
                  $csv->setActiveSheetIndex(0)->setCellValue('J'.$numrow, number_format($data->harga,2,'.',','));
                  $csv->setActiveSheetIndex(0)->setCellValue('K'.$numrow, $data->garansi);
                  $csv->setActiveSheetIndex(0)->setCellValue('L'.$numrow, $data->input_produk);
                  
                  $no++; // Tambah 1 setiap kali looping
                  $numrow++; // Tambah 1 setiap kali looping
              }
                // Set orientasi kertas jadi LANDSCAPE
              $csv->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);
                // Set judul file excel nya
              $csv->getActiveSheet(0)->setTitle("Laporan Solarhub");
              $csv->setActiveSheetIndex(0);
                // Proses file excel
              header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                header('Content-Disposition: attachment; filename="Solarhub_'.$this->session->userdata('nama_perusahaan').'_produk_'.date("d-m-Y_H:i:s").'.csv"'); // Set nama file excel nya
                header('Cache-Control: max-age=0');
                $write = new PHPExcel_Writer_CSV($csv);
                $write->save('php://output');


            }elseif ($jenis_eks=='teknisi') {
               
                $csv->setActiveSheetIndex(0)->setCellValue('A1', "NO");
                $csv->setActiveSheetIndex(0)->setCellValue('B1', "NAMA TEKNISI"); 
                $csv->setActiveSheetIndex(0)->setCellValue('C1', "JENIS KELAMIN");
                $csv->setActiveSheetIndex(0)->setCellValue('D1', "TANGGAL LAHIR");
                $csv->setActiveSheetIndex(0)->setCellValue('E1', "ALAMAT");
                $csv->setActiveSheetIndex(0)->setCellValue('F1', "KECAMATAN"); 
                $csv->setActiveSheetIndex(0)->setCellValue('G1', "KABUPATEN");
                $csv->setActiveSheetIndex(0)->setCellValue('H1', "PROVINSI");
                $csv->setActiveSheetIndex(0)->setCellValue('I1', "POS");
               // $csv->setActiveSheetIndex(0)->setCellValue('J1', "KEAHLIAN");
                $csv->setActiveSheetIndex(0)->setCellValue('J1', "HARGA");
                $csv->setActiveSheetIndex(0)->setCellValue('K1', "DIINPUT");
                 $get_teknisi=$this->db->get_where('perusahaan_pemasang',array('id_perusahaan'=>$this->session->userdata('id_perusahaan'),'status_hapus_pemasang'=>'false'))->result();
                    $no = 1; // Untuk penomoran tabel, di awal set dengan 1
                    $numrow = 2; // Set baris pertama untuk isi tabel adalah baris ke 2
                    foreach($get_teknisi as $data){ // Lakukan looping pada variabel siswa
                        $get_keahlian=$this->db->get_where('pemasang_keahlian',array('id_pemasang'=>$data->id_pemasang))->result();
                        foreach ($get_keahlian as $key => $valueAh) {
                            $keahlian[]=$valueAh->keahlian;
                        }
                      $csv->setActiveSheetIndex(0)->setCellValue('A'.$numrow, $no);
                      $csv->setActiveSheetIndex(0)->setCellValue('B'.$numrow, $data->nama_pemasang);
                      $csv->setActiveSheetIndex(0)->setCellValue('C'.$numrow, $data->jenis_kelamin);
                      $csv->setActiveSheetIndex(0)->setCellValue('D'.$numrow, $data->tanggal_lahir_pemasang);
                      $csv->setActiveSheetIndex(0)->setCellValue('E'.$numrow, $data->alamat_pemasang.'  '.$data->desa_pemasang);
                      $csv->setActiveSheetIndex(0)->setCellValue('F'.$numrow, $data->kecamatan_pemasang);
                      $csv->setActiveSheetIndex(0)->setCellValue('G'.$numrow, $data->kabupaten_pemasang);
                      $csv->setActiveSheetIndex(0)->setCellValue('H'.$numrow, $data->provinsi_pemasang);
                      $csv->setActiveSheetIndex(0)->setCellValue('I'.$numrow, $data->kodepos_pemasang);
                     // $csv->setActiveSheetIndex(0)->setCellValue('J'.$numrow, implode(", ", $keahlian));
                      $csv->setActiveSheetIndex(0)->setCellValue('J'.$numrow, number_format($data->harga_pemasang,2,'.',','));
                      $csv->setActiveSheetIndex(0)->setCellValue('K'.$numrow, $data->input_pemasang);
                      
                      $no++; // Tambah 1 setiap kali looping
                      $numrow++; // Tambah 1 setiap kali looping
                  }
                    // Set orientasi kertas jadi LANDSCAPE
                  $csv->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);
                    // Set judul file excel nya
                  $csv->getActiveSheet(0)->setTitle("Laporan Solarhub");
                  $csv->setActiveSheetIndex(0);
                    // Proses file excel
                  header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                    header('Content-Disposition: attachment; filename="Solarhub_'.$this->session->userdata('nama_perusahaan').'_teknisi_'.date("d-m-Y_H:i:s").'.csv"'); // Set nama file excel nya
                    header('Cache-Control: max-age=0');
                    $write = new PHPExcel_Writer_CSV($csv);
                    $write->save('php://output');


            }elseif ($jenis_eks=='pembelian') {
               
                $csv->setActiveSheetIndex(0)->setCellValue('A1', "NO");
                $csv->setActiveSheetIndex(0)->setCellValue('B1', "NOMOR INVOICE"); 
                $csv->setActiveSheetIndex(0)->setCellValue('C1', "PRODUK");
                $csv->setActiveSheetIndex(0)->setCellValue('D1', "HARGA");
                $csv->setActiveSheetIndex(0)->setCellValue('E1', "JUMLAH");
                $csv->setActiveSheetIndex(0)->setCellValue('F1', "SUBTOTAL"); 
                $csv->setActiveSheetIndex(0)->setCellValue('G1', "PENERIMA");
                $csv->setActiveSheetIndex(0)->setCellValue('H1', "ALAMAT");
                $csv->setActiveSheetIndex(0)->setCellValue('I1', "TANGGAL PEMBELIAN");
                 $data=$this->M_perusahaan->ekspor_csv_pembelian();
                    $no = 1; // Untuk penomoran tabel, di awal set dengan 1
                    $numrow = 2; // Set baris pertama untuk isi tabel adalah baris ke 2
                    foreach($data as $data){ // Lakukan looping pada variabel siswa

                       
                      $csv->setActiveSheetIndex(0)->setCellValue('A'.$numrow, $no);
                      $csv->setActiveSheetIndex(0)->setCellValue('B'.$numrow, $data->no_invoice);
                      $csv->setActiveSheetIndex(0)->setCellValue('C'.$numrow, $data->nama_produk);
                      $csv->setActiveSheetIndex(0)->setCellValue('D'.$numrow, number_format($data->harga,2,'.',','));
                      $csv->setActiveSheetIndex(0)->setCellValue('E'.$numrow, $data->jumlah);
                      $csv->setActiveSheetIndex(0)->setCellValue('F'.$numrow, number_format($data->harga*$data->jumlah,2,'.',','));
                      $csv->setActiveSheetIndex(0)->setCellValue('G'.$numrow, $data->nama_penerima);
                      $csv->setActiveSheetIndex(0)->setCellValue('H'.$numrow, $data->alamat_penerima.' '.$data->kecamatan_penerima.' '.$data->kabupaten_penerima.' '.$data->provinsi_penerima);
                      $csv->setActiveSheetIndex(0)->setCellValue('I'.$numrow, $data->input_order);
                      
                      $no++; // Tambah 1 setiap kali looping
                      $numrow++; // Tambah 1 setiap kali looping
                  }
                    // Set orientasi kertas jadi LANDSCAPE
                  $csv->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);
                    // Set judul file excel nya
                  $csv->getActiveSheet(0)->setTitle("Laporan Solarhub");
                  $csv->setActiveSheetIndex(0);
                    // Proses file excel
                  header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                    header('Content-Disposition: attachment; filename="Solarhub_'.$this->session->userdata('nama_perusahaan').'_pembelian_'.date("d-m-Y_H:i:s").'.csv"'); // Set nama file excel nya
                    header('Cache-Control: max-age=0');
                    $write = new PHPExcel_Writer_CSV($csv);
                    $write->save('php://output');



            }elseif ($jenis_eks=='pengiriman') {
                               
                $csv->setActiveSheetIndex(0)->setCellValue('A1', "NO");
                $csv->setActiveSheetIndex(0)->setCellValue('B1', "NOMOR INVOICE"); 
                $csv->setActiveSheetIndex(0)->setCellValue('C1', "PRODUK");
                $csv->setActiveSheetIndex(0)->setCellValue('D1', "HARGA");
                $csv->setActiveSheetIndex(0)->setCellValue('E1', "JUMLAH");
                $csv->setActiveSheetIndex(0)->setCellValue('F1', "SUBTOTAL"); 
                $csv->setActiveSheetIndex(0)->setCellValue('G1', "PENERIMA");
                $csv->setActiveSheetIndex(0)->setCellValue('H1', "ALAMAT");
                $csv->setActiveSheetIndex(0)->setCellValue('I1', "PEMBELIAN");
                //$csv->setActiveSheetIndex(0)->setCellValue('J1', "SELESAI");
                  $data=$this->M_perusahaan->ekspor_csv_pengiriman();
                    $no = 1; // Untuk penomoran tabel, di awal set dengan 1
                    $numrow = 2; // Set baris pertama untuk isi tabel adalah baris ke 2
                    foreach($data as $data){ // Lakukan looping pada variabel siswa

                      $csv->setActiveSheetIndex(0)->setCellValue('A'.$numrow, $no);
                      $csv->setActiveSheetIndex(0)->setCellValue('B'.$numrow, $data->no_invoice);
                      $csv->setActiveSheetIndex(0)->setCellValue('C'.$numrow, $data->nama_produk);
                      $csv->setActiveSheetIndex(0)->setCellValue('D'.$numrow, number_format($data->harga,2,'.',','));
                      $csv->setActiveSheetIndex(0)->setCellValue('E'.$numrow, $data->jumlah);
                      $csv->setActiveSheetIndex(0)->setCellValue('F'.$numrow, number_format($data->harga*$data->jumlah,2,'.',','));
                      $csv->setActiveSheetIndex(0)->setCellValue('G'.$numrow, $data->nama_penerima);
                      $csv->setActiveSheetIndex(0)->setCellValue('H'.$numrow, $data->alamat_penerima.' '.$data->kecamatan_penerima.' '.$data->kabupaten_penerima.' '.$data->provinsi_penerima);
                      $csv->setActiveSheetIndex(0)->setCellValue('I'.$numrow, $data->input_order);
                      //$csv->setActiveSheetIndex(0)->setCellValue('J'.$numrow, $data->tanggal_selesai);
                      
                      $no++; // Tambah 1 setiap kali looping
                      $numrow++; // Tambah 1 setiap kali looping
                  }
                    // Set orientasi kertas jadi LANDSCAPE
                  $csv->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);
                    // Set judul file excel nya
                  $csv->getActiveSheet(0)->setTitle("Laporan Solarhub");
                  $csv->setActiveSheetIndex(0);
                    // Proses file excel
                  header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                    header('Content-Disposition: attachment; filename="Solarhub_'.$this->session->userdata('nama_perusahaan').'_pengriman_'.date("d-m-Y_H:i:s").'.csv"'); // Set nama file excel nya
                    header('Cache-Control: max-age=0');
                    $write = new PHPExcel_Writer_CSV($csv);
                    $write->save('php://output');

            }

        }
        function pdf($jenis_eks=null)
        {


            if ($jenis_eks=='produk') {
                $this->load->view('frontend/perusahaan/eksport_produk');
            }elseif ($jenis_eks=='teknisi') {
             $this->load->view('frontend/perusahaan/eksport_teknisi');
         }elseif ($jenis_eks=='pembelian') {
             $this->load->view('frontend/perusahaan/eksport_pembelian');
         }elseif ($jenis_eks=='pengiriman') {
             $this->load->view('frontend/perusahaan/eksport_pengiriman');
         }


     }
    function daftar_iklan()
    {
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();
        if ($this->session->userdata('jenis_perusahaan') =='individu') {
            redirect(base_url().'user','refresh');
        }
        $data['iklan']=$this->M_perusahaan->tampil_iklan();
        $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        $this->load->view('frontend/perusahaan/iklan_daftar');
        $this->load->view('frontend/perusahaan/footer');
    }
     function riwayat_iklan()
    {
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();
        if ($this->session->userdata('jenis_perusahaan') =='individu') {
            redirect(base_url().'user','refresh');
        }
        $data['iklan']=$this->M_perusahaan->riwayat_iklan();
        $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        $this->load->view('frontend/perusahaan/iklan_riwayat');
        $this->load->view('frontend/perusahaan/footer');
    }
      public function tambah_iklan_backup()
    {
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();
        $data['paket_iklan']=$this->M_perusahaan->tampil_paket_iklan();
        $data['tanggal_min'] = $this->M_perusahaan->tanggal_min_form();
        $data['tanggal_iklan'] = $this->M_perusahaan->tanggal_iklan();
        $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        $this->load->view('frontend/perusahaan/iklan_form');
        $this->load->view('frontend/perusahaan/footer');
    }
    public function tambah_iklan()
    {
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();
        $data['paket_iklan']=$this->M_perusahaan->tampil_paket_iklan();
        $data['tanggal_min'] = $this->M_perusahaan->tanggal_min_form();
        $data['tanggal_iklan'] = $this->M_perusahaan->tanggal_iklan();
        $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        $this->load->view('frontend/perusahaan/iklan_form');
        $this->load->view('frontend/perusahaan/footer');
    }
    function lala()
    {
        $now='2022-02-18';
       // date("Y-m-d", strtotime('+7 days', strtotime($tanggal)))
        for ($i=0; $i < 10; $i++) { 
            //echo $i+1;
            echo $now;
            $now_end = date("Y-m-d", strtotime('+6 days', strtotime($now)));
            echo ' - '.$now_end.'<br>';
             $data = array(
                'tanggal_tayang' => $now,
                'tanggal_akhir' => $now_end,
                'status_iklan' =>'tayang',
                'input_iklan' => date('Y-m-d')
             );
              $this->db->insert('iklan',$data);
            $now = date("Y-m-d", strtotime('+1 days', strtotime($now_end)));
        }
    }
    function iklan_tampil_form()
    {
        $id_iklan_paket=$this->input->post('id_iklan_paket', TRUE);

        $paket_iklan = $this->db->get_where('iklan_paket', array('id_iklan_paket'=>$id_iklan_paket))->row();


        $hasil = $this->load->view('frontend/perusahaan/iklan_paket_form',
         array('nama_paket'=>$paket_iklan->nama_paket, 'harga'=>number_format($paket_iklan->harga,0,',','.'), 
            'iklan_banner'=>$paket_iklan->iklan_banner, 'iklan_sidebar'=>$paket_iklan->iklan_sidebar_pustaka, 'iklan_detail_pustaka'=>$paket_iklan->iklan_detail_pustaka,'iklan_produk'=>$paket_iklan->iklan_produk,'iklan_newsletter'=>$paket_iklan->iklan_newsletter), true);

        $callback = array(
          'hasil' => $hasil // Set array hasil dengan isi dari view.php yang diload tadi
      );
        echo json_encode($callback); // konversi varibael $callback menjadi JSON

    }
   function hitung_tanggal()
   {
      $tanggal=$this->input->post('tanggal', TRUE);

      $callback = array(
        'hasil' =>  date("Y-m-d", strtotime('+6 days', strtotime($tanggal))) // Set array hasil dengan isi dari view.php yang diload tadi
      );
      echo json_encode($callback);
   }
   function ambil_rekening()
   {
      $id_rekening = $this->input->post('id_rekening');
        
      $data_rekening = $this->db->get_where('rekening', array('id_rekening'=>$id_rekening))->row();

      $bank = $data_rekening->bank;
      $nomor_rekening = $data_rekening->nomor_rekening;
      $nama_rekening = $data_rekening->nama_rekening;        
        
      $callback = array('bank'=>$bank,'nomor_rekening'=>$nomor_rekening, 'nama_rekening'=>$nama_rekening); // Masukan variabel lists tadi ke dalam array $callback dengan index array : list_kota
      echo json_encode($callback); 
   }
    function simpan_iklan()
    {


        $nama_kampanye=$this->input->post('nama_kampanye', TRUE);
        $paket=$this->input->post('paket_id', TRUE);
        $tanggal_tayang=$this->input->post('tanggal_tayang', TRUE);
        $tanggal_akhir=$this->input->post('tanggal_akhir', TRUE);
        $link=$this->input->post('link', TRUE);
        $bank=$this->input->post('bank', TRUE);
        $nama_rek=$this->input->post('nama_rek', TRUE);
        $no_rek=$this->input->post('no_rek', TRUE);
        $folder_iklan='epc_'.$this->session->userdata('id_perusahaan').'_'.date("dmyHis");
       
         
        $get_cek = $this->db->get_where('iklan', array('tanggal_tayang'=>$tanggal_tayang))->result_array();
        if(count($get_cek) < 1){

             mkdir('./upload_file/iklan/'.$folder_iklan);
            
            if($this->M_perusahaan->simpan_iklan($nama_kampanye, $paket, $tanggal_tayang, $tanggal_akhir, $link, $bank, $nama_rek, $no_rek, $folder_iklan) == TRUE){

                if (isset($_FILES["iklan_banner"]["name"])) {
                    $iklan_konten=$_FILES["iklan_banner"]["name"];
                    $this->M_perusahaan->simpan_konten_iklan($folder_iklan, $iklan_konten, 'iklan_banner', 'iklan_banner.png');
                }
                if (isset($_FILES["iklan_pustaka"]["name"])) {
                     $iklan_konten=$_FILES["iklan_pustaka"]["name"];
                    $this->M_perusahaan->simpan_konten_iklan($folder_iklan, $iklan_konten, 'iklan_pustaka', 'iklan_pustaka.png');
                    
                }
                if (isset($_FILES["iklan_detail_pustaka"]["name"])) {
                     $iklan_konten=$_FILES["iklan_detail_pustaka"]["name"];
                    $this->M_perusahaan->simpan_konten_iklan($folder_iklan, $iklan_konten, 'iklan_detail_pustaka', 'iklan_detail_pustaka.png');
                    
                }
                if (isset($_FILES["iklan_produk"]["name"])) {
                     $iklan_konten=$_FILES["iklan_produk"]["name"];
                    $this->M_perusahaan->simpan_konten_iklan($folder_iklan, $iklan_konten, 'iklan_produk', 'iklan_produk.png');
                    
                }
                if (isset($_FILES["iklan_newsletter"]["name"])) {
                     $iklan_konten=$_FILES["iklan_newsletter"]["name"];
                    $this->M_perusahaan->simpan_konten_iklan($folder_iklan, $iklan_konten, 'iklan_newsletter', 'iklan_newsletter.png');
                    
                }
                $get_id_epc = $this->M_perusahaan->get_id_epc();
                $data = array(
                    'id_iklan' => $get_id_epc->id_iklan,
                    'status_pembayaran'=> 'menunggu_pembayaran'
                );
                $this->db->insert('iklan_pembayaran' , $data);

                redirect(base_url()."perusahaan/pembayaran_iklan");
            }else{
                redirect(base_url()."perusahaan/tambah_iklan");
            }
        }else{
         

        $this->session->set_flashdata('notif' , 'false');
        $this->session->set_flashdata('teks_notif' , "Tanggal sudah digunakan");

          redirect(base_url()."perusahaan/tambah_iklan");
        }

      //  }
    }
  
    function pembayaran_iklan()
    {
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();
        if ($this->session->userdata('jenis_perusahaan') =='individu') {
            redirect(base_url().'user','refresh');
        }
        $data['iklan']=$this->M_perusahaan->tampil_pembayaran_iklan();
        $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        $this->load->view('frontend/perusahaan/iklan_pembayaran');
        $this->load->view('frontend/perusahaan/footer');
    }
    function upload_pembayaran_iklan()
    {
        $id_iklan=$this->input->post('id_iklan', true);
        $this->db->where('id_iklan' , $id_iklan);
        $this->db->update('iklan' , array('status_iklan'=> 'menunggu_verifikasi'));

        $name_bukti='INV-E'.$this->session->userdata('id_perusahaan').'-ADS'.$id_iklan.'-'.date("Ymd-His");
        $data = array(
            'bukti'=>$name_bukti,
            'status_pembayaran'=> 'menunggu_verifikasi',
            'input_pembayaran' => date("Y-m-d")
        );
        $this->db->where('id_iklan', $id_iklan);
        $this->db->update('iklan_pembayaran' , $data);

        $_FILES["bukti"]["name"];

         $config['upload_path'] = './upload_file/pembayaran/';
         $config['allowed_types'] = 'jpg|jpeg|png|gif|bmp';
         $config['file_name'] = $name_bukti.'.png';
         $this->upload->initialize($config);
         $this->upload->do_upload('bukti');
         $data = $this->upload->data();
                        //Compress Image
         $config['image_library']='gd2';
         $config['source_image']='./upload_file/pembayaran/'.$data['file_name'];
         $config['create_thumb']= FALSE;
         $config['maintain_ratio']= TRUE;
         $config['quality']= '100%';
                        //$config['width']= 720;
                        //$config['height']= 300;
         $config['new_image']= './upload_file/pembayaran/'.$data['file_name'];
         $this->load->library('image_lib', $config);
         $this->image_lib->resize();

         redirect(base_url().'perusahaan/pembayaran_iklan','refresh');
    }
    function detail_iklan($id_iklan)
    {
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();
        if ($this->session->userdata('jenis_perusahaan') =='individu') {
            redirect(base_url().'user','refresh');
        }
        $data['iklan']=$this->M_perusahaan->tampil_detail_iklan($id_iklan);
        $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        $this->load->view('frontend/perusahaan/iklan_detail');
        $this->load->view('frontend/perusahaan/footer');
    }
    function tayangkan_iklan($id_iklan, $newsletter)
    {
        $this->db->where('id_iklan' , $id_iklan);
        $this->db->update('iklan' , array('status_iklan' => 'tayang'));
   
        $this->session->set_flashdata('notif' , true);
        $this->session->set_flashdata('teks_notif' , "Iklan Ditayangkan");
        $this->session->set_flashdata('status_newsletter', $newsletter);
        $this->session->set_flashdata('id_iklan_news', $id_iklan);
        redirect(base_url()."perusahaan/daftar_iklan");
    }
    function send_newsletter()
    {
      $id_iklan = $this->input->post('id_iklan');
      $iklan_newsletter =$this->db->get_where('iklan', array('id_iklan'=>$id_iklan))->row();
      $folder= base_url().'upload_file/iklan/'.$iklan_newsletter->folder_iklan.'/iklan_newsletter.png';
      $content =  $this->load->view('frontend/template_email/newsletter_email', array('folder'=>$folder,'link'=>$iklan_newsletter->link), true);

      $this->load->library('mailer');
     
            $subjek = 'Solarhub Newsletter';
           // Ambil isi file content.php dan masukan ke variabel $content
      $email_user=$this->M_perusahaan->email_user();

      foreach ($email_user as $key => $valueUser) {
         $email_penerima = $valueUser['email'];
         $sendmail = array(
               'email_penerima'=>$email_penerima,
               'subjek'=>$subjek,
               'content'=>$content
                     //'attachment'=>$attachment
        );
        $send = $this->mailer->send($sendmail);
      }
     echo json_encode('selesai');
    }

     function perbaikan_iklan($id_iklan)
    {
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();
        if ($this->session->userdata('jenis_perusahaan') =='individu') {
            redirect(base_url().'user','refresh');
        }
        $data['iklan']=$this->M_perusahaan->tampil_detail_iklan($id_iklan);
        $data['iklan_perbaikan']=$this->M_perusahaan->tampil_perbaikan_iklan($id_iklan);
        $data['plugin_v']='1';$this->load->view('frontend/perusahaan/header', $data);
        $this->load->view('frontend/perusahaan/iklan_perbaikan');
        $this->load->view('frontend/perusahaan/footer');
    }
    function simpan_perbaikan_iklan()
    {
        $id_iklan = $this->input->post('id_iklan');
        $folder = $this->input->post('folder');

        $nama_kampanye = $this->input->post('nama_kampanye');
        $link = $this->input->post('link');
        $iklan_banner = $this->input->post('iklan_banner');
        $iklan_pustaka = $this->input->post('iklan_pustaka');
        $iklan_detail_pustaka = $this->input->post('iklan_detail_pustaka');
        $iklan_produk = $this->input->post('iklan_produk');
        $iklan_newsletter = $this->input->post('iklan_newsletter');
        if (!empty($nama_kampanye)) {
          $this->db->where('id_iklan', $id_iklan);
          $this->db->update('iklan' , array('nama_kampanye'=> $nama_kampanye));
        }
        if (!empty($link)) {
          $this->db->where('id_iklan', $id_iklan);
          $this->db->update('iklan' , array('link'=> $link));
        }
        // if($this->M_perusahaan->simpan_iklan($nama_kampanye, $paket, $tanggal_tayang, $tanggal_akhir, $link, $bank, $nama_rek, $no_rek, $folder_iklan) == TRUE){

               
                if (isset($_FILES["iklan_banner"]["name"])) {
                    unlink('./upload_file/iklan/'.$folder.'/iklan_banner.png');
                    $iklan_konten=$_FILES["iklan_banner"]["name"];
                   $this->M_perusahaan->simpan_update_konten_iklan($folder, $iklan_konten, 'iklan_banner', 'iklan_banner.png');
                    //echo '1';
                }
                if (isset($_FILES["iklan_pustaka"]["name"])) {
                   unlink('./upload_file/iklan/'.$folder.'/iklan_pustaka.png');
                     $iklan_konten=$_FILES["iklan_pustaka"]["name"];
                   $this->M_perusahaan->simpan_update_konten_iklan($folder, $iklan_konten, 'iklan_pustaka', 'iklan_pustaka.png');
                    //echo '2';
                }
                if (isset($_FILES["iklan_detail_pustaka"]["name"])) {
                   unlink('./upload_file/iklan/'.$folder.'/iklan_detail_pustaka.png');
                     $iklan_konten=$_FILES["iklan_detail_pustaka"]["name"];
                   $this->M_perusahaan->simpan_update_konten_iklan($folder, $iklan_konten, 'iklan_detail_pustaka', 'iklan_detail_pustaka.png');
                    //echo '3';
                }
                if (isset($_FILES["iklan_produk"]["name"])) {
                   unlink('./upload_file/iklan/'.$folder.'/iklan_produk.png');
                     $iklan_konten=$_FILES["iklan_produk"]["name"];
                    $this->M_perusahaan->simpan_update_konten_iklan($folder, $iklan_konten, 'iklan_produk', 'iklan_produk.png');
                    //echo '4';
                }
                if (isset($_FILES["iklan_newsletter"]["name"])) {
                  unlink('./upload_file/iklan/'.$folder.'/iklan_newsletter.png');
                  $iklan_konten=$_FILES["iklan_newsletter"]["name"];
                  $this->M_perusahaan->simpan_update_konten_iklan($folder, $iklan_konten, 'iklan_newsletter', 'iklan_newsletter.png');
                                    //echo '4';
                }
                
                $data = array(
                    'status_iklan'=> 'menunggu_verifikasi'
                );
                $this->db->where('id_iklan', $id_iklan);
                $this->db->update('iklan' , $data);

                $this->db->where('id_iklan', $id_iklan);
                $this->db->delete('iklan_perbaikan');
                
                redirect(base_url()."perusahaan/daftar_iklan");
    }

   

 }

 /* End of file Perusahaan.php */
/* Location: ./application/controllers/Perusahaan.php */