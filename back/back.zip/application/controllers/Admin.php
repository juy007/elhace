<?php 
if (!defined('BASEPATH'))exit('No direct script access allowed');

class Admin extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->database();
      $this->load->library('upload');
      $this->load->library('encryption');
      $this->load->helper('security');
      $this->load->helper('url');
      $this->load->library('session');
      $this->load->model('M_admin');
      $this->load->helper(array('url','form'));

      /*cache control*/
      $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
      $this->output->set_header('Pragma: no-cache');

       date_default_timezone_set('Asia/Jakarta');
   }
//BERANDA START====================================================================
   function index()
   {
      $data['web'] = $this->db->get_where('website', array('id_website'=>'1'))->row();
      $this->load->view('backend/login', $data);
   }

   function validation_login()
   {
      $username = $this->input->post('username');
      $password = $this->input->post('password');

      $check = $this->M_admin->validation_login($username, $password);

      if (count($check) > 0) {

          $query = $this->db->get_where('admin', array('username' => $username, 'password' => sha1($password)));
         $row = $query->row();
         
         $this->session->set_userdata('admin_login', 'TRUE');
         $this->session->set_userdata('id_admin', $row->id_admin);
         $this->session->set_userdata('nama_admin', $row->nama_admin);
         $this->session->set_userdata('email', $row->email);
         $this->session->set_userdata('username', $row->username);
         $this->session->set_userdata('password', $row->password);

         $this->M_admin->save_login($row->id_admin);

          redirect(base_url() ."admin-dashboard", 'refresh');
       }elseif (count($check) < 1) {
         $this->session->set_flashdata('username' , $username);
         $this->session->set_flashdata('password' , $password);
         $this->session->set_flashdata('notif' , 'FALSE');
         $this->session->set_flashdata('teks_notif' , "wrong username or password");
         redirect(base_url() ."admin", 'refresh');
      }
   }
   function forgot_password()
   {
      $this->session->sess_destroy();
      $data['web'] = $this->db->get_where('website', array('id_website'=>'1'))->row();
      $this->load->view('backend/forgot_password', $data);
   }
   function validation_forgot()
   {
      $email = $this->input->post('email');

      $check = $this->M_admin->validation_forgot($email);

      if (count($check) > 0) {
         $admin = $this->db->get_where('admin', array('email'=>$email))->row();
         $this->session->set_userdata('id_admin_otp', $admin->id_admin);

         $check_otp = $this->db->get_where('admin_otp', array('id_admin'=>$admin->id_admin))->result_array();
         if (count($check_otp)>0) {
            $this->M_admin->delete_otp($admin->id_admin);
         }
         
         
         $this->load->library('mailer');
         $verification_code = rand(1000, 9999);
         $recipient_email = $email;
         $subject = 'Verification Code';
         $message = $verification_code;
                
         $content = $this->load->view('backend/email/email_forgot_otp', array('message'=>$message), true); 
         $sendmail = array(
            'recipient_email'=>$recipient_email,
            'subject'=>$subject,
            'content'=>$content
                  //'attachment'=>$attachment
         );
         $send = $this->mailer->send($sendmail);
         
         
         date_default_timezone_set('Asia/Jakarta');
         $this->db->insert('admin_otp', array('id_admin'=> $admin->id_admin, 'code'=>$verification_code, 'date'=> date('Y-m-d'), 'time'=> date('H:i')));

          $this->session->set_userdata('forgot', 'TRUE');  
          redirect(base_url() ."admin-forgot-password-otp", 'refresh');
      }elseif (count($check) < 1) {
         $this->session->set_flashdata('email' , $email);
         $this->session->set_flashdata('notif' , 'FALSE');
         $this->session->set_flashdata('teks_notif' , "email not found");
         redirect(base_url() ."admin-forgot-password", 'refresh');
      }
   }
   function forgot_password_otp()
   {
      if ($this->session->userdata('forgot') != 'TRUE')
      redirect(base_url()."admin-forgot-password", 'refresh');

      $data['web'] = $this->db->get_where('website', array('id_website'=>'1'))->row();
      $this->load->view('backend/forgot_password_otp', $data);
   }

   function validation_forgot_password_otp()
   {
      $code = $this->input->post('code'); 
      $id_admin = $this->input->post('id_admin');

      $check_otp = $this->db->get_where('admin_otp', array('id_admin'=>$id_admin, 'code'=>$code))->result_array();
      if (count($check_otp)>0) {
         $otp = $this->db->get_where('admin_otp', array('id_admin'=>$id_admin, 'code'=>$code))->row();

         $date = new DateTime($otp->time);
         $date_plus = $date->modify("+1 minutes");
         $expired = $date_plus->format("H:i");

         if ($otp->date == date('Y-m-d') && date('H:i') <= $expired) {
            redirect(base_url() ."admin-new-password", 'refresh');
         }else{
            $this->session->set_flashdata('code' , $code);
            $this->session->set_flashdata('notif' , 'FALSE');
            $this->session->set_flashdata('teks_notif' , "expired code");
            redirect(base_url() ."admin-forgot-password-otp", 'refresh');
         }
         
      }else if(count($check_otp)<1){
         $this->session->set_flashdata('code' , $code);
         $this->session->set_flashdata('notif' , 'FALSE');
         $this->session->set_flashdata('teks_notif' , "code not available");
         redirect(base_url() ."admin-forgot-password-otp", 'refresh');
      } 
   }

   function new_password()
   {
      if ($this->session->userdata('forgot') != 'TRUE')
      redirect(base_url()."admin-forgot-password", 'refresh');

      $data['web'] = $this->db->get_where('website', array('id_website'=>'1'))->row();
      $this->load->view('backend/new_password', $data);
   }

   function logout()
   {
      //$this->session->unset_tempdata('item');
      $this->session->sess_destroy();
      redirect(base_url());
   } 

   function dashboard()
   {   
      if ($this->session->userdata('admin_login') != 'TRUE')
      redirect(base_url(), 'refresh');
      
      $this->load->view('backend/header');
      $this->load->view('backend/index');
      $this->load->view('backend/footer');
   }

    function news()
   {   
      if ($this->session->userdata('admin_login') != 'TRUE')
      redirect(base_url(), 'refresh');
      $data['read_news'] = $this->M_admin->read_news();
      $this->load->view('backend/header');
      $this->load->view('backend/news', $data);
      $this->load->view('backend/footer');
   }
    function news_form()
   {   
      if ($this->session->userdata('admin_login') != 'TRUE')
      redirect(base_url(), 'refresh');


      $open=opendir('upload_file/news') or die('Folder tidak terdeteksi!');
      while ($file=readdir($open)) {
      if($file !='.' && $file !='..'){   
            $read_news = $this->db->get_where('news', array('news_folder'=>$file));
            
            if ($read_news->num_rows()<1) {

                $files_list    =glob('upload_file/news/'.$file.'/*');
               foreach ($files_list as $file_show) {
                  if (is_file($file_show))
                     unlink($file_show);
               }
                  rmdir('upload_file/news/'.$file);
            }
         }
        
      }

      date_default_timezone_set('Asia/Jakarta');
      $this->session->set_userdata('news_folder', date('Y-m-d H-i-s'));
      mkdir('./upload_file/news/'.$this->session->userdata('news_folder'));
      $this->load->view('backend/header');
      $this->load->view('backend/news_summernote');
      //$this->load->view('backend/footer');
   }
    function news_edit($id_news)
   {   
      if ($this->session->userdata('admin_login') != 'TRUE')
      redirect(base_url(), 'refresh');
     
      $data['news_edit'] = $this->db->get_where('news', array('id_news'=>$id_news))->row();
      $this->session->set_userdata('news_folder',$data['news_edit']->news_folder);

      $this->load->view('backend/header');
      $this->load->view('backend/news_summernote_edit', $data);
   }

   function news_read()
   {   
      $id_news=$this->input->post('id_news');

      $read_news = $this->db->get_where('news', array('id_news'=>$id_news))->row();

      $callback = array(
         'news_folder' => $read_news->news_folder,
         'news_title' => $read_news->news_title,
         'news_text' => $read_news->news_text
      );
       echo json_encode($callback);
   }

   function save_news()
   {
      $news_title = $this->input->post('news_title');
      $meta_description = $this->input->post('meta_description');
      $meta_keyword = $this->input->post('meta_keyword');
      $news_text = $this->input->post('news_text');
      $news_views = '0';
      $create_date= date('Y-m-d');
      $news_status= $this->input->post('news_status');
      $news_folder= $this->input->post('news_folder');
      
      if(isset($_FILES["news_banner"]["name"])){
         $config['upload_path'] = './upload_file/news/'.$this->session->userdata('news_folder');
         $config['allowed_types'] = 'jpg|jpeg|png|gif';
         $config['file_name'] = 'image_news.png';
         $this->upload->initialize($config);
         if(!$this->upload->do_upload('news_banner')){
            $this->upload->display_errors();
            return FALSE;
         }else{
            $data = $this->upload->data();
                //Compress Image
            $config['image_library']='gd2';
            $config['source_image']='./upload_file/news/'.$this->session->userdata('news_folder').'/'.$data['file_name'];
            $config['create_thumb']= FALSE;
            $config['maintain_ratio']= TRUE;
            $config['quality']= '60%';
            $config['width']= 800;
            $config['height']= 800;
            $config['new_image']= './upload_file/news/'.$this->session->userdata('news_folder').'/'.$data['file_name'];
            $this->load->library('image_lib', $config);
            $this->image_lib->resize();
            //echo base_url().'upload_file/news/'.$this->session->userdata('news_folder').'/'.$data['file_name'];
         }
      }
      
      if ($this->M_admin->save_news($news_title, $meta_description, $meta_keyword, $news_text, $news_views, $create_date, $news_status, $news_folder) == TRUE) {
         $this->session->set_flashdata('notif' , true);
         $this->session->set_flashdata('teks_notif' , "news added successfully");
      }else{
         $this->session->set_flashdata('notif' , false);
         $this->session->set_flashdata('teks_notif' , "news failed to add");
      }
        
        redirect(base_url() ."admin-news-form/", 'refresh');
   }
   function save_news_update()
   {
      $id_news = $this->input->post('id_news');
      $news_title = $this->input->post('news_title');
      $meta_description = $this->input->post('meta_description');
      $meta_keyword = $this->input->post('meta_keyword');
      $news_text = $this->input->post('news_text');
      $updated_date= date('Y-m-d');
      $news_folder= $this->input->post('news_folder');

      
      if(!empty($_FILES["news_banner"]["name"])){
         //echo "hai";

         if(file_exists("./upload_file/news/".$news_folder."/image_news.png")){
            unlink('./upload_file/news/'.$news_folder.'/image_news.png');
         }
         
         $config['upload_path'] = './upload_file/news/'.$news_folder;
         $config['allowed_types'] = 'jpg|jpeg|png|gif';
         $config['file_name'] = 'image_news.png';
         $this->upload->initialize($config);
         if(!$this->upload->do_upload('news_banner')){
            $this->upload->display_errors();
            return FALSE;
         }else{
            $data = $this->upload->data();
                //Compress Image
            $config['image_library']='gd2';
            $config['source_image']='./upload_file/news/'.$news_folder.'/'.$data['file_name'];
            $config['create_thumb']= FALSE;
            $config['maintain_ratio']= TRUE;
            $config['quality']= '60%';
            $config['width']= 800;
            $config['height']= 800;
            $config['new_image']= './upload_file/news/'.$news_folder.'/'.$data['file_name'];
            $this->load->library('image_lib', $config);
            $this->image_lib->resize();
            //echo base_url().'upload_file/news/'.$this->session->userdata('news_folder').'/'.$data['file_name'];
         }
      }
      
      if ($this->M_admin->save_news_update($id_news, $news_title, $meta_description, $meta_keyword, $news_text, $updated_date) == TRUE) {
         $this->session->set_flashdata('notif' , true);
         $this->session->set_flashdata('teks_notif' , "news edited successfully");
      }else{
         $this->session->set_flashdata('notif' , false);
         $this->session->set_flashdata('teks_notif' , "news failed to edit");
      }
        
        redirect(base_url() ."admin-news-edit/".$id_news.'/', 'refresh');
   }

   function upload_image_summernote()
   {
      
        if(isset($_FILES["image"]["name"])){
            $config['upload_path'] = './upload_file/news/'.$this->session->userdata('news_folder');
            $config['allowed_types'] = 'jpg|jpeg|png|gif';
            $this->upload->initialize($config);
            if(!$this->upload->do_upload('image')){
                $this->upload->display_errors();
                return FALSE;
            }else{
                $data = $this->upload->data();
                //Compress Image
                $config['image_library']='gd2';
                $config['source_image']='./upload_file/news/'.$this->session->userdata('news_folder').'/'.$data['file_name'];
                $config['create_thumb']= FALSE;
                $config['maintain_ratio']= TRUE;
                $config['quality']= '60%';
                $config['width']= 800;
                $config['height']= 800;
                $config['new_image']= './upload_file/news/'.$this->session->userdata('news_folder').'/'.$data['file_name'];
                $this->load->library('image_lib', $config);
                $this->image_lib->resize();
                echo base_url().'upload_file/news/'.$this->session->userdata('news_folder').'/'.$data['file_name'];
            }
        }
   }
    function delete_image_summernote()
   {
       $src = $this->input->post('src');
        $file_name = str_replace(base_url(), '', $src);
        if(unlink($file_name))
        {
            echo 'File Delete Successfully';
        }
   }

   function news_status()
   {   
      $id_news=$this->input->post('id_news');
      $news_status=$this->input->post('news_status');

      if($this->M_admin->news_status_update($id_news, $news_status))
      {
         $result = 'true';
      }else{
         $result = 'false';
      }
      
      $callback = array(
         'notif' => $result
      );
      
      echo json_encode($callback);
   }

    function news_delete($id_news)
   {
      $read_news = $this->db->get_where('news', array('id_news'=>$id_news))->row();

      if ($this->M_admin->news_delete($id_news) == TRUE) {

         $files    =glob('upload_file/news/'.$read_news->news_folder.'/*');
         foreach ($files as $file) {
            if (is_file($file))
            //echo $file.'<br>';
            unlink($file); // hapus file
         }
         rmdir('upload_file/news/'.$read_news->news_folder);

         $this->session->set_flashdata('notif' , true);
         $this->session->set_flashdata('teks_notif' , "news deleted successfully");
      }else{
         $this->session->set_flashdata('notif' , false);
         $this->session->set_flashdata('teks_notif' , "news failed to delete");
      }
        
        redirect(base_url() ."admin-news", 'refresh');
   }

   function news_cron()
   {
      $open=opendir('upload_file/news') or die('Folder tidak terdeteksi!');
      while ($file=readdir($open)) {
      if($file !='.' && $file !='..'){   
      //$files[]=$file;
      //}
            echo $file.' : <br>';
            $read_news = $this->db->get_where('news', array('news_folder'=>$file));
            
            if ($read_news->num_rows()<1) {

                $files_list    =glob('upload_file/news/'.$file.'/*');
               foreach ($files_list as $file_show) {
                  if (is_file($file_show))
                     unlink($file_show);
               }
                  rmdir('upload_file/news/'.$file);
            }
         }
        
      }
   }

   function portfolio()
   {   
      if ($this->session->userdata('admin_login') != 'TRUE')
      redirect(base_url(), 'refresh');
      
      $data['portfolio_read'] = $this->M_admin->portfolio_read();

      $this->load->view('backend/header');
      $this->load->view('backend/portfolio', $data);
      $this->load->view('backend/footer');
   }

   function portfolio_form()
   {   
      if ($this->session->userdata('admin_login') != 'TRUE')
      redirect(base_url(), 'refresh');

      $this->load->view('backend/header');
      $this->load->view('backend/portfolio_form');
      $this->load->view('backend/footer');
   }

   function save_portfolio()
   {
      $category = $this->input->post('category');
      $publish_status = $this->input->post('publish_status');
      $create_date= date('Y-m-d');

     
      if(file_exists("upload_file/portfolio/".$_FILES["image_portfolio"]["name"])){
         $image_name=date('is').'-'.$_FILES["image_portfolio"]["name"];
      }else{
         $image_name=$_FILES["image_portfolio"]["name"];
      }

      if(isset($_FILES["image_portfolio"]["name"])){
         $config['upload_path'] = './upload_file/portfolio';
         $config['allowed_types'] = 'jpg|jpeg|png|gif';
         $config['file_name'] = $image_name;
         $this->upload->initialize($config);
         if(!$this->upload->do_upload('image_portfolio')){
            $this->upload->display_errors();
            return FALSE;
         }else{
            $data = $this->upload->data();
                //Compress Image
            $config['image_library']='gd2';
            $config['source_image']='./upload_file/portfolio'.'/'.$data['file_name'];
            $config['create_thumb']= FALSE;
            $config['maintain_ratio']= TRUE;
            //$config['quality']= '60%';
            //$config['width']= 800;
            //$config['height']= 800;
            $config['new_image']= './upload_file/portfolio'.'/'.$data['file_name'];
            $this->load->library('image_lib', $config);
            $this->image_lib->resize();
            //echo base_url().'upload_file/news/'.$this->session->userdata('news_folder').'/'.$data['file_name'];
         }
      }
         if ($this->M_admin->save_portfolio($category, $image_name, $create_date, $publish_status) == TRUE) {
         $this->session->set_flashdata('notif' , true);
         $this->session->set_flashdata('teks_notif' , "portfolio added successfully");
         }else{
            $this->session->set_flashdata('notif' , false);
            $this->session->set_flashdata('teks_notif' , "portfolio failed to add");
         }
           
           redirect(base_url() ."admin-portfolio-form/", 'refresh');
   }

   function portfolio_read()
   {   
      $id_portfolio=$this->input->post('id_portfolio');

      $read_portfolio = $this->db->get_where('portfolio', array('id_portfolio'=>$id_portfolio))->row();

      $callback = array(
         'image' => $read_portfolio->image
      );
       echo json_encode($callback);
   }

   function portfolio_status()
   {   
      $id_portfolio=$this->input->post('id_portfolio');
      $portfolio_status=$this->input->post('portfolio_status');

      if($this->M_admin->portfolio_status_update($id_portfolio, $portfolio_status))
      {
         $result = 'true';
      }else{
         $result = 'false';
      }
      
      $callback = array(
         'notif' => $result
      );
      
      echo json_encode($callback);
   }

   function portfolio_delete($id_portfolio)
   {
      $read_portfolio = $this->db->get_where('portfolio', array('id_portfolio'=>$id_portfolio))->row();

      if ($this->M_admin->portfolio_delete($id_portfolio) == TRUE) {

         unlink('upload_file/portfolio/'.$read_portfolio->image);

         $this->session->set_flashdata('notif' , true);
         $this->session->set_flashdata('teks_notif' , "portfolio deleted successfully");
      }else{
         $this->session->set_flashdata('notif' , false);
         $this->session->set_flashdata('teks_notif' , "portfolio failed to delete");
      }
        
        redirect(base_url() ."admin-portfolio", 'refresh');
   }


    function logo()
   {   
      if ($this->session->userdata('admin_login') != 'TRUE')
      redirect(base_url(), 'refresh');
      
      $this->load->view('backend/header');
      $this->load->view('backend/logo_form');
      $this->load->view('backend/footer');
   }

   function save_logo()
   {
      unlink('assets/frontend/img/main_logo.png');
      $config['upload_path'] = './assets/frontend/img';
      $config['allowed_types'] = 'jpg|jpeg|png|gif';
      $config['file_name'] = 'main_logo.png';
      $this->upload->initialize($config);
      if(!$this->upload->do_upload('logo')){
         $this->upload->display_errors();
         return FALSE;
      }else{
         $data = $this->upload->data();
          //Compress Image
         $config['image_library']='gd2';
         $config['source_image']='./assets/frontend/img'.'/'.$data['file_name'];
         $config['create_thumb']= FALSE;
         $config['maintain_ratio']= TRUE;
            //$config['quality']= '60%';
            //$config['width']= 800;
            //$config['height']= 800;
         $config['new_image']= './assets/frontend/img'.'/'.$data['file_name'];
         $this->load->library('image_lib', $config);
         $this->image_lib->resize();
      }
      $this->session->set_flashdata('notif' , true);
      $this->session->set_flashdata('teks_notif' , "successfully updated");
           
      redirect(base_url() ."admin-logo/", 'refresh');
   }

    function footer()
   {   
      if ($this->session->userdata('admin_login') != 'TRUE')
      redirect(base_url(), 'refresh');
      
      $data['web'] = $this->db->get_where('website', array('id_website'=>'1'))->row();
      $this->load->view('backend/header');
      $this->load->view('backend/footer_form', $data);
      $this->load->view('backend/footer');
   }
    function save_footer()
   {
      $footer = $this->input->post('footer');
     
         if ($this->M_admin->save_footer($footer) == TRUE) {
         $this->session->set_flashdata('notif' , true);
         $this->session->set_flashdata('teks_notif' , "successfully updated");
         }else{
            $this->session->set_flashdata('notif' , false);
            $this->session->set_flashdata('teks_notif' , "failed to update");
         }
           
           redirect(base_url() ."admin-footer/", 'refresh');
   }

    function meta()
   {   
      if ($this->session->userdata('admin_login') != 'TRUE')
      redirect(base_url(), 'refresh');
      $data['web'] = $this->db->get_where('website', array('id_website'=>'1'))->row();
      $this->load->view('backend/header');
      $this->load->view('backend/meta', $data);
      $this->load->view('backend/footer');
   }

   function save_meta()
   {
      $meta_description = $this->input->post('meta_description');
      $meta_keyword = $this->input->post('meta_keyword');
     
         if ($this->M_admin->save_meta($meta_description, $meta_keyword) == TRUE) {
         $this->session->set_flashdata('notif' , true);
         $this->session->set_flashdata('teks_notif' , "successfully updated");
         }else{
            $this->session->set_flashdata('notif' , false);
            $this->session->set_flashdata('teks_notif' , "failed to update");
         }
           
           redirect(base_url() ."admin-meta/", 'refresh');
   }


    function social_media()
   {   
      if ($this->session->userdata('admin_login') != 'TRUE')
      redirect(base_url(), 'refresh');
       $data['web'] = $this->db->get_where('website', array('id_website'=>'1'))->row();
      $this->load->view('backend/header');
      $this->load->view('backend/media_social', $data);
      $this->load->view('backend/footer');
   }

   function save_social_media()
      {
         $facebook = $this->input->post('facebook');
         $twitter = $this->input->post('twitter');
         $instagram = $this->input->post('instagram');
        
            if ($this->M_admin->save_social_media($facebook, $twitter, $instagram) == TRUE) {
            $this->session->set_flashdata('notif' , true);
            $this->session->set_flashdata('teks_notif' , "successfully updated");
            }else{
               $this->session->set_flashdata('notif' , false);
               $this->session->set_flashdata('teks_notif' , "failed to update");
            }
              
              redirect(base_url() ."admin-social-media/", 'refresh');
      }


   function setting()
   {   
      if ($this->session->userdata('admin_login') != 'TRUE')
      redirect(base_url(), 'refresh');
      $data['web'] = $this->db->get_where('website', array('id_website'=>'1'))->row();
      $this->load->view('backend/header');
      $this->load->view('backend/profile', $data);
      $this->load->view('backend/footer');
   }

   function save_setting()
   {
      $name = $this->input->post('name');
      $email = $this->input->post('email');
      $username = $this->input->post('username');

      if ($this->M_admin->save_setting($name, $email, $username, $this->session->userdata('id_admin')) == TRUE) {
            $this->session->set_flashdata('notif' , true);
            $this->session->set_flashdata('teks_notif' , "successfully updated");

            $this->session->set_userdata('nama_admin', $name);
            $this->session->set_userdata('email', $email);
            $this->session->set_userdata('username', $username);

      }else{
            $this->session->set_flashdata('notif' , false);
            $this->session->set_flashdata('teks_notif' , "failed to update");
      }
           
           redirect(base_url() ."admin-edit-profile/", 'refresh');

      
   }
   function setting_check_pass()
   {
      $id_admin=$this->input->post('id_admin');
      $pass=$this->input->post('pass');

      $check= $this->db->get_where('admin', array('id_admin'=>$id_admin, 'password'=>sha1($pass)))->result_array();

      if (count($check)>0) {
         $result = 'true';
      }elseif (count($check)<1){
         $result = 'false';
      }

      $callback = array(
         'notif' => $result
      );
       echo json_encode($callback);
   }
    function save_setting_password()
   {
      $repassword = $this->input->post('repassword');

      if ($this->M_admin->save_setting_password($repassword, $this->session->userdata('id_admin')) == TRUE) {
            $this->session->set_flashdata('notif' , true);
            $this->session->set_flashdata('teks_notif' , "password updated successfully");

      }else{
            $this->session->set_flashdata('notif' , false);
            $this->session->set_flashdata('teks_notif' , "password failed to update");
      }
           
           redirect(base_url() ."admin-edit-profile/", 'refresh');

      
   }


//LOGOUT START====================================================================
   
//LOGOUT END======================================================================
//MENU MOBILE START===============================================================
   function user_menu()
   {   
      if ($this->session->userdata('user_login') != 'TRUE')
      redirect(base_url(), 'refresh');

      //  $data['seo'] = $this->home->seo(); //menampilkan meta title, keyword, deskripsi
      $data['lang'] = $this->Website->lang($this->session->userdata('lang')); 
      $data['medsos'] = $this->Website->medsosweb();
      
      $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
      $this->load->view('frontend/user/menu_user');
      $this->load->view('frontend/user/footer');
   }
//MENU MOBILE END================================================================
//MENU UBAH DATA USER START======================================================
   function akun()
   {   
      if ($this->session->userdata('user_login') != 'TRUE')
      redirect(base_url(), 'refresh');

      $data['lang'] = $this->Website->lang($this->session->userdata('lang')); 
      $data['medsos'] = $this->Website->medsosweb();
       
      $query = $this->db->get_where('user', array('id_user' => $this->session->userdata('id_user')));
      $data['data_user'] = $query->row();
      $data['provinsi'] = $this->M_user->tampil_provinsi();
      $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
      $this->load->view('frontend/user/akun', $data);
      $this->load->view('frontend/user/footer');
   }

   function update_foto_user()
   {
      if(file_exists("upload_file/".$this->session->userdata('folder')."/img/foto_profil/".$this->session->userdata('foto_profil'))){
       unlink('upload_file/'.$this->session->userdata('folder').'/img/foto_profil/'.$this->session->userdata('foto_profil'));
      }

      $_FILES["gambar"]["name"];

      $config['upload_path'] = './upload_file/'.$this->session->userdata('folder').'/img/foto_profil/';
      $config['allowed_types'] = 'jpg|jpeg|png|gif|bmp';
      $config['file_name'] = $this->session->userdata('foto_profil');
      $this->upload->initialize($config);
      if(!$this->upload->do_upload('gambar')){
          $this->upload->display_errors();
         return FALSE;
      }else{
         $data = $this->upload->data();
            //Compress Image
         $config['image_library']='gd2';
         $config['source_image']='./upload_file/'.$this->session->userdata('folder').'/img/foto_profil/'.$data['file_name'];
         $config['create_thumb']= FALSE;
         $config['maintain_ratio']= TRUE;
         $config['quality']= '100%';
         $config['width']= 720;
         $config['height']= 300;
         $config['new_image']= './upload_file/'.$this->session->userdata('folder').'/img/foto_profil/'.$data['file_name'];
         $this->load->library('image_lib', $config);
         $this->image_lib->resize();
      }
      //echo base_url().'./upload_file/'.$this->session->userdata('folder').'/img/perusahaan/'.$data['file_name'];      
      redirect(base_url()."user/akun");
   }

   function update_data_user()
   {
      $nama_depan = $this->input->post('nama_depan',TRUE);
      $nama_belakang = $this->input->post('nama_belakang',TRUE);
      $email = $this->input->post('email',TRUE);
      $telepon = $this->input->post('telepon',TRUE);
      $alamat = $this->input->post('alamat',TRUE);
      $kelurahan = str_replace("_", " ", $this->input->post('kelurahan'));
      $kecamatan = str_replace("_", " ", $this->input->post('kecamatan'));
      $kota = str_replace("_", " ", $this->input->post('kota'));
      $provinsi = str_replace("_", " ", $this->input->post('provinsi'));
      $pos = $this->input->post('pos',TRUE);
      if ($this->M_user->simpan_update_data_user($nama_depan, $nama_belakang, $email, $telepon, $alamat, $kelurahan, $kecamatan, $kota, $provinsi, $pos) == TRUE) {

        $this->session->set_userdata('nama_depan', $nama_depan);
        $this->session->set_userdata('nama_belakang', $nama_belakang);
        $this->session->set_userdata('email', $email);
        $this->session->set_userdata('telepon', telepon);
        $this->session->set_userdata('alamat', $alamat);
        $this->session->set_userdata('kecamatan', $kecamatan);
        $this->session->set_userdata('kota', $kota);
        $this->session->set_userdata('provinsi', $provinsi);
        $this->session->set_userdata('pos', $pos);

        redirect(base_url() . "user/akun");
      }else{
        $this->session->set_flashdata('notif' , false);
        $this->session->set_flashdata('teks_notif' , "Registrasi Gagal");
        redirect(base_url() . "user/akun/gagal");
      }
   }

   function update_password_user()
   {
      $password = $this->input->post('password2',TRUE);
      if ($this->M_user->simpan_update_password_user($password) == TRUE) {
         $this->session->set_userdata('pass', $password);
         redirect(base_url() . "user/akun");
      }else{
         $this->session->set_flashdata('notif' , false);
         $this->session->set_flashdata('teks_notif' , "Registrasi Gagal");
         redirect(base_url() . "user/akun/gagal");
      }
   }
//MENU UBAH DATA USER END======================================================
//ARTIKEL START================================================================
   function artikel()
   {
      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();
          
      if (empty($this->input->post('cari'))) {
         $data['artikel']=$this->M_user->tampil_artikel();
         $data['label_cari']="";
      }else{
         $data['artikel']=$this->M_user->tampil_artikel_cari($this->input->post('cari'));
         $data['label_cari']="Hasil pencarian<br>'".$this->input->post('cari')."'";
      }

      $data['artikel_terbaru']=$this->M_user->tampil_artikel_terbaru();
      $data['iklan'] = $this->M_user->tampil_iklan_sidebar_pustaka();

      $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
      $this->load->view('frontend/user/artikel');
      $this->load->view('frontend/user/footer');
   }

   function detail_artikel($id_artikel=null)
   {
      if (empty($id_artikel)) {redirect(base_url().'user/artikel');}
      $get_artikel = $this->db->get_where('artikel', array('id_artikel'=>$id_artikel));
      if(count($get_artikel->result_array()) < 1){ redirect(base_url().'user/load');}

      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();
           
      $data['artikel']=$this->M_user->tampil_artikel_detail($id_artikel);
      $data['artikel_terbaru']=$this->M_user->tampil_artikel_terbaru();
      $data['iklan'] = $this->M_user->tampil_iklan_sidebar_pustaka();
      $data['iklan2'] = $this->M_user->tampil_iklan_detail_pustaka();

      $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
      $this->load->view('frontend/user/artikel_detail');
      $this->load->view('frontend/user/footer');
   }
//ARTIKEL END====================================================================
//PUBLIKASI START================================================================
   function publikasi()
   {
      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();
      if (empty($this->input->post('cari'))) {
         $data['publikasi']=$this->M_user->tampil_publikasi();
         $data['label_cari']="";
      }else{
         $data['publikasi']=$this->M_user->tampil_publikasi_cari($this->input->post('cari'));
         $data['label_cari']="Hasil pencarian<br>'".$this->input->post('cari')."'";
      }

      $data['publikasi_terbaru']=$this->M_user->tampil_publikasi_terbaru();
      $data['iklan'] = $this->M_user->tampil_iklan_sidebar_pustaka();
      
      $data['plugin_v']='2';$data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
      $this->load->view('frontend/user/publikasi');
      $this->load->view('frontend/user/footer');
   }

   function detail_publikasi($id_publikasi=null)
   {  
      if (empty($id_publikasi)) {redirect(base_url().'user/publikasi');}
      $get_publikasi = $this->db->get_where('publikasi', array('id_publikasi'=>$id_publikasi));
      if(count($get_publikasi->result_array()) < 1){ redirect(base_url().'user/load');}

      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();

      $data['publikasi']=$this->M_user->tampil_publikasi_detail($id_publikasi);
      $data['publikasi_terbaru']=$this->M_user->tampil_publikasi_terbaru();
      $data['iklan'] = $this->M_user->tampil_iklan_sidebar_pustaka();
      $data['iklan2'] = $this->M_user->tampil_iklan_detail_pustaka();
   
      $data['plugin_v']='2';$data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
      $this->load->view('frontend/user/publikasi_detail');
      $this->load->view('frontend/user/footer');
   }

   function publikasi_email_kirim()
   {
      $id = $this->input->post('id',TRUE);
      $link = $this->input->post('link',TRUE);
      $nama = $this->input->post('nama',TRUE);
      $email = $this->input->post('email',TRUE);
      $institusi = $this->input->post('institusi',TRUE);

      $data = array(
         'id_publikasi' => $id,
         'id_user'=> $this->session->userdata('id_user'),
         'nama' => $nama,
         'email' => $email,
         'institusi' => $institusi,
         'input_publikasi_download' => date('Y-m-d')
      );
      $this->db->insert('publikasi_download',$data);
       /*
       $content =  $this->load->view('frontend/template_email/publikasi_email', array('link'=> $link ), true);

       $this->load->library('mailer');
       $recipient_email =$email;
       $subject = 'Publikasi';
        
       $sendmail = array(
           'email_penerima'=>$recipient_email,
           'subject'=>$subject,
           'content'=>$content
                
       );
       $send = $this->mailer->send($sendmail);


       $callback = array(
             'hasil' => 'email terkirim, silahkan buka e-mail' // Set array hasil dengan isi dari view.php yang diload tadi
         );
       echo json_encode($callback);
       */
      $callback = array(
          'hasil' => 'Berhasil didownload' // Set array hasil dengan isi dari view.php yang diload tadi
       );
      echo json_encode($callback);
   }
//PUBLIKASI END================================================================
//INFO SOLARHUB START==========================================================   
   function tentang()
   {
      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();
        
      $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
      $this->load->view('frontend/user/tentang');
      $this->load->view('frontend/user/footer');
   }

   function syarat_dan_ketentuan()
   {
      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();
        
      $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
      $this->load->view('frontend/user/syaratKetentuan');
      $this->load->view('frontend/user/footer');
   }

   function tentang_plts_atap()
   {
      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();
          
      $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
      $this->load->view('frontend/user/faq_plts_atap');
      $this->load->view('frontend/user/footer');
   }

   function tentang_solarhub()
   {
      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();
          
      $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
      $this->load->view('frontend/user/faq_solarhub');
      $this->load->view('frontend/user/footer');
   }

   function tentang_kalkulator_surya()
   {
      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();
      
      $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
      $this->load->view('frontend/user/faq_kalkulator_surya');
      $this->load->view('frontend/user/footer');
   }
//INFO SOLARHUB END==========================================================  
//PEMBLIAN PRODUK START====================================================== 
   function beli()
   {
      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();

      $cek_keranjang = $this->db->get_where('order', array('id_user'=>$this->session->userdata('id_user'),'status_order'=>'keranjang'));

      if ($cek_keranjang->num_rows() < 1) {
        redirect(base_url().'user');
      }

      $data['rekening'] = $this->M_user->tampil_rekening();
      $data['checkout'] = $this->M_user->tampil_beli();
      $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
      $this->load->view('frontend/user/beli');
      $this->load->view('frontend/user/footer');
   } 

   function ambil_data_rekening()
   {
   }

   function simpan_beli()
   {
      if (!empty($_POST['nama_penerima'])) {
         $id_invoice = 'INV/U'.$this->session->userdata('id_user').'/PD/'.date("Ymd/His");
         $nama = $this->input->post('nama_penerima');
         $telepon = $this->input->post('telepon_penerima');
         $alamat = $this->input->post('alamat_penerima');
         $kecamatan  = $this->input->post('kecamatan_penerima');
         $kabupaten = $this->input->post('kabupaten_penerima');
         $provinsi = $this->input->post('provinsi_penerima');
         $pos = $this->input->post('pos_penerima');
         $total = $this->input->post('total');
         $bank = $this->input->post('bank');
         $nomor_rekening = $this->input->post('nomor_rekening');
         $nama_rekening = $this->input->post('nama_rekening');
         $alamat_for_email = $alamat.' '.$kecamatan.' '.$kabupaten.' '.$provinsi.' '.$pos;
         $this->M_user->tambah_invoice($id_invoice, $nama, $telepon, $alamat, $kecamatan, $kabupaten, $provinsi, $pos, $total, $bank, $nama_rekening, $nomor_rekening, 'menunggu_pembayaran');

         $id = $this->input->post('Fid_order');
         $Fno_invoice = $this->input->post('Fno_invoice');
         $jumlah = $this->input->post('Fjumlah');

         $result = array();
         $no = 0;
         foreach($id AS $key => $val){
           $no++;
           $result[] = array(
            "id_order" => $id[$key],
            "id_invoice" => $id_invoice,
            "no_invoice"  =>  $Fno_invoice.''.$no,
            "tanggal" => date("Y-m-d"),
            "jam" => date("H:i:s"),
            "status_order" => 'menunggu_pembayaran'
         );
         }
         $this->db->update_batch('order', $result, 'id_order');

         $item['item']=$this->M_user->invoice_email($id_invoice);

         $content =  $this->load->view('frontend/template_email/invoice_email', array('no_invoice'=>$id_invoice,'tanggal'=> date("Y-m-d"), 'nama_penerima'=>$nama, 'telepon'=> $telepon, 'alamat'=> $alamat_for_email, 'bank'=>$bank, 'nama_rek'=>$nama_rekening, 'no_rek'=> $nomor_rekening, 'item' => $item['item'] ), true);

         /* for($i=0; $i < count($result); $i++)
            {
               echo implode(",", $result[$i])."<br>";
            }*/
         $this->load->library('mailer');
         $recipient_email =$this->session->userdata('email');
         $subject = 'Invoice';
         // Ambil isi file content.php dan masukan ke variabel $content
         $sendmail = array(
            'email_penerima'=>$recipient_email,
            'subject'=>$subject,
            'content'=>$content
            //'attachment'=>$attachment
         );
         $send = $this->mailer->send($sendmail);

         redirect(base_url().'user/pembelian');
      }else{  
         redirect(base_url().'user', 'refresh');
      }    
   }

   function invoice($id_invoice = null)
   {
      $data['id_invo'] = $id_invoice;
      if (empty($id_invoice)) {redirect(base_url().'user/pembelian', 'refresh');}
      $id_invoice = str_replace('-', '/', $id_invoice);
      $data['invo'] = str_replace('-', '/', $id_invoice);
      $cek =  $this->db->get_where('order_invoice', array('id_invoice'=> $id_invoice))->result_array();
      if (count($cek) < 1) {
         redirect(base_url().'user');
      }
      $get_id_user = $this->db->get_where('user', array('id_user'=>$this->session->userdata('id_user')));
      $data['user'] = $get_id_user->row();

      $data['invoice'] =  $this->db->get_where('order_invoice', array('id_invoice'=> $id_invoice))->row();
      $data['daftar_invoice'] = $this->M_user->daftar_invoice($id_invoice);
      $data['pembayaran'] = $this->M_user->tampil_pembayaran($id_invoice);

      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();

      $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
      $this->load->view('frontend/user/invoice');
      $this->load->view('frontend/user/footer');
   }

   function ekspor_pdf_invoice($invoice)
   {

      $this->load->library('pdf');
      $this->pdf->setPaper('A4', 'portrait');
      $this->pdf->filename = date("d-m-Y")."-".$invoice.".pdf";

      $id_invoice = str_replace('-', '/', $invoice);
      $invo=$invoice;//#
      $get_id_user = $this->db->get_where('user', array('id_user'=>$this->session->userdata('id_user')));
      $user = $get_id_user->row();//#

      $invoice =  $this->db->get_where('order_invoice', array('id_invoice'=> $id_invoice))->row();//#
      $daftar_invoice = $this->M_user->daftar_invoice($id_invoice);//#
      $pembayaran = $this->M_user->tampil_pembayaran($id_invoice);//#
      $this->pdf->load_view('frontend/user/invoice_pdf',array('invo'=>$invo,'user'=>$user,'invoice'=>$invoice, 'daftar_invoice'=>$daftar_invoice,'pembayaran'=>$pembayaran),true);
   }

   function simpan_pembayaran()
   {
        $id_invoice = $this->input->post('id_invoice');
        $id_invoice_re = str_replace('/', '-',$this->input->post('id_invoice'));
        $pembayaran = $this->input->post('pembayaran');
        $nominal = str_replace('.', '',$this->input->post('nominal'));
        $bukti_pembayaran = $id_invoice_re.'-'.date('dmYHi').'.png';

        $this->M_user->simpan_pembayaran($id_invoice, $pembayaran, $nominal, $bukti_pembayaran);

        $_FILES["pembayaran"]["name"];

        $config['upload_path'] = './upload_file/pembayaran/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif|bmp';
        $config['file_name'] = $bukti_pembayaran;
        $this->upload->initialize($config);
        $this->upload->do_upload('pembayaran');
        $data = $this->upload->data();
               //Compress Image
        $config['image_library']='gd2';
        $config['source_image']='./upload_file/pembayaran/'.$data['file_name'];
        $config['create_thumb']= FALSE;
        $config['maintain_ratio']= TRUE;
        $config['quality']= '100%';
              //$config['width']= 720;
              //$config['height']= 300;
        $config['new_image']= './upload_file/pembayaran/'.$data['file_name'];
        $this->load->library('image_lib', $config);
        $this->image_lib->resize();

        redirect(base_url().'user/invoice/'.$id_invoice_re);
   }

   function riwayat()
   {
      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();

      $data['riwayat']= $this->M_user->selesai_order();
      $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
      $this->load->view('frontend/user/riwayat');
      $this->load->view('frontend/user/footer');
   }

   function pembelian()
   {
      $data['invoice']= $this->M_user->invoice();
      $data['proses_order']= $this->M_user->proses_order();
      $data['kirim_order']= $this->M_user->kirim_order();
      $data['selesai_order']= $this->M_user->selesai_order();

      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();

      $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
      $this->load->view('frontend/user/pembelian');
      $this->load->view('frontend/user/footer');
   }    

   function pembelian_selesai($id_order, $id_produk, $jumlah)
   {
      $hitung_produk=$this->db->get_where('order', array('id_produk'=>$id_produk,'status_order'=>'selesai',))->result_array();

      $this->db->where('id_produk' , $id_produk);
      $this->db->update('perusahaan_produk', array('terjual'=>count($hitung_produk)+$jumlah));

      $data1 = array(
         'status_order' => 'selesai',
         'tanggal_selesai' => date("Y-m-d"),
         'jam_selesai' => date("H:i:s")
      );
      $this->db->where('id_order' , $id_order);
      $this->db->update('order' , $data1); 

      $data2 = array(
         'id_order' => $id_order,
         'status_bukti'=> 'menunggu_upload',
         'input_bukti_order' => date("Y-m-d")
      );
      $this->db->insert('order_bukti' , $data2);

      redirect(base_url().'user/pembelian','refresh');
   }    

   function pembelian_detail($id_order = null)//halaman verifikasi OTP
   {
      if (empty($id_order)) {redirect(base_url().'user/pembelian', 'refresh');}
      $cek = $this->db->get_where('order', array('id_order'=> $id_order))->result_array();
      if (count($cek) < 1) {redirect(base_url().'user/pembelian', 'refresh');}

      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();
      $data['invoice'] = $this->M_user->pembelian_detail_invoice($id_order);
      $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
      $this->load->view('frontend/user/pembelian_detail');
      $this->load->view('frontend/user/footer');
   }   
//PEMBLIAN PRODUK END======================================================  
//WISHLIST START===========================================================
   function wishlist()
   {
      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();

      $data['wishlist'] = $this->M_user->tampil_wishlist();

      $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
      $this->load->view('frontend/user/wishlist');
      $this->load->view('frontend/user/footer');
   }

   function tambah_wishlist_produk()
   {
      $id_user = $this->input->post('id_user');
      $id_etalase = $this->input->post('id_produk');
      $jenis= $this->input->post('jenis');
      $produk_wishlist = $this->M_user->tambah_wishlist_produk($id_user, $id_etalase, $jenis);

      if ($produk_wishlist == TRUE) {
         echo 'sukses';
      }else{
         echo 'gagal';
      } 
   }

   function hapus_wishlist($id_wishlist)
   {
      $this->db->where('id_wishlist', $id_wishlist);
      $this->db->delete('user_wishlist');
      redirect(base_url().'user/wishlist');
   }

   function produk_tambah_keranjang()
   {
      $id_user = $this->input->post('id_user');
      $id_produk = $this->input->post('id_produk');
      $jml_item = $this->input->post('jml_item');
      $total_harga = $this->input->post('total_harga');
      $catatan = $this->input->post('catatan');

      $cek_keranjang = $this->db->get_where('order', array('id_user'=>$id_user,'id_produk'=>$id_produk,'status_order'=>'keranjang'));
      $value_order = $cek_keranjang->row();

      if ($cek_keranjang->num_rows() > 0) {
         $jml_update = $value_order->jumlah+$jml_item;
         //$harga_update = $value_order->harga+$total_harga;
         $this->db->where('id_user' , $id_user);
         $this->db->where('id_produk' , $id_produk);
         $this->db->where('status_order' , 'keranjang');
         $this->db->update('order', array('jumlah'=>$jml_update));
         echo 'sukses';
      }else{
         $produk_keranjang = $this->M_user->tambah_keranjang_produk($id_user, $id_produk, $jml_item, $total_harga, $catatan);

         if ($produk_keranjang == TRUE) {
            echo 'sukses';
         }else{
            echo 'gagal';
         } 
      }
   }
//WISHLIST END===========================================================
//KERANJANG START========================================================
   function keranjang()
   {
      if (isset($_POST['Fid_order'])) {
         $id = $this->input->post('Fid_order');
         $catatan = $this->input->post('Fcatatan');
         $jumlah = $this->input->post('Fjumlah');

         $result = array();
         foreach($id AS $key => $val){
            $result[] = array(
               "id_order" => $id[$key],
               "catatan"  => $_POST['Fcatatan'][$key],
               "jumlah"  => $_POST['Fjumlah'][$key]
            );
         }
         $this->db->update_batch('order', $result, 'id_order');
         redirect(base_url().'user/beli', 'refresh');
      }

      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();

      $data['keranjang'] = $this->M_user->tampil_keranjang();

      $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
      $this->load->view('frontend/user/keranjang');
      $this->load->view('frontend/user/footer');
   }

   function hapus_keranjang($id_keranjang)
   {
      $this->db->where('id_order', $id_keranjang);
      $this->db->delete('order');
      redirect(base_url().'user/keranjang');
   }
//KERANJANG END==========================================================
//BUAT PERUSAHAAN START==================================================
   function form_perusahaan()
   {
      $get_id_perusahaan = $this->db->get_where('perusahaan', array('id_user'=>$this->session->userdata('id_user')));
      $value_get_id = $get_id_perusahaan->row();

      if ($get_id_perusahaan->num_rows() > 0) {
          redirect(base_url().'user/form_area_operasi','refresh');
      }

      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();
      $data['provinsi'] = $this->M_user->tampil_provinsi();

      $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
      $this->load->view('frontend/user/form_perusahaan');
      $this->load->view('frontend/user/footer');
   }

   function ambil_data_kota()
   {
      $provinsi=$this->input->post('provinsi');
      $data=$this->M_user->tampil_cari_kota($provinsi)->result();
      echo json_encode($data);
   }

   function ambil_data_kecamatan()
   {
      $kabupaten=str_replace("_", " ", $this->input->post('kabupaten'));
      $data=$this->M_user->tampil_cari_kecamatan($kabupaten)->result();
      echo json_encode($data);
   }

   function ambil_data_kelurahan()
   {
      $kecamatan=str_replace("_", " ", $this->input->post('kecamatan'));
      $data=$this->M_user->tampil_cari_kelurahan($kecamatan)->result();
      echo json_encode($data);
   }

   function ambil_data_pos()
   {
      $kelurahan=str_replace("_", " ", $this->input->post('kelurahan'));
      $kecamatan=str_replace("_", " ", $this->input->post('kecamatan'));
      $kabupaten=str_replace("_", " ", $this->input->post('kabupaten'));
      $provinsi=str_replace("_", " ",$this->input->post('provinsi'));
      $data=$this->M_user->tampil_cari_kodepos($kelurahan, $kecamatan, $kabupaten, $provinsi)->row();
      echo json_encode($data);
   }

   function form_area_operasi()
   {
      /*$get_id_perusahaan = $this->db->get_where('perusahaan', array('id_user'=>$this->session->userdata('id_user')));
      $value_get_id = $get_id_perusahaan->row();
      if ($value_get_id->status_perusahaan == 'aktiv') {
         redirect(base_url().'user/form_kontak');
      }*/
      if (isset($_POST['namaPerusahaan'])){
         $namaPerusahaan = $this->input->post('namaPerusahaan');
         $taglinePerusahaan = $this->input->post('taglinePerusahaan');
         $alamatPerusahaan = $this->input->post('alamatPerusahaan');
         $kelurahanPerusahaan = str_replace("_", " ", $this->input->post('kelurahanPerusahaan'));
         $kecamatanPerusahaan = str_replace("_", " ", $this->input->post('kecamatanPerusahaan'));
         $kabupatenPerusahaan = str_replace("_", " ", $this->input->post('kabupatenPerusahaan'));
         $provinsiPerusahaan = str_replace("_", " ", $this->input->post('provinsiPerusahaan'));
         $posPerusahaan = $this->input->post('posPerusahaan');
         $latitudePerusahaan = $this->input->post('latitudePerusahaan');
         $longitudePerusahaan = $this->input->post('longitudePerusahaan');
         $deskripsiPerusahaan = $this->input->post('deskripsiPerusahaan');
         $jenisPerusahaan = $this->input->post('jenisPerusahaan');

         $nama_bank = $this->input->post('nama_bank');
         $pemilik_rekening = $this->input->post('pemilik_rekening');
         $no_rekening = $this->input->post('no_rekening');

         if($this->M_user->simpan_perusahaan($namaPerusahaan, $taglinePerusahaan, $alamatPerusahaan, $kelurahanPerusahaan, $kecamatanPerusahaan, $kabupatenPerusahaan, $provinsiPerusahaan, $posPerusahaan, $latitudePerusahaan, $longitudePerusahaan, $deskripsiPerusahaan, $jenisPerusahaan, $nama_bank, $pemilik_rekening, $no_rekening) == TRUE){

            //mkdir("upload_file/".$this->session->userdata('folder')."/img/perusahaan");

            $_FILES["logoPerusahaan"]["name"];

            $config['upload_path'] = './upload_file/'.$this->session->userdata('folder').'/img/perusahaan/';
            $config['allowed_types'] = 'jpg|jpeg|png|gif|bmp';
            $config['file_name'] = 'logoPerusahaan.png';
            $this->upload->initialize($config);
            $this->upload->do_upload('logoPerusahaan');
            $data = $this->upload->data();
                //Compress Image
            $config['image_library']='gd2';
            $config['source_image']='./upload_file/'.$this->session->userdata('folder').'/img/perusahaan/'.$data['file_name'];
            $config['create_thumb']= FALSE;
            $config['maintain_ratio']= TRUE;
            $config['quality']= '100%';
            //$config['width']= 720;
            //$config['height']= 300;
            $config['new_image']= './upload_file/'.$this->session->userdata('folder').'/img/perusahaan/'.$data['file_name'];
            $this->load->library('image_lib', $config);
            $this->image_lib->resize();
            //  echo base_url().'./upload_file/'.$this->session->userdata('folder').'/img/perusahaan/'.$data['file_name'];      
            
            $_FILES["bannerPerusahaan"]["name"];

            $config1['upload_path'] = './upload_file/'.$this->session->userdata('folder').'/img/perusahaan/';
            $config1['allowed_types'] = 'jpg|jpeg|png|gif|bmp';
            $config1['file_name'] = 'bannerPerusahaan.png';
            $this->upload->initialize($config1);
            $this->upload->do_upload('bannerPerusahaan');
            $data = $this->upload->data();
                   //Compress Image
            $config1['image_library']='gd2';
            $config1['source_image']='./upload_file/'.$this->session->userdata('folder').'/img/perusahaan/'.$data['file_name'];
            $config1['create_thumb']= FALSE;
            $config1['maintain_ratio']= TRUE;
            $config1['quality']= '100%';
            $config1['width']= 720;
            $config1['height']= 300;
            $config1['new_image']= './upload_file/'.$this->session->userdata('folder').'/img/perusahaan/'.$data['file_name'];
            $this->load->library('image_lib', $config1);
            $this->image_lib->resize();
                
            $get_id_perusahaan = $this->db->get_where('perusahaan', array('id_user'=>$this->session->userdata('id_user')));
            $value_get_id = $get_id_perusahaan->row();

            $this->session->set_userdata('id_perusahaan', $value_get_id->id_perusahaan);
            $this->session->set_userdata('nama_perusahaan', $value_get_id->nama_perusahaan);
            $this->session->set_userdata('tagline', $value_get_id->tagline);
            $this->session->set_userdata('alamat_perusahaan', $value_get_id->alamat_perusahaan);
            $this->session->set_userdata('kelurahan_perusahaan', $value_get_id->kelurahan_perusahaan);
            $this->session->set_userdata('kecamatan_perusahaan', $value_get_id->kecamatan_perusahaan);
            $this->session->set_userdata('kabupaten_perusahaan', $value_get_id->kabupaten_perusahaan);
            $this->session->set_userdata('provinsi_perusahaan', $value_get_id->provinsi_perusahaan);
            $this->session->set_userdata('pos_perusahaan', $value_get_id->pos_perusahaan);
            $this->session->set_userdata('latitude', $value_get_id->latitude);
            $this->session->set_userdata('longitude', $value_get_id->longitude);
            $this->session->set_userdata('deskripsi', $value_get_id->deskripsi);
            $this->session->set_userdata('pembayaran_cash', $value_get_id->pembayaran_cash);
            $this->session->set_userdata('pembayaran_kredit', $value_get_id->pembayaran_kredit);
            $this->session->set_userdata('status_perusahaan', $value_get_id->status_perusahaan);
            $this->session->set_userdata('jenis_perusahaan', $value_get_id->jenis_perusahaan);
            $this->session->set_userdata('rating_perusahaan', $value_get_id->rating_perusahaan);
            $this->session->set_userdata('input_perusahaan', $value_get_id->input_perusahaan);

            $dataArea = array(
              'id_perusahaan' => $value_get_id->id_perusahaan,
              'kabupaten' => str_replace("_", " ", $this->input->post('kabupatenPerusahaan')),
              'input_area_operasi' => date('Y-m-d')
           );
            $this->db->insert('perusahaan_area_operasi',$dataArea);

            $dataArea2 = array(
              'id_perusahaan' => $value_get_id->id_perusahaan,
              'kabupaten' => str_replace("_", " ", $this->input->post('provinsiPerusahaan')),
              'input_area_operasi' => date('Y-m-d')
            );
            $this->db->insert('perusahaan_area_operasi',$dataArea2);

            $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
            $data['medsos'] = $this->Website->medsosweb();
            $data['provinsi'] = $this->M_user->tampil_provinsi();
            $data['area_operasi'] = $value_get_id->kabupaten_perusahaan;
            $data['area'] = $this->db->get_where('perusahaan_area_operasi', array('id_perusahaan'=>  $value_get_id->id_perusahaan))->result_array();

            $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
            $this->load->view('frontend/user/form_area_operasi');
            $this->load->view('frontend/user/footer');
         }else{
            redirect(base_url()."user/form_perusahaan");
         }
      }else{
         $get_id_perusahaan = $this->db->get_where('perusahaan', array('id_user'=>$this->session->userdata('id_user')));
         $value_get_id = $get_id_perusahaan->row();
         if ($get_id_perusahaan->num_rows() > 0) {
            if ($value_get_id->status_perusahaan == 'aktiv') {
               //  redirect(base_url().'user/finish','refresh');
               redirect(base_url().'user/form_kontak');
            }   
         }else{
            // redirect(base_url().'user/form_perusahaan','refresh');
         }
         $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
         $data['medsos'] = $this->Website->medsosweb();
         $data['provinsi'] = $this->M_user->tampil_provinsi();
         $data['area_operasi'] = $value_get_id->kabupaten_perusahaan;
         $data['area'] = $this->db->get_where('perusahaan_area_operasi', array('id_perusahaan'=>  $value_get_id->id_perusahaan))->result_array();

         $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
         $this->load->view('frontend/user/form_area_operasi');
         $this->load->view('frontend/user/footer');
      } 
   }

   function tambah_area_operasi()
   {
      $kabupaten = $this->input->post('kabupaten');

      $get_id_perusahaan = $this->db->get_where('perusahaan', array('id_user'=>$this->session->userdata('id_user')));
      $value_get_id = $get_id_perusahaan->row();

      $get_area_operasi = $this->db->get_where('perusahaan_area_operasi', array('id_perusahaan'=> $value_get_id->id_perusahaan, 'kabupaten'=> $kabupaten))->result_array();

      if (count($get_area_operasi) < 1) {
         $data = array(
            'id_perusahaan' => $value_get_id->id_perusahaan,
            'kabupaten' => $kabupaten,
            'input_area_operasi' => date('Y-m-d')
         );
         $this->db->insert('perusahaan_area_operasi',$data);

         $area_operasi = $this->M_user->tampil_area_operasi_perusahaan($value_get_id->id_perusahaan);

         $hasil = $this->load->view('frontend/user/form_area_operasi_view', array('area_operasi'=>$area_operasi), true);

         $callback = array(
            'hasil' => $hasil // Set array hasil dengan isi dari view.php yang diload tadi
         );
        echo json_encode($callback);

      }else{
         $hasil = 'no';

         $callback = array(
            'hasil' => $hasil // Set array hasil dengan isi dari view.php yang diload tadi
         );
        echo json_encode($callback);
      }
   }

   function hapus_area_operasi()
   {
      $id_area_operasi = $this->input->post('id_area_operasi');
      $get_id_perusahaan = $this->db->get_where('perusahaan', array('id_user'=>$this->session->userdata('id_user')));
      $value_get_id = $get_id_perusahaan->row();

      $this->db->where('id_area_operasi', $id_area_operasi);
      $this->db->delete('perusahaan_area_operasi');

      $area_operasi = $this->M_user->tampil_area_operasi_perusahaan($value_get_id->id_perusahaan);

      $hasil = $this->load->view('frontend/user/form_area_operasi_view', array('area_operasi'=>$area_operasi), true);

      $callback = array(
         'hasil' => $hasil // Set array hasil dengan isi dari view.php yang diload tadi
      );
      echo json_encode($callback);
   }

   function form_kontak()
   {
      $get_id_perusahaan = $this->db->get_where('perusahaan', array('id_user'=>$this->session->userdata('id_user')));
      $value_get_id = $get_id_perusahaan->row();

      if ($get_id_perusahaan->num_rows() > 0) {
         $query = $this->db->get_where('perusahaan_medsos', array('id_perusahaan' => $value_get_id->id_perusahaan));
         if ($query->num_rows() > 0) {
            redirect(base_url().'user/form_jadwal','refresh');
         }   
      }else{
         redirect(base_url().'user/form_perusahaan','refresh');
      }


      if (isset($_POST['namaPerusahaan'])){
         $namaPerusahaan = $this->input->post('namaPerusahaan');
         $taglinePerusahaan = $this->input->post('taglinePerusahaan');
         $alamatPerusahaan = $this->input->post('alamatPerusahaan');
         $kelurahanPerusahaan = str_replace("_", " ", $this->input->post('kelurahanPerusahaan'));
         $kecamatanPerusahaan = str_replace("_", " ", $this->input->post('kecamatanPerusahaan'));
         $kabupatenPerusahaan = str_replace("_", " ", $this->input->post('kabupatenPerusahaan'));
         $provinsiPerusahaan = str_replace("_", " ", $this->input->post('provinsiPerusahaan'));
         $posPerusahaan = $this->input->post('posPerusahaan');
         $latitudePerusahaan = $this->input->post('latitudePerusahaan');
         $longitudePerusahaan = $this->input->post('longitudePerusahaan');
         $deskripsiPerusahaan = $this->input->post('deskripsiPerusahaan');
         $jenisPerusahaan = $this->input->post('jenisPerusahaan');

         if($this->M_user->simpan_perusahaan($namaPerusahaan, $taglinePerusahaan, $alamatPerusahaan, $kelurahanPerusahaan, $kecamatanPerusahaan, $kabupatenPerusahaan, $provinsiPerusahaan, $posPerusahaan, $latitudePerusahaan, $longitudePerusahaan, $deskripsiPerusahaan, $jenisPerusahaan) == TRUE){

            //mkdir("upload_file/".$this->session->userdata('folder')."/img/perusahaan");

            $_FILES["logoPerusahaan"]["name"];

            $config['upload_path'] = './upload_file/'.$this->session->userdata('folder').'/img/perusahaan/';
            $config['allowed_types'] = 'jpg|jpeg|png|gif|bmp';
            $config['file_name'] = 'logoPerusahaan.png';
            $this->upload->initialize($config);
            $this->upload->do_upload('logoPerusahaan');
            $data = $this->upload->data();
                         //Compress Image
            $config['image_library']='gd2';
            $config['source_image']='./upload_file/'.$this->session->userdata('folder').'/img/perusahaan/'.$data['file_name'];
            $config['create_thumb']= FALSE;
            $config['maintain_ratio']= TRUE;
            $config['quality']= '100%';
            //$config['width']= 720;
            //$config['height']= 300;
            $config['new_image']= './upload_file/'.$this->session->userdata('folder').'/img/perusahaan/'.$data['file_name'];
            $this->load->library('image_lib', $config);
            $this->image_lib->resize();
            //echo base_url().'./upload_file/'.$this->session->userdata('folder').'/img/perusahaan/'.$data['file_name'];      
                  
            $_FILES["bannerPerusahaan"]["name"];

            $config1['upload_path'] = './upload_file/'.$this->session->userdata('folder').'/img/perusahaan/';
            $config1['allowed_types'] = 'jpg|jpeg|png|gif|bmp';
            $config1['file_name'] = 'bannerPerusahaan.png';
            $this->upload->initialize($config1);
            $this->upload->do_upload('bannerPerusahaan');
            $data = $this->upload->data();
               //Compress Image
            $config1['image_library']='gd2';
            $config1['source_image']='./upload_file/'.$this->session->userdata('folder').'/img/perusahaan/'.$data['file_name'];
            $config1['create_thumb']= FALSE;
            $config1['maintain_ratio']= TRUE;
            $config1['quality']= '100%';
            $config1['width']= 720;
            $config1['height']= 300;
            $config1['new_image']= './upload_file/'.$this->session->userdata('folder').'/img/perusahaan/'.$data['file_name'];
            $this->load->library('image_lib', $config1);
            $this->image_lib->resize();
            
            $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
            $data['medsos'] = $this->Website->medsosweb();

            $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
            $this->load->view('frontend/user/form_kontak');
            $this->load->view('frontend/user/footer');
         }else{
            redirect(base_url()."user/form_perusahaan");
         }
      }else{
        $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
        $data['medsos'] = $this->Website->medsosweb();

        $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
        $this->load->view('frontend/user/form_kontak');
        $this->load->view('frontend/user/footer');
      } 
   }

   function form_jadwal()
   {
      $get_id_perusahaan = $this->db->get_where('perusahaan', array('id_user'=>$this->session->userdata('id_user')));
      $value_get_id = $get_id_perusahaan->row();
      $this->session->set_userdata('id_perusahaan', $value_get_id->id_perusahaan);
      if ($get_id_perusahaan->num_rows() > 0) {
         $query = $this->db->get_where('perusahaan_jadwal', array('id_perusahaan' => $value_get_id->id_perusahaan));
         if ($query->num_rows() > 0) {
            redirect(base_url().'user/form_portofolio','refresh');
         }
      }else{
         redirect(base_url().'user/form_perusahaan','refresh');
      }

      if (isset($_POST['emailPerusahaan'])){
         $emailPerusahaan = $this->input->post('emailPerusahaan');
         $teleponPerusahaan = $this->input->post('teleponPerusahaan');
         $whatsappPerusahaan = $this->input->post('whatsappPerusahaan');


         if($this->M_user->simpan_kontakEmail($emailPerusahaan) == TRUE && $this->M_user->simpan_kontakTelepon($teleponPerusahaan) == TRUE && $this->M_user->simpan_kontakWhatsapp($whatsappPerusahaan) == TRUE){
            if (isset($_POST['websitePerusahaan'])){
               $websitePerusahaan = $this->input->post('websitePerusahaan');
               $this->M_user->simpan_kontakWebsite($websitePerusahaan);
            }

            if (isset($_POST['linkvideoPerusahaan'])){
               $linkvideoPerusahaan = $this->input->post('linkvideoPerusahaan');
               $this->M_user->simpan_kontakVideo($linkvideoPerusahaan);
            }

            $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
            $data['medsos'] = $this->Website->medsosweb();

            $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
            $this->load->view('frontend/user/form_jadwal');
            $this->load->view('frontend/user/footer');
         }else{
           redirect(base_url()."user/form_kontak");
         }

      }else{
         $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
         $data['medsos'] = $this->Website->medsosweb();

         $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
         $this->load->view('frontend/user/form_jadwal');
         $this->load->view('frontend/user/footer');
      }
   }

   function form_portofolio()
   {
      $get_id_perusahaan = $this->db->get_where('perusahaan', array('id_user'=>$this->session->userdata('id_user')));
      $value_get_id = $get_id_perusahaan->row();

      if ($get_id_perusahaan->num_rows() > 0) {
         $query = $this->db->get_where('perusahaan_portofolio', array('id_perusahaan' => $value_get_id->id_perusahaan));
         if ($query->num_rows() > 0) {
            redirect(base_url().'user/form_pembayaran','refresh');
         }
      }else{
         redirect(base_url().'user/form_perusahaan','refresh');
      }

      if (isset($_POST['hari'])){
         $hari = $this->input->post('hari');
         $kondisi = $this->input->post('kondisi');
         $jam_buka = $this->input->post('jam_buka');
         $jam_tutup = $this->input->post('jam_tutup');

         if($this->M_user->simpan_jadwal($hari, $kondisi, $jam_buka, $jam_tutup) == TRUE){

             $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
             $data['medsos'] = $this->Website->medsosweb();

             $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
             $this->load->view('frontend/user/form_portofolio');
             $this->load->view('frontend/user/footer');
         }else{
           redirect(base_url()."user/form_jadwal");
         }

      }else{
         $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
         $data['medsos'] = $this->Website->medsosweb();

         $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
         $this->load->view('frontend/user/form_portofolio');
         $this->load->view('frontend/user/footer');
      }
   }

   function form_pembayaran()
   {
      $get_id_perusahaan = $this->db->get_where('perusahaan', array('id_user'=>$this->session->userdata('id_user')));
      $value_get_id = $get_id_perusahaan->row();
      if ($get_id_perusahaan->num_rows() > 0) {
         if($value_get_id->pembayaran_cash=='true' || $value_get_id->pembayaran_kredit=='true'){
            redirect(base_url().'user/finish','refresh');
         }
      }else{
       redirect(base_url().'user/form_perusahaan','refresh');
      }   

      if (isset($_POST['nama_projek'])){
         $nama_projek = $this->input->post('nama_projek');
         $kapasitas = $this->input->post('kapasitas');
         $informasi_tambahan = $this->input->post('informasi_tambahan');
         $folder = substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz123456789'), 0, 8);
          $_FILES["slide"]["name"];

         mkdir("./upload_file/".$this->session->userdata('folder')."/img/perusahaan/portofolio/".$folder);
         // chmod("./upload_file/".$this->session->userdata('folder')."/img/perusahaan/portofolio/".$folder, 0777, true);

         $filesCount = count($_FILES['slide']['name']);

         for($i = 0; $i < $filesCount; $i++){
            $new_name = substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz123456789'), 0, 5);

            $_FILES['file']['name']     = $_FILES['slide']['name'][$i];
            $_FILES['file']['type']     = $_FILES['slide']['type'][$i];
            $_FILES['file']['tmp_name'] = $_FILES['slide']['tmp_name'][$i];
            $_FILES['file']['error']     = $_FILES['slide']['error'][$i];
            $_FILES['file']['size']     = $_FILES['slide']['size'][$i];

            // File upload configuration
            $config['upload_path'] = './upload_file/'.$this->session->userdata('folder').'/img/perusahaan/portofolio/'.$folder.'/';

            $config['allowed_types'] = 'jpg|jpeg|png|gif|bmp';
            $config['file_name'] = 'slide_'.$new_name.'.png';
            $config['create_thumb']= FALSE;
            $config['maintain_ratio']= TRUE;
            $config['quality']= '100%';

            $this->load->library('upload', $config);
            $this->upload->initialize($config);

            if($this->upload->do_upload('file')){
              $fileData = $this->upload->data();
              $uploadData[$i]['file_name'] = $fileData['file_name'];
              $uploadData[$i]['uploaded_on'] = date("Y-m-d H:i:s");
              //  $insert = $this->file->insert($uploadData);
            }
         }

         if(!empty($uploadData)){
            $data = array(
              'id_perusahaan' => $value_get_id->id_perusahaan,
              'projek' => $nama_projek,
              'kapasitas' => str_replace(",",".",$kapasitas),
              'informasi_tambahan' => $informasi_tambahan,
              'folder' => $folder,
              'input_portofolio_perusahaan' => date('Y-m-d')
           );
            $this->db->insert('perusahaan_portofolio',$data);

            $this->session->set_flashdata('notif' , true);
            $this->session->set_flashdata('teks_notif' , "Berhasil ditambah");

            $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
            $data['medsos'] = $this->Website->medsosweb();

            $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
            $this->load->view('frontend/user/form_pembayaran');
            $this->load->view('frontend/user/footer');
         }
      }else{

         $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
         $data['medsos'] = $this->Website->medsosweb();
         $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
         $this->load->view('frontend/user/form_pembayaran');
         $this->load->view('frontend/user/footer');
      }
   }

   function finish()
   {   
      $get_id_perusahaan = $this->db->get_where('perusahaan', array('id_user'=>$this->session->userdata('id_user')));
      $value_get_id = $get_id_perusahaan->row();

      if (isset($_POST['cash'])){
         $status_cash = $this->input->post('cash');
         $status_kredit = $this->input->post('kredit');
         $bank = $this->input->post('bank');
         $update_pembayaran = $this->M_user->update_status_pembayaran($value_get_id->id_perusahaan, $status_cash, $status_kredit); 
         if ($status_kredit == 'true') {
            $input_bank=$this->M_user->input_skema_pembiayaan($value_get_id->id_perusahaan,$bank);
         }

         if ($update_pembayaran == FALSE) {
            redirect(base_url()."user/form_pembayaran");
         }
      }

      $query = $this->db->get_where('perusahaan_medsos', array('id_perusahaan' => $value_get_id->id_perusahaan));
      $query2 = $this->db->get_where('perusahaan_jadwal', array('id_perusahaan' => $value_get_id->id_perusahaan));
      $query3 = $this->db->get_where('perusahaan_portofolio', array('id_perusahaan' => $value_get_id->id_perusahaan));

      if ($query->num_rows() <= 0) {
         redirect(base_url().'user/form_kontak','refresh');
      }elseif ($query2->num_rows() <= 0) {
        redirect(base_url().'user/form_jadwal','refresh');
      }elseif ($query3->num_rows() <= 0) {
        redirect(base_url().'user/form_portofolio','refresh');
      }elseif($value_get_id->pembayaran_cash == 'false' && $value_get_id->pembayaran_kredit=='false'){
        redirect(base_url().'user/form_pembayaran','refresh');
      }

      $get_id_epc = $this->db->get_where('perusahaan', array('id_user'=>$this->session->userdata('id_user'),'jenis_perusahaan'=>'individu','status_perusahaan'=>'menunggu_verifikasi'));
      $value_get_epc = $get_id_epc->row();
      if ($get_id_epc->num_rows()>0) {
         $this->db->where('id_user', $value_get_epc->id_user);
         $this->db->update('perusahaan', array('status_perusahaan'=>'aktiv'));
      }

      $data['status_perusahaan'] = $value_get_id->status_perusahaan;
      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();

      $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
      $this->load->view('frontend/user/form_finish');
      $this->load->view('frontend/user/footer');
   }

   function finishxxx()
   {
      $get_id_perusahaan = $this->db->get_where('perusahaan', array('id_user'=>$this->session->userdata('id_user')));
      $value_get_id = $get_id_perusahaan->row();

      $nama_projek = $this->input->post('nama_projek');
      $kapasitas = $this->input->post('kapasitas');
      $informasi_tambahan = $this->input->post('informasi_tambahan');
      $folder = substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz123456789'), 0, 8);
      $_FILES["slide"]["name"];
         //mkdir("upload_file/".$this->session->userdata('folder')."/img/perusahaan/portofolio/".$folder);

      $filesCount = count($_FILES['slide']['name']);

      for($i = 0; $i < $filesCount; $i++){
         $new_name = substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz123456789'), 0, 5);

         $_FILES['file']['name']     = $_FILES['slide']['name'][$i];
         $_FILES['file']['type']     = $_FILES['slide']['type'][$i];
         $_FILES['file']['tmp_name'] = $_FILES['slide']['tmp_name'][$i];
         $_FILES['file']['error']     = $_FILES['slide']['error'][$i];
         $_FILES['file']['size']     = $_FILES['slide']['size'][$i];

                  // File upload configuration
         $config['upload_path'] = './upload_file/'.$this->session->userdata('folder').'/img/perusahaan/portofolio/'.$folder.'/';

         $config['allowed_types'] = 'jpg|jpeg|png|gif|bmp';
         $config['file_name'] = 'slide_'.$new_name.'.png';
         $config['create_thumb']= FALSE;
         $config['maintain_ratio']= TRUE;
         $config['quality']= '100%';

         $this->load->library('upload', $config);
         $this->upload->initialize($config);

         if($this->upload->do_upload('file')){
            $fileData = $this->upload->data();
            $uploadData[$i]['file_name'] = $fileData['file_name'];
            $uploadData[$i]['uploaded_on'] = date("Y-m-d H:i:s");
                  //  $insert = $this->file->insert($uploadData);
         }
      }

      if(!empty($uploadData)){
         $data = array(
            'id_perusahaan' => $value_get_id->id_perusahaan,
            'projek' => $nama_projek,
            'kapasitas' => str_replace(",",".",$kapasitas),
            'informasi_tambahan' => $informasi_tambahan,
            'folder' => $folder,
            'input_portofolio_perusahaan' => date('Y-m-d')
         );
         $this->db->insert('perusahaan_portofolio',$data);

         $this->session->set_flashdata('notif' , true);
         $this->session->set_flashdata('teks_notif' , "Slide Berhasil ditambah");
      }
      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();

      $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
      $this->load->view('frontend/user/form_finish');
      $this->load->view('frontend/user/footer');
   }
//BUAT PERUSAHAAN END====================================================
//PRODUK START===========================================================
   function produk($jenis=null,$lokasi=null,$ukuran=null)
   {
      //  $data['seo'] = $this->home->seo(); //menampilkan meta title, keyword, deskripsi
      $data['lang'] = $this->Website->lang($this->session->userdata('lang')); 
      $data['medsos'] = $this->Website->medsosweb();
      
      if (empty($jenis) && empty($lokasi)) {
         $loc = json_decode(file_get_contents("https://ipinfo.io/".$_SERVER['REMOTE_ADDR']."/json"));
         $data['jenis'] ='auto';
         $data['lokasi'] = $loc->city;
         //$data['lokasi'] =$this->session->userdata('kota');
      }else{
         $data['jenis'] = $jenis;
         $data['lokasi'] = $lokasi;
      }
      $data['ukuran'] = $ukuran;

      $data['cari'] = $this->input->get('cari');
      $data['kabupaten'] = $this->M_user->tampil_kota();
      $data['provinsi'] = $this->M_user->tampil_provinsi();
      $data['produk'] = $this->M_user->tampil_produk();
      $data['iklan'] = $this->M_user->tampil_iklan_produk();

      $data['plugin_v']='2';$this->load->view('frontend/user/header_1',$data);
      $this->load->view('frontend/user/produk');
      $this->load->view('frontend/user/footer');
      //$this->load->view('frontend/footer');
   }

   function produk_search()
   {
      //============================membuat array id perusahaan dari area operasi===1 
        $areaArray = $this->input->post('lokasi_kota');
        if (!empty($areaArray)) {
            $this->db->select("*");
            $this->db->where_in('kabupaten', $areaArray);
            $this->db->group_by('id_perusahaan');
            $data_area_operasi= $this->db->get('perusahaan_area_operasi')->result_array();

            if (count($data_area_operasi) > 0)
            {
                foreach ($data_area_operasi as $key => $valueAO) {
                  $kab[] = $valueAO['id_perusahaan'];
                }
            }else{
                $kab ='x';
            }
        }else{
            $kab ='';
        }


        $nama_produk = $this->input->post('nama_produk');
        $lokasi_kota = $this->input->post('lokasi_kota');
        $lokasi_provinsi = '';//$this->input->post('lokasi_provinsi');
        $kategori = $this->input->post('kategori');    
       /* $sistem_on_grid = $this->input->post('sistem_on_grid');                           
        $sistem_off_grid = $this->input->post('sistem_off_grid');
        $sistem_hybrid = $this->input->post('sistem_hybrid');                             
        $pju = $this->input->post('pju');
        $panel = $this->input->post('panel');
        $inverter = $this->input->post('inverter');
        $kabel = $this->input->post('kabel');*/
        $harga_minimal = str_replace(".", "", $this->input->post('harga_minimal'));
        $harga_maximal = str_replace(".", "", $this->input->post('harga_maximal'));
        $pembayaran_cash = $this->input->post('pembayaran_cash');
        $pembayaran_kredit = $this->input->post('pembayaran_kredit');
        $garansi = $this->input->post('garansi');
        $ukuran_sistem = $this->input->post('ukuran_sistem');
        $rating = $this->input->post('rating');
        $sortir = $this->input->post('sortir');                       

        $produk = $this->M_user->search_produk($nama_produk, $kategori, $kab,/*$lokasi_provinsi,*/$harga_minimal, $harga_maximal, $pembayaran_cash, $pembayaran_kredit, $garansi, $ukuran_sistem, $rating, $sortir);


        $hasil = $this->load->view('frontend/user/produk_view1', array('produk'=>$produk,'kategori'=>$kategori,'lokasi_kota' => $lokasi_kota,'lokasi_provinsi' => $lokasi_provinsi,'harga_minimal' =>$harga_minimal,'harga_maximal' =>$harga_maximal,'pembayaran_cash' => $pembayaran_cash,'pembayaran_kredit' => $pembayaran_kredit,'garansi' =>$garansi,'ukuran_sistem' => $ukuran_sistem,'rating'=> $rating), true);

        $callback = array(
          'hasil' => $hasil // Set array hasil dengan isi dari view.php yang diload tadi
      );
        echo json_encode($callback); // konversi varibael $callback menjadi JSON
   }

   function produk_reset_search()
   {
      $nama_produk = $this->input->post('nama_produk');
      $sortir = $this->input->post('sortir');

      $produk = $this->M_user->search_reset_produk($nama_produk, $sortir);

      $hasil = $this->load->view('frontend/user/produk_view1', array('produk'=>$produk), true);
      $page = $this->load->view('frontend/user/produk_paging', array('produk'=>$produk), true);

      $callback = array(
         'hasil' => $hasil,
         'prod' => $page // Set array hasil dengan isi dari view.php yang diload tadi
      );
       echo json_encode($callback); // konversi varibael $callback menjadi JSON
   }

   function produk_detail($id_produk = null)
   {
      if (empty($id_produk)) {redirect(base_url().'user/produk');}
      $get_produk = $this->db->get_where('produk_view', array('id_produk'=>$id_produk, 'status_publis'=>'true', 'status_hapus'=>'false', 'status_perusahaan'=>'aktiv'));
      $valProduk=$get_produk->row();
      if(count($get_produk->result_array()) < 1){ redirect(base_url().'user/load');}
        
      //  $data['seo'] = $this->home->seo(); //menampilkan meta title, keyword, deskripsi
      $data['lang'] = $this->Website->lang($this->session->userdata('lang')); 
      $data['medsos'] = $this->Website->medsosweb();

      $data['produk']=  $get_produk->row();
      $data['ulasan']=  $this->M_user->ulasan_produk($id_produk);

      $byRekom1 = $this->M_user->rekomendasi_produk_perusahaan($id_produk, '1','cek_rekom','true');
      $byRekom2 = $this->M_user->rekomendasi_produk_perusahaan($id_produk, '2','cek_rekom','true');
      $byRekom3 = $this->M_user->rekomendasi_produk_perusahaan($id_produk, '3','cek_rekom','true');
      $byRekom4 = $this->M_user->rekomendasi_produk_perusahaan($id_produk, '4','cek_rekom','true');
      $byRekom5 = $this->M_user->rekomendasi_produk_perusahaan($id_produk, '5','cek_rekom','true');
      $byRekom6 = $this->M_user->rekomendasi_produk_perusahaan($id_produk, '6','cek_rekom','true');
      $byRekom7 = $this->M_user->rekomendasi_produk_perusahaan($id_produk, '7','cek_rekom','true');
      $byRekom8 = $this->M_user->rekomendasi_produk_perusahaan($id_produk, '8','cek_rekom','true');
      $byRekom9 = $this->M_user->rekomendasi_produk_perusahaan($id_produk, '9','cek_rekom','true');
      $byRekom10 = $this->M_user->rekomendasi_produk_perusahaan($id_produk, '10','cek_rekom','true');

      $cariRekom = array($byRekom1, $byRekom2, $byRekom3, $byRekom4, $byRekom5, $byRekom6, $byRekom7, $byRekom8, $byRekom9, $byRekom10);

      if (max($cariRekom)==$byRekom1) { $no_rekom ='1';}
      elseif (max($cariRekom)==$byRekom2) {$no_rekom ='2';}
      elseif (max($cariRekom)==$byRekom3) {$no_rekom ='3';}
      elseif (max($cariRekom)==$byRekom4) {$no_rekom ='4';}
      elseif (max($cariRekom)==$byRekom5) {$no_rekom ='5';}
      elseif (max($cariRekom)==$byRekom6) {$no_rekom ='6';}
      elseif (max($cariRekom)==$byRekom7) {$no_rekom ='7';}
      elseif (max($cariRekom)==$byRekom8) {$no_rekom ='8';}
      elseif (max($cariRekom)==$byRekom9) {$no_rekom ='9';}
      elseif (max($cariRekom)==$byRekom10) {$no_rekom ='10';}

      $data['rekomedasi_perusahaan']=  $this->M_user->rekomendasi_produk_perusahaan($id_produk, $no_rekom,'get_rekom', 'true');

      $byRekomAll1 = $this->M_user->rekomendasi_produk_perusahaan($id_produk, '1','cek_rekom','false');
      $byRekomAll2 = $this->M_user->rekomendasi_produk_perusahaan($id_produk, '2','cek_rekom','false');
      $byRekomAll3 = $this->M_user->rekomendasi_produk_perusahaan($id_produk, '3','cek_rekom','false');
      $byRekomAll4 = $this->M_user->rekomendasi_produk_perusahaan($id_produk, '4','cek_rekom','false');
      $byRekomAll5 = $this->M_user->rekomendasi_produk_perusahaan($id_produk, '5','cek_rekom','false');
      $byRekomAll6 = $this->M_user->rekomendasi_produk_perusahaan($id_produk, '6','cek_rekom','false');
      $byRekomAll7 = $this->M_user->rekomendasi_produk_perusahaan($id_produk, '7','cek_rekom','false');
      $byRekomAll8 = $this->M_user->rekomendasi_produk_perusahaan($id_produk, '8','cek_rekom','false');
      $byRekomAll9 = $this->M_user->rekomendasi_produk_perusahaan($id_produk, '9','cek_rekom','false');
      $byRekomAll10 = $this->M_user->rekomendasi_produk_perusahaan($id_produk, '10','cek_rekom','false');

      $cariRekomAll = array($byRekomAll1, $byRekomAll2, $byRekomAll3, $byRekomAll4, $byRekomAll5, $byRekomAll6, $byRekomAll7, $byRekomAll8, $byRekomAll9, $byRekomAll10);

      if(max($cariRekomAll)==$byRekomAll1) { $no_rekomAll ='1';}
      elseif (max($cariRekomAll)==$byRekomAll2) {$no_rekomAll ='2';}
      elseif (max($cariRekomAll)==$byRekomAll3) {$no_rekomAll ='3';}
      elseif (max($cariRekomAll)==$byRekomAll4) {$no_rekomAll ='4';}
      elseif (max($cariRekomAll)==$byRekomAll5) {$no_rekomAll ='5';}
      elseif (max($cariRekomAll)==$byRekomAll6) {$no_rekomAll ='6';}
      elseif (max($cariRekomAll)==$byRekomAll7) {$no_rekomAll ='7';}
      elseif (max($cariRekomAll)==$byRekomAll8) {$no_rekomAll ='8';}
      elseif (max($cariRekomAll)==$byRekomAll9) {$no_rekomAll ='9';}
      elseif (max($cariRekomAll)==$byRekomAll10) {$no_rekomAll ='10';}

      $data['rekomedasi']=  $this->M_user->rekomendasi_produk_perusahaan($id_produk, $no_rekomAll,'get_rekom', 'false');
      //$data['rekomedasi']=  $this->M_user->rekomendasi_produk($id_produk);

      $data['chat_view'] =  $this->M_user->lihat_chat($valProduk->id_perusahaan_view);

      $data['plugin_v']='2';$this->load->view('frontend/user/header_1',$data);
      $this->load->view('frontend/user/produk_detail');
      $this->load->view('frontend/user/footer');
   }
//PRODUK END===============================================================
//PEMASANG START===========================================================
   function pemasang($jenis=null,$lokasi=null)
   {
      //  $data['seo'] = $this->home->seo(); //menampilkan meta title, keyword, deskripsi
      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();
      
      if (empty($jenis) && empty($lokasi)) {
         $loc = json_decode(file_get_contents("https://ipinfo.io/".$_SERVER['REMOTE_ADDR']."/json"));
         $data['jenis'] ='auto';
         $data['lokasi'] = $loc->city;
          //$data['lokasi'] =$this->session->userdata('kota');
      }else{
         $data['jenis'] = $jenis;
         $data['lokasi'] = $lokasi;
      }


      $data['cari'] = $this->input->get('cari');
      $data['kabupaten'] = $this->M_user->tampil_kota();
      $data['provinsi'] = $this->M_user->tampil_provinsi();
      $data['pemasang'] = $this->M_user->tampil_pemasang();
      $data['plugin_v']='2';$this->load->view('frontend/user/header_1',$data);
      $this->load->view('frontend/user/pemasang');
      $this->load->view('frontend/user/footer');
   }

   function pemasang_search()
   {
        //============================membuat array id perusahaan dari area operasi===1 
      $areaArray = $this->input->post('lokasi_kota');

      if (!empty($areaArray)) {
         $this->db->select("*");
         $this->db->where_in('area_pemasang', $areaArray);
         $this->db->group_by('id_pemasang');
         $data_area_operasi= $this->db->get('pemasang_area_kerja')->result_array();

         if (count($data_area_operasi) > 0)
         {
            foreach ($data_area_operasi as $key => $valueAO) {
               $kab[] = $valueAO['id_pemasang'];
            }
         }else{
           $kab ='x';
         }
      }else{
         $kab ='';
      }

        /*
        if (!empty($areaArray)) {
            $this->db->select("*");
            $this->db->where_in('kabupaten', $areaArray);
            $this->db->group_by('id_perusahaan');
            $data_area_operasi= $this->db->get('perusahaan_area_operasi')->result_array();

            if (count($data_area_operasi) > 0)
            {
                foreach ($data_area_operasi as $key => $valueAO) {
                  $kab[] = $valueAO['id_perusahaan'];
                }
            }else{
                $kab ='x';
            }
        }else{
            $kab ='';
         }*/
      $nama_teknisi = $this->input->post('nama_teknisi');
      $lokasi_kota = $this->input->post('lokasi_kota');
      $lokasi_provinsi = '';//$this->input->post('lokasi_provinsi');
      $keahlian = $this->input->post('keahlian');
      $harga_minimal = $this->input->post('harga_minimal');
      $harga_maximal = $this->input->post('harga_maximal');
      $rating = $this->input->post('rating');
      $sortir = $this->input->post('sortir');

      if (!empty($keahlian)) {
         $this->db->select("*");
         $this->db->where_in('keahlian', $keahlian);
         $this->db->group_by('id_pemasang');
         $dataKeahlian= $this->db->get('pemasang_keahlian')->result_array();
         if (count($dataKeahlian) > 0) {
            foreach ($dataKeahlian as $key => $valueKeahlian) {
               $keahlian_array[] = $valueKeahlian['id_pemasang'];
            }
         }else{
           $keahlian_array='x';
         }

      }else{
         $keahlian_array='';
      }

      $pemasang = $this->M_user->search_pemasang($nama_teknisi, $kab,/*$lokasi_provinsi,*/$keahlian_array, $harga_minimal, $harga_maximal, $rating, $sortir);

      $hasil = $this->load->view('frontend/user/pemasang_search', array('pemasang'=>$pemasang, 'keahlian' =>$keahlian, 'lokasi_kota' => $lokasi_kota,'lokasi_provinsi' => $lokasi_provinsi,'harga_minimal' =>$harga_minimal,'harga_maximal' =>$harga_maximal,'rating'=> $rating), true);

      $callback = array(
         'hasil' => $hasil,
         // Set array hasil dengan isi dari view.php yang diload tadi
      );
      echo json_encode($callback);
   }

   function pemasang_reset_search()
   {
      $nama_teknisi = $this->input->post('nama_teknisi');
      $sortir = $this->input->post('sortir');

      $pemasang = $this->M_user->search_reset_pemasang($nama_teknisi, $sortir);

      $hasil = $this->load->view('frontend/user/pemasang_search', array('pemasang'=>$pemasang), true);
       
      $callback = array(
          'hasil' => $hasil,
         // Set array hasil dengan isi dari view.php yang diload tadi
      );
        echo json_encode($callback); // konversi varibael $callback menjadi JSON
   }

   function pemasang_detail($id_pemasang=null)
   {
      if (empty($id_pemasang)) {redirect(base_url().'user/pemasang');}

      $get_pemasang = $this->db->get_where('pemasang_view', array('id_pemasang'=>$id_pemasang, 'status_publis_pemasang'=>'true', 'status_hapus_pemasang'=>'false','status_perusahaan'=>'aktiv'));
      $valPemasang=$get_pemasang->row();
      if(count($get_pemasang->result_array()) < 1){ redirect(base_url().'user/load');}

      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();

      $data['pemasang'] = $this->M_user->tampil_detail_pemasang($id_pemasang);
      // if(count($data['pemasang']) < 1){ redirect(base_url().'user/pemasang'); }
      $data['keahlian'] = $this->M_user->tampil_keahlian_pemasang($id_pemasang);
      $data['portofolio'] = $this->M_user->tampil_portofolio_pemasang($id_pemasang);
      $data['sertifikat'] = $this->M_user->tampil_sertifikat_pemasang($id_pemasang);
      $data['dataPerusahaan'] = $this->M_user->tampil_dataPerusahaan_pemasang($id_pemasang);
      $data['dataUser'] = $this->M_user->tampil_dataUser_pemasang($data['dataPerusahaan']->id_user);

      $data['ulasan']=  $this->M_user->ulasan_teknisi($id_pemasang);
      $data['chat_view'] =  $this->M_user->lihat_chat($valPemasang->id_perusahaan_view);

      $data['plugin_v']='2';$this->load->view('frontend/user/header_1',$data);
      $this->load->view('frontend/user/pemasang_detail');
      $this->load->view('frontend/user/footer');
   }

   function kirim_penawaran($id_pemasang)
   {
      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();
   
      $data['pemasang'] = $this->M_user->tampil_detail_pemasang($id_pemasang);
      // if(count($data['pemasang']) < 1){ redirect(base_url().'user/pemasang'); }
      $data['keahlian'] = $this->M_user->tampil_keahlian_pemasang($id_pemasang);

      $data['dataPerusahaan'] = $this->M_user->tampil_dataPerusahaan_pemasang($id_pemasang);
      $data['dataUser'] = $this->M_user->tampil_dataUser_pemasang($data['dataPerusahaan']->id_user);
      $data['provinsi'] = $this->M_user->tampil_provinsi();
      $data['rekening'] = $this->M_user->tampil_rekening();

      $data['plugin_v']='2';$this->load->view('frontend/user/header_1',$data);
      $this->load->view('frontend/user/pemasang_form_penawaran');
      $this->load->view('frontend/user/footer');
   }

   function cek_tanggal_penawaran()
   {
      $id = $this->input->post('id');
      $tanggal = $this->input->post('tanggal');                   

      $cek_penawaran= $this->db->get_where('pemasang_penawaran', array('id_pemasang'=>$id,'tanggal_pengerjaan'=>$tanggal))->result_array();

      $hasil = count($cek_penawaran);
      $callback = array(
        'hasil' => $hasil,

      );
      echo json_encode($callback); 
   }

   function simpan_penawaran()
   {
      $nama_proyek = $this->input->post('nama_proyek',TRUE);
      $keahlian = $this->input->post('keahlian',TRUE);
      $keterangan = $this->input->post('keterangan',TRUE);
      $dokumen = $this->input->post('dokumen',TRUE);
      $area = array_unique($this->input->post('areaPenawaran',TRUE));
      $bank = $this->input->post('bank',TRUE);
      $harga = $this->input->post('harga',TRUE);
      $nama_rekening =$this->input->post('nama_rekening',TRUE);
      $no_rekening = $this->input->post('no_rekening',TRUE);
      $tgl_pengerjaan = $this->input->post('tgl_pengerjaan',TRUE);
      $id_user = $this->input->post('id_user',TRUE);
      $id_pemasang = $this->input->post('id_pemasang',TRUE);

       /* echo $nama_proyek.'<br>';
        echo $keahlian.'<br>';
        echo $keterangan.'<br>';
        echo $_FILES["dokumen"]["name"].'<br>';
        echo implode(', ',$area).'<br>';
        echo $id_user.'<br>';
        echo $id_pemasang;*/


       $new_name = $this->session->userdata('id_user').'_penawaran_'.date("d").''.date("m").''.date("y").''.date("H").''.date("i").''.date("s").'_'.substr($_FILES["dokumen"]["name"], -7);


        
      if ($this->M_user->simpan_penawaran($nama_proyek, $keahlian, $keterangan, $harga, $area, $new_name, $id_user, $id_pemasang, $bank, $nama_rekening, $no_rekening, $tgl_pengerjaan) == TRUE) {

         if (!empty($_FILES["dokumen"]["name"])) {

           $config['upload_path'] = './upload_file/'.$this->session->userdata('folder').'/penawaran/';
           $config['allowed_types'] = 'pdf|jpeg|jpg|png|docx';
           $config['file_name'] = $new_name;
           $this->upload->initialize($config);
           $this->upload->do_upload('dokumen');
           $data = $this->upload->data();
                        //Compress Image
           $config['image_library']='gd2';
           $config['source_image']='./upload_file/'.$this->session->userdata('folder').'/penawaran/'.$data['file_name'];
           $config['create_thumb']= FALSE;
           $config['maintain_ratio']= TRUE;
           $config['quality']= '100%';
                        //$config['width']= 720;
                        //$config['height']= 300;
           $config['new_image']= './upload_file/'.$this->session->userdata('folder').'/penawaran/'.$data['file_name'];
           $this->load->library('image_lib', $config);
           $this->image_lib->resize();

        }

        $this->session->set_flashdata('notif' , true);
        $this->session->set_flashdata('teks_notif' , "Proyek berhasil ditambahkan ".$notif_session);
        redirect(base_url() . "user/kirim_penawaran/".$id_pemasang);
      }else{
         $this->session->set_flashdata('notif' , false);
         $this->session->set_flashdata('teks_notif' , "Gagal");
         redirect(base_url() . "user/kirim_penawaran/".$id_pemasang);
      }
   }
//PEMASANG END=============================================================
//PENAWARAN START==========================================================
   function penawaran_teknisi()
   {
      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();

      $data['penawaran'] = $this->M_user->daftar_penawaran();
      $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
      $this->load->view('frontend/user/pemasang_daftar_penawaran');
      $this->load->view('frontend/user/footer');
   }

   function detail_penawaran($id_penawaran=null)
   {
      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();

      $data['penawaran'] = $this->M_user->detail_penawaran($id_penawaran);
      $data['pembayaran'] = $this->M_user->pembayaran_penawaran($id_penawaran);
      $data['id']=$id_penawaran;
      $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
      $this->load->view('frontend/user/pemasang_detail_penawaran');
      $this->load->view('frontend/user/footer');
   }

   function penawaran_invoice($id_penawaran=null)
   {
      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();

      $data['penawaran'] = $this->M_user->detail_penawaran($id_penawaran);
      $data['pembayaran'] = $this->M_user->pembayaran_penawaran($id_penawaran);
      $data['id']=$id_penawaran;
      $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
      $this->load->view('frontend/user/pemasang_invoice_penawaran');
      $this->load->view('frontend/user/footer');
   }

   function pembayaran_penawaran()
   {
      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();

      $data['penawaran'] = $this->M_user->daftar_pembayaran_penawaran();
      $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
      $this->load->view('frontend/user/pemasang_pembayaran_penawaran');
      $this->load->view('frontend/user/footer');
   }

   function simpan_pembayaran_penawaran()
   {
      $id_penawaran = $this->input->post('id');
      $no_invoice = $this->input->post('no_invoice');
      $no_invoice_re = str_replace('/', '-',$this->input->post('no_invoice'));
      $pembayaran = $this->input->post('pembayaran');
      $nominal = str_replace('.', '',$this->input->post('nominal'));
      $bukti_pembayaran = $no_invoice_re.'-'.date("dmyHis").'.png';

      $this->M_user->simpan_pembayaran_penawaran($no_invoice, $nominal, $bukti_pembayaran);

      $_FILES["pembayaran"]["name"];

      $config['upload_path'] = './upload_file/pembayaran/';
      $config['allowed_types'] = 'jpg|jpeg|png|gif|bmp';
      $config['file_name'] = $bukti_pembayaran;
      $this->upload->initialize($config);
      $this->upload->do_upload('pembayaran');
      $data = $this->upload->data();
            //Compress Image
      $config['image_library']='gd2';
      $config['source_image']='./upload_file/pembayaran/'.$data['file_name'];
      $config['create_thumb']= FALSE;
      $config['maintain_ratio']= TRUE;
      $config['quality']= '100%';
      //$config['width']= 720;
      //$config['height']= 300;
      $config['new_image']= './upload_file/pembayaran/'.$data['file_name'];
      $this->load->library('image_lib', $config);
      $this->image_lib->resize();

      $data1 = array(
       'status_penawaran' => 'menunggu_verifikasi_pembayaran'
      );
      $this->db->where('id_penawaran' , $id_penawaran);
      $this->db->update('pemasang_penawaran' , $data1);

      redirect(base_url().'user/pembayaran_penawaran/'.$id_penawaran);
   }

   function ulasan_penawaran()
   {
      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();

      $data['penawaran'] = $this->M_user->daftar_penawaran();
      $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
      $this->load->view('frontend/user/pemasang_daftar_ulasan_penawaran');
      $this->load->view('frontend/user/footer');
   }

   function beri_ulasan($id_penawaran = null, $id_perusahaan = null, $id_teknisi = null, $etalase = null)
   {
      if (!empty($id_penawaran) && !empty($id_teknisi)) {
         $cek_penawaran = $this->db->get_where('pemasang_penawaran', array('id_penawaran'=> $id_penawaran))->result();
         $cek_teknisi = $this->db->get_where('perusahaan_pemasang', array('id_pemasang'=> $id_teknisi))->result();
         if(count($cek_penawaran) < 1 || count($cek_teknisi) < 1){redirect(base_url().'user/ulasan_penawaran','refresh');}
      }else{redirect(base_url().'user/ulasan_penawaran','refresh');}
       $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();
      $data['penawaran'] = $this->db->get_where('pemasang_penawaran', array('id_penawaran'=> $id_penawaran))->row();
      $data['teknisi'] = $this->db->get_where('pemasang_view', array('id_pemasang'=> $id_teknisi))->row();

      $data['id_penawaran']=$id_penawaran;
      $data['id_perusahaan']=$id_perusahaan;
      $data['id_teknisi']=$id_teknisi;
      $data['etalase']=$etalase;

      $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
      $this->load->view('frontend/user/ulasan_penawaran_form');
      $this->load->view('frontend/user/footer');
   }

   function simpan_ulasan_penawaran()
   {

      $rating=$this->input->post('rating');  
      $ulasan=$this->input->post('ulasan');  
      $id_user=$this->input->post('id_user');  
      $id_penawaran=$this->input->post('id_penawaran');  
      $id_perusahaan=$this->input->post('id_perusahaan');  
      $id_teknisi=$this->input->post('id_teknisi');
      $etalase=$this->input->post('etalase');    

      if ($this->M_user->simpan_ulasan_penawaran($rating, $ulasan, $id_user, $id_penawaran, $id_perusahaan, $id_teknisi, $etalase) == TRUE) {
         $this->M_user->simpan_rating_pemasang($id_teknisi, $etalase);
         $this->M_user->simpan_rating_perusahaan($id_perusahaan);

         $this->session->set_flashdata('notif' , true);
         $this->session->set_flashdata('teks_notif' , "Ulasan disimpan");
         redirect(base_url() . "user/ulasan_penawaran");
      }else{
         $this->session->set_flashdata('notif' , false);
         $this->session->set_flashdata('teks_notif' , "Ulasan gagal disimpan");
         redirect(base_url() . "user/ulasan_penawaran");
      }
   }
//PENAWARAN END============================================================
//PERUSAHAAN START=========================================================
   function perusahaan($jenis=null,$lokasi=null)
   {
      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();
        
      if (empty($jenis) && empty($lokasi)) {
         $loc = json_decode(file_get_contents("https://ipinfo.io/".$_SERVER['REMOTE_ADDR']."/json"));
         $data['jenis'] ='auto';
         $data['lokasi'] = $loc->city;
         //$data['lokasi'] =$this->session->userdata('kota');
       }else{
         $data['jenis'] = $jenis;
         $data['lokasi'] = $lokasi;
      }

      $data['cari'] = $this->input->get('cari');
      $data['kabupaten'] = $this->M_user->tampil_kota();
      $data['provinsi'] = $this->M_user->tampil_provinsi();
      $data['perusahaan'] = $this->M_user->tampil_perusahaan();
      $data['plugin_v']='2';$this->load->view('frontend/user/header_1',$data);
      $this->load->view('frontend/user/perusahaan');
      $this->load->view('frontend/user/footer');
   }

   function perusahaan_search()
   {
      $areaArray = $this->input->post('lokasi_kota');
      if (!empty($areaArray)) {
         $this->db->select("*");
         $this->db->where_in('kabupaten', $areaArray);
         $this->db->group_by('id_perusahaan');
         $data_area_operasi= $this->db->get('perusahaan_area_operasi')->result_array();

         if (count($data_area_operasi) > 0)
         {
            foreach ($data_area_operasi as $key => $valueAO) {
               $kab[] = $valueAO['id_perusahaan'];
            }
         }else{
            $kab ='x';
         }
      }else{
       $kab ='';
      }

      $nama_perusahaan = $this->input->post('nama_perusahaan');
      $lokasi_kota = $this->input->post('lokasi_kota');
      $lokasi_provinsi = '';//$this->input->post('lokasi_provinsi');
      $pembayaran_cash = $this->input->post('pembayaran_cash');
      $pembayaran_kredit = $this->input->post('pembayaran_kredit');
      $rating = $this->input->post('rating');
      $sortir = $this->input->post('sortir');                   

      $perusahaan = $this->M_user->search_perusahaan($nama_perusahaan, $kab,/* $lokasi_provinsi,*/$pembayaran_cash, $pembayaran_kredit, $rating, $sortir);

      $hasil = $this->load->view('frontend/user/perusahaan_search', array('perusahaan'=>$perusahaan,'lokasi_kota' => $lokasi_kota,'lokasi_provinsi' => $lokasi_provinsi,'pembayaran_cash' => $pembayaran_cash,'pembayaran_kredit' => $pembayaran_kredit,'rating'=> $rating), true);

      $callback = array(
         'hasil' => $hasil,

      );
      echo json_encode($callback);
   }

   function perusahaan_reset_search()
   {
      $nama_perusahaan = $this->input->post('nama_perusahaan');
      $sortir = $this->input->post('sortir');                   

      $perusahaan = $this->M_user->search_reset_perusahaan($nama_perusahaan, $sortir);

      $hasil = $this->load->view('frontend/user/perusahaan_search', array('perusahaan'=>$perusahaan), true);

      $callback = array(
        'hasil' => $hasil,
      );
      echo json_encode($callback);

   }

   function perusahaan_detail($id_perusahaan)
   {
      if (empty($id_perusahaan)) {redirect(base_url().'user/perusahaan');}

      $get_perusahaan = $this->db->get_where('perusahaan', array('id_perusahaan'=>$id_perusahaan, 'status_perusahaan'=>'aktiv'));
      $valPerusahaan=$get_perusahaan->row();
      if(count($get_perusahaan->result_array()) < 1){ redirect(base_url().'user/load');}
      $this->session->set_userdata('id_perusahaan_detail', $id_perusahaan);
      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();
       
      $data['banner'] = $this->M_user->tampil_banner($id_perusahaan);
      $data['perusahaan'] = $this->M_user->detail_perusahaan($id_perusahaan);

      $data['produk_terbaru'] = $this->M_user->detail_perusahaan_produk_terbaru($id_perusahaan);

      $data['chat_view'] =  $this->M_user->lihat_chat($id_perusahaan);
      $data['plugin_v']='2';$this->load->view('frontend/user/header_1',$data);
      $this->load->view('frontend/user/perusahaan_detail');
      $this->load->view('frontend/user/perusahaan_beranda');
      $this->load->view('frontend/user/footer');
   }

   function chat_modal_send()
   {
       $chat = $this->input->post('chat');
       $id_perusahaan = $this->input->post('id_perusahaan');
       $jenis = $this->input->post('jenis');
       $pengirim = $this->input->post('pengirim');                         

       $this->M_user->send_chat($chat, $id_perusahaan, $jenis, $pengirim);
       $chatView =  $this->M_user->lihat_chat($id_perusahaan);
       $chat_view = $this->load->view('frontend/user/chat_modal_view', array('chat_view'=>$chatView), true);

       $callback = array(
        'chat_view' => $chat_view
      );
       echo json_encode($callback);

   }

   function chat_view_modal()
   {
      $id_perusahaan = $this->input->post('id_perusahaan');    
      $count_chat=$this->db->get_where('chat', array('id_perusahaan'=>$id_perusahaan, 'id_user'=>$this->session->userdata('id_user')))->result_array();                    
      $chatView =  $this->M_user->lihat_chat($id_perusahaan);
      $chat_view = $this->load->view('frontend/user/chat_modal_view', array('chat_view'=>$chatView), true);

      $callback = array(
        'chat_view' => $chat_view,
        'chat_count'=>count($count_chat)
      );
       echo json_encode($callback);
   }

   function perusahaan_produk()
   {
       $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
       $data['medsos'] = $this->Website->medsosweb();
          
       $data['perusahaan'] = $this->M_user->detail_perusahaan($this->session->userdata('id_perusahaan_detail'));
       $data['produk'] = $this->M_user->detail_perusahaan_produk($this->session->userdata('id_perusahaan_detail'));
       $data['chat_view'] =  $this->M_user->lihat_chat($this->session->userdata('id_perusahaan_detail'));
       $data['plugin_v']='2';$this->load->view('frontend/user/header_1',$data);
       $this->load->view('frontend/user/perusahaan_detail');
       $this->load->view('frontend/user/perusahaan_produk');
       $this->load->view('frontend/user/footer');
   }

   function perusahaan_produk_sortir()
   {
      $folder_user = $this->input->post('folder_user'); 
      $sortir = $this->input->post('sortir');                   
      $produk = $this->M_user->perusahaan_produk_sortir($this->session->userdata('id_perusahaan_detail'),$sortir);
      $hasil = $this->load->view('frontend/user/perusahaan_produk_view', array('produk'=>$produk, 'folder_user'=>$folder_user), true);

      $callback = array(
      'hasil' => $hasil,

      );
      echo json_encode($callback);
   }

   function perusahaan_pemasang()
   {
      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();
      
      $data['perusahaan'] = $this->M_user->detail_perusahaan($this->session->userdata('id_perusahaan_detail'));
      $data['pemasang'] = $this->M_user->detail_perusahaan_pemasang($this->session->userdata('id_perusahaan_detail'));
      $data['chat_view'] =  $this->M_user->lihat_chat($this->session->userdata('id_perusahaan_detail'));
      $data['plugin_v']='2';$this->load->view('frontend/user/header_1',$data);
      $this->load->view('frontend/user/perusahaan_detail');
      $this->load->view('frontend/user/perusahaan_pemasang');
      $this->load->view('frontend/user/footer');
   }

   function perusahaan_pemasang_sortir()
   {
      $folder_user = $this->input->post('folder_user'); 
      $sortir = $this->input->post('sortir');                   
      $pemasang = $this->M_user->perusahaan_pemasang_sortir($this->session->userdata('id_perusahaan_detail'),$sortir);
      $hasil = $this->load->view('frontend/user/perusahaan_pemasang_view', array('pemasang'=>$pemasang, 'folder_user'=>$folder_user), true);

      $callback = array(
        'hasil' => $hasil,
      );
      echo json_encode($callback);
   }

   function perusahaan_ulasan()
   {
      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();
       
      $data['perusahaan'] = $this->M_user->detail_perusahaan($this->session->userdata('id_perusahaan_detail'));
      $data['ulasan'] = $this->M_user->detail_perusahaan_produk($this->session->userdata('id_perusahaan_detail'));
      $data['chat_view'] =  $this->M_user->lihat_chat($this->session->userdata('id_perusahaan_detail'));
      $data['plugin_v']='2';$this->load->view('frontend/user/header_1',$data);
      $this->load->view('frontend/user/perusahaan_detail');
      $this->load->view('frontend/user/perusahaan_ulasan');
      $this->load->view('frontend/user/footer');
   }
//PERUSAHAAN END===========================================================
   function hapusfolderproduk()
   {
      $dir_produk = 'upload_file/12345/img/perusahaan/produk/mantap';

      $glob_slide_produk = glob($dir_produk.'/slide/*');
      foreach ($glob_slide_produk as $glob_slide_produk_ex) {
        unlink($glob_slide_produk_ex);
              // $sf = scandir($g,1);
              /*  foreach ($sf as $sfc) {
                   if ($sfc != '.' && $sfc != '..') {
                        echo $dir2,$sfc.'<br>';
                   }
                }   */
              // echo $g.'<br>';
      }
      unlink($dir_produk.'/coverProduk.png'); 
      rmdir($dir_produk.'/slide');
      rmdir($dir_produk);
   }

   function hapusfolderpemasang()
   {
      $dir_pemasang = 'upload_file/12345/img/perusahaan/pemasang/paman';
      /*  $glob_slide_pemasang = glob($dir_pemasang.'/slide/*');
        foreach ($glob_slide_pemasang as $glob_slide_pemasang_ex) {
            unlink($glob_slide_pemasang_ex);
        }

        $glob_sertifikat_pemasang = glob($dir_pemasang.'/sertifikat/*');
        foreach ($glob_sertifikat_pemasang as $glob_sertifikat_pemasang_ex) {
            unlink($glob_sertifikat_pemasang_ex);
         }*/

      $scandir_portofolio_pemasang = scandir($dir_pemasang.'/portofolio',1);
      foreach ($scandir_portofolio_pemasang as $scandir_portofolio_pemasang_ex) {
        // unlink($glob_sertifikat_pemasang_ex);
         if ($scandir_portofolio_pemasang_ex != '.' && $scandir_portofolio_pemasang_ex != '..'){
            // echo $dir_pemasang.'/portofolio/'.$scandir_portofolio_pemasang_ex.'/<br>';

            $glob_protofolio_pemasang = glob($dir_pemasang.'/portofolio/'.$scandir_portofolio_pemasang_ex.'/*');
            echo $dir_pemasang.'/portofolio/'.$scandir_portofolio_pemasang_ex.'<br>';
               /* foreach ($glob_protofolio_pemasang as $glob_protofolio_pemasang_ex) {
                    //unlink($glob_protofolio_pemasang_ex);
                    echo $glob_protofolio_pemasang.'<br>';
                 }*/
         }

      }

      /*unlink($dir_pemasang.'/ktp.png'); unlink($dir_pemasang.'/profil.png'); 
        rmdir($dir_pemasang.'/slide');
        rmdir($dir_pemasang.'/sertifikat');
        rmdir($dir_pemasang.'/portofolio');*/
   }

//CHAT START===============================================================
   function chat_perusahaan($id_perusahaan, $jenis_chat, $pengirim)
   {
       $data['id_perusahaan']= $id_perusahaan;
       $data['jenis_chat']= $jenis_chat;
       $data['pengirim']= $pengirim;

       $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
       $data['medsos'] = $this->Website->medsosweb();

       $data['daftar_chat'] = $this->M_user->tampil_chat();

       $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
       $this->load->view('frontend/user/chat');
       $this->load->view('frontend/user/footer');
   }
    
   function chat()
   {
       $data['id_perusahaan']= '0';
       $data['jenis_chat']= 'text';
       $data['pengirim']= 'user';

       $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
       $data['medsos'] = $this->Website->medsosweb();

       $data['daftar_chat'] = $this->M_user->tampil_chat();

       $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
       $this->load->view('frontend/user/chat');
       $this->load->view('frontend/user/footer');
   }

   function send_chat()
   {
       $chat = $this->input->post('chat');
       $id_perusahaan = $this->input->post('id_perusahaan');
       $jenis = $this->input->post('jenis');
       $pengirim = $this->input->post('pengirim');                         

       $this->M_user->send_chat($chat, $id_perusahaan, $jenis, $pengirim);

       $daftarChat = $this->M_user->daftar_chat();
       $chatView =  $this->M_user->lihat_chat($id_perusahaan);


       $daftar_chat = $this->load->view('frontend/user/chat_daftar', array('daftar_chat'=>$daftarChat), true);
       $chat_view = $this->load->view('frontend/user/chat_view', array('chat_view'=>$chatView), true);

       $callback = array(
        'daftar_chat' => $daftar_chat,
        'chat_view' => $chat_view
      );
      echo json_encode($callback);

   }

   function view_daftar_chat()
   {
      $daftarChat = $this->M_user->daftar_chat();
      $daftar_chat = $this->load->view('frontend/user/chat_daftar', array('daftar_chat'=>$daftarChat), true);
      $callback = array(
        'daftar_chat' => $daftar_chat
      );
      echo json_encode($callback);
   }

   function view_chat()
   {
       $id_perusahaan = $this->input->post('id_perusahaan');           
       $get_perusahaan=$this->db->get_where('perusahaan_view', array('id_perusahaan'=>$id_perusahaan))->row();             
       $count_chat=$this->db->get_where('chat', array('id_perusahaan'=>$id_perusahaan, 'id_user'=>$this->session->userdata('id_user')))->result_array(); 
       $daftarChat = $this->M_user->daftar_chat();
       $chatView =  $this->M_user->lihat_chat($id_perusahaan);


       $daftar_chat = $this->load->view('frontend/user/chat_daftar', array('daftar_chat'=>$daftarChat), true);
       $chat_view = $this->load->view('frontend/user/chat_view', array('chat_view'=>$chatView, 'nama_epc'=>$get_perusahaan->nama_perusahaan, 'folder'=>$get_perusahaan->folder), true);

       $callback = array(
        'daftar_chat' => $daftar_chat,
        'chat_view' => $chat_view,
        'count_chat'=>count($count_chat),
        'nama_epc'=>$get_perusahaan->nama_perusahaan,
        'folder'=> $get_perusahaan->folder
      );
      echo json_encode($callback);
   }
//CHAT END=================================================================
//LELANG START=============================================================
   function proyek()
   {
       $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
       $data['medsos'] = $this->Website->medsosweb();
       $data['bidding'] = $this->M_user->bidding_berlangasung();
       $cek_bidding = $this->db->get_where('bidding',array('id_user'=>$this->session->userdata('id_user'),'status_bidding'=> 'berlangsung'))->result();

       $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
       if (count($cek_bidding)  < 1 ) {
         $this->load->view('frontend/user/bidding_no');
      }else{
         $this->load->view('frontend/user/bidding');
      }
      $this->load->view('frontend/user/footer');
   }

   function proyek_diproses()
   {
      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();
      $data['bidding'] = $this->M_user->bidding_diproses();
      $cek_bidding = $this->db->get_where('bidding',array('id_user'=>$this->session->userdata('id_user'),'status_bidding'=> 'diproses'))->result();

      $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
      $this->load->view('frontend/user/bidding_diproses');
      $this->load->view('frontend/user/footer');
   }

   function proyek_dikerjakan()
   {
      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();
      $data['bidding'] = $this->M_user->bidding_dikerjakan();
      $cek_bidding = $this->db->get_where('bidding',array('id_user'=>$this->session->userdata('id_user'),'status_bidding'=> 'berlangsung'))->result();

      $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
      $this->load->view('frontend/user/bidding_dikerjakan');
       $this->load->view('frontend/user/footer');
   }

   function daftar_bidding()
   {
      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();

      $data['bidding'] = $this->M_user->daftar_bidding();
      $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
      $this->load->view('frontend/user/bidding_daftar');
      $this->load->view('frontend/user/footer');
   }

   function detail_bidding($id_bidding = null)
   {
       if (empty(preg_replace("/[^0-9]/","",$id_bidding))) {redirect(base_url().'user/daftar_bidding');}

       $get_bidding = $this->db->get_where('bidding', array('id_bidding'=>$id_bidding));
       $valueBidding=$get_bidding->row();
       if(count($get_bidding->result_array()) < 1){ redirect(base_url().'user/daftar_bidding');}

       $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
       $data['medsos'] = $this->Website->medsosweb();

       $data['bidding'] = $this->M_user->detail_bidding($id_bidding);
       $data['area'] = $this->M_user->area_bidding($id_bidding);
       $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
       $this->load->view('frontend/user/bidding_detail');
       $this->load->view('frontend/user/footer');
   }

   function tambah_proyek($budget=null, $ukuran_sistem=null, $lokasi=null)
   {
       $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
       $data['medsos'] = $this->Website->medsosweb();
       $data['provinsi'] = $this->M_user->tampil_provinsi();
       $data['robot_budget']=$budget;
       $data['robot_ukuran_sistem']=$ukuran_sistem;
       $data['robot_lokasi']=$lokasi;

       $get_proyek=$this->db->get_where('bidding', array('id_user'=>$this->session->userdata('id_user'), 'status_bidding'=>'berlangsung'))->result_array();

       $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
       if (count($get_proyek)>0) {
         $this->load->view('frontend/user/bidding_form_no');
      }else{
         $this->load->view('frontend/user/bidding_form');
      }
      $this->load->view('frontend/user/footer');
   }

   function tambah_c()
   {
       $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
       $data['medsos'] = $this->Website->medsosweb();
       $data['provinsi'] = $this->M_user->tampil_provinsi();

             //$data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
       $this->load->view('frontend/user/dinamis');
              //$this->load->view('frontend/user/footer');
   }

   function simpan_bidding()
   {
      $nama_bidding = $this->input->post('nama_bidding',TRUE);
      $kategori = $this->input->post('kategori',TRUE);
      $keterangan = $this->input->post('keterangan',TRUE);
      $budget = str_replace(".", "",$this->input->post('budget',TRUE));
      $dokumen = $this->input->post('dokumen',TRUE);
      $ukuran_sistem = $this->input->post('ukuran_sistem',TRUE);
      $batas_penawaran = $this->input->post('batas_penawaran',TRUE);
      $area = $this->input->post('areaBidding',TRUE);

      $new_name = $this->session->userdata('id_user').'_proyek_'.date("d").''.date("m").''.date("y").''.date("H").''.date("i").''.date("s").'_'.substr($_FILES["dokumen"]["name"], -7);

      /*echo $nama_bidding,"<br>";
      echo $kategori."<br>";
      echo $keterangan."<br>";
      echo $budget."<br>";
      echo $_FILES["dokumen"]["name"]."<br>";
      echo base_url()."upload_file/".$this->session->userdata('folder')."/bidding<br>";
      echo $new_name."<br>";
      echo $ukuran_sistem."<br>";
      echo $batas_penawaran."<br>";
      echo implode('|',$area);*/
        
      if ($this->M_user->simpan_bidding($nama_bidding, $kategori, $keterangan, $budget, $new_name, $ukuran_sistem, $batas_penawaran) == TRUE) {

         $_FILES["dokumen"]["name"];

         $config['upload_path'] = './upload_file/'.$this->session->userdata('folder').'/bidding/';
         $config['allowed_types'] = 'pdf|jpeg|jpg|png|docx';
         $config['file_name'] = $new_name;
         $this->upload->initialize($config);
         $this->upload->do_upload('dokumen');
         $data = $this->upload->data();
                    //Compress Image
         $config['image_library']='gd2';
         $config['source_image']='./upload_file/'.$this->session->userdata('folder').'/bidding/'.$data['file_name'];
         $config['create_thumb']= FALSE;
         $config['maintain_ratio']= TRUE;
         $config['quality']= '100%';
                    //$config['width']= 720;
                    //$config['height']= 300;
         $config['new_image']= './upload_file/'.$this->session->userdata('folder').'/bidding/'.$data['file_name'];
         $this->load->library('image_lib', $config);
         $this->image_lib->resize();

         $id_bidding_terbaru = $this->M_user->get_id_bidding();

         $areacek = array_unique($area); //jika ada area yanga sama
         $result = array();
         foreach ($areacek as $key => $val) {
            $result[] = array(      
               'id_bidding' => $id_bidding_terbaru->id_bidding,
               'lokasi' => $areacek[$key],
               'input_bidding_area' => date('Y-m-d')
            );  
         }       
         $this->db->insert_batch('bidding_area',$result); 

         if ($ukuran_sistem > 15) {
            $notif_session = 'dan menunggu di verifikasi admin';
         }else{
            $get_perusahaan = $this->M_user->tampil_perusahaan_send_bidding();
            $areaBidding=implode(",", $area);
            $this->load->library('mailer');
            foreach ($get_perusahaan as $key => $value) {
               $content =  $this->load->view('frontend/template_email/bidding_email',array('id_bidding'=>$id_bidding_terbaru->id_bidding,'id_perusahaan'=>$value['id_perusahaan'],'dibuat'=>date('d-m-Y'),'nama_bidding'=>$nama_bidding,'kategori'=>$kategori,'keterangan'=>$keterangan,'budget'=>$budget,'ukuran_sistem'=>$ukuran_sistem, 'batas_penawaran'=>$batas_penawaran,'area'=> $areaBidding), true);
                $recipient_email = $value['link'];
                $subject = 'Lelang';
                       // Ambil isi file content.php dan masukan ke variabel $content
                $sendmail = array(
                  'email_penerima'=>$recipient_email,
                        'subject'=>$subject,//$subject,
                        'content'=>$content
                              //'attachment'=>$attachment
                     );
                $send = $this->mailer->send($sendmail);
             }
             $notif_session = '';
         }

         $this->session->set_flashdata('notif' , true);
         $this->session->set_flashdata('teks_notif' , "Proyek berhasil ditambahkan ".$notif_session);
         redirect(base_url() . "user/tambah_proyek");
       }else{
         $this->session->set_flashdata('notif' , false);
         $this->session->set_flashdata('teks_notif' , "Gagal");
         redirect(base_url() . "user/tambah_proyek");
      }
   }

   function reload_epc()
   {
      $id_bidding = $this->input->post('id_bidding');

      $daftar_epc_bidding = $this->M_user->reload_epc($id_bidding);

      $hasil = $this->load->view('frontend/user/bidding_mengajukan', array('epc'=>$daftar_epc_bidding), true);

      $callback = array(
        'hasil' => $hasil
      );
      echo json_encode($callback); 
   }

   function hitung_epc()
   {
      $id_bidding = $this->input->post('id_bidding');

      $daftar_epc_bidding = $this->M_user->reload_epc($id_bidding);
      $hasil=count($daftar_epc_bidding);
      $callback = array(
         'hasil' => $hasil
      );
      echo json_encode($callback);
   }

   function lihat_epc()
   {
      $id_bidding_take = $this->input->post('id_bidding');
      $id_perusahaan = $this->input->post('id_perusahaan');

      $detail_bidding_take = $this->M_user->lihat_epc_take($id_bidding_take, $id_perusahaan);

      $hasil = $this->load->view('frontend/user/bidding_detail_epc', array('bidding_take'=>$detail_bidding_take), true);
           //$hasil=$id_bidding_take.' '.$id_perusahaan;
      $callback = array(
         'hasil' => $hasil
      );
      echo json_encode($callback);
   }

   function checkout_lelang($id_bidding=null,$id_bidding_take=null,$id_perusahaan=null)
   {
      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();

      $data['bidding'] = $this->M_user->detail_bidding($id_bidding);
      $data['area_bidding'] = $this->M_user->area_bidding($id_bidding);
      $data['bidding_take'] = $this->M_user->lihat_epc_take($id_bidding, $id_perusahaan);
      $data['epc'] = $this->M_user->detail_epc($id_perusahaan);
      $data['rekening'] = $this->M_user->tampil_rekening();
      $data['id_bidding']=$id_bidding;$data['id_bidding_take']=$id_bidding_take;$data['id_perusahaan']=$id_perusahaan;

      $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
      $this->load->view('frontend/user/bidding_checkout');
      $this->load->view('frontend/user/footer');
   }

   function pilih_pemenang()
   {    
      $id_bidding=$this->input->post('id_bidding');   
      $id_bidding_take=$this->input->post('id_bidding_take');                             
      $id_perusahaan=$this->input->post('id_perusahaan');                                                             
      $estimasi_budget_nego=$this->input->post('estimasi_budget_nego');               
      $bank=$this->input->post('bank');               
      $nama_rek=$this->input->post('nama_rek');                   
      $no_rek=$this->input->post('no_rek');

      //if (!empty($estimasi_budget_nego)) {
      $data = array(
         'budget'=>str_replace(".", "",$estimasi_budget_nego),
         'status_bidding' => 'diproses'
      );
      $this->db->where('id_bidding' , $id_bidding);
      $this->db->update('bidding' , $data);
      /*}else{
      $data = array(
           'status_bidding' => 'diproses'
       );
      $this->db->where('id_bidding' , $id_bidding);
      $this->db->update('bidding' , $data);
      }*/

      $data2 = array(
        'status_bidding_take' => 'tidak_menang'
      );
      $this->db->where('id_bidding' , $id_bidding);
      $this->db->where_not_in('id_perusahaan' , $id_perusahaan);
      $this->db->update('bidding_take' , $data2);

      $data3 = array(
         'no_invoice'=> 'INV/U'.$this->session->userdata('id_user').'/BD'.$id_bidding_take.'/'.$id_perusahaan.'/'.date("Ymd/His"),
         'tgl_invoice'=> date('Y-m-d'),
         'bank'=>$bank,
         'nama_rek'=>$nama_rek,
         'no_rek'=>$no_rek,
         'status_bidding_take' => 'menunggu_pembayaran',
         'terpilih'=>date('Y-m-d')
      );
      $this->db->where('id_bidding' , $id_bidding);
      $this->db->where('id_perusahaan' , $id_perusahaan);
      $this->db->update('bidding_take' , $data3);

      $get_bidding_take =$this->db->get_where('bidding_take', array('id_bidding'=>$id_bidding))->result_array();
      $no=0;
      foreach ($get_bidding_take as $key => $valueBiddingTake) {
         $no++;
         if ($valueBiddingTake['id_perusahaan']!= $id_perusahaan) {
           unlink('./'.$valueBiddingTake['link'].'/'.$valueBiddingTake['dokumen']);
         }
      }
      $this->session->set_flashdata('notif' , true);
      $this->session->set_flashdata('teks_notif' , "Pemenang telah dipilih, Silahkan Lanjutkan Pembayaran");
      redirect(base_url() . "user/pembayaran_proyek");
   }

   function simpan_pembayaran_lelang()
   {
      $id_bidding_take = $this->input->post('id_bidding_take');
      $id_bidding = $this->input->post('id_bidding');
      $no_invoice = $this->input->post('no_invoice');
      $no_invoice_re = str_replace('/', '-',$this->input->post('no_invoice'));
      $pembayaran = $this->input->post('pembayaran');
      $nominal = str_replace('.', '',$this->input->post('nominal'));
      $bukti_pembayaran = $no_invoice_re.'-'.date("dmyHis").'.png';

      $this->M_user->simpan_pembayaran_lelang($id_bidding_take, $nominal, $bukti_pembayaran);

      $_FILES["pembayaran"]["name"];

      $config['upload_path'] = './upload_file/pembayaran/';
      $config['allowed_types'] = 'jpg|jpeg|png|gif|bmp';
      $config['file_name'] = $bukti_pembayaran;
      $this->upload->initialize($config);
      $this->upload->do_upload('pembayaran');
      $data = $this->upload->data();
            //Compress Image
      $config['image_library']='gd2';
      $config['source_image']='./upload_file/pembayaran/'.$data['file_name'];
      $config['create_thumb']= FALSE;
      $config['maintain_ratio']= TRUE;
      $config['quality']= '100%';
           //$config['width']= 720;
           //$config['height']= 300;
      $config['new_image']= './upload_file/pembayaran/'.$data['file_name'];
      $this->load->library('image_lib', $config);
      $this->image_lib->resize();

      $data1 = array(
         'status_bidding_take' => 'menunggu_verifikasi_pembayaran'
      );
      $this->db->where('id_bidding_take' , $id_bidding_take);
      $this->db->update('bidding_take' , $data1);

      redirect(base_url().'user/pembayaran_proyek');
   }

   function pembayaran_proyek()
   {
      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();

      $data['bidding'] = $this->M_user->daftar_pembayaran_lelang();
      $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
      $this->load->view('frontend/user/bidding_pembayaran');
      $this->load->view('frontend/user/footer');
   }

   function invoice_lelang($id_bidding=null)
   {
      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();

      $data['lelang'] = $this->M_user->lelang_invoice($id_bidding);
      $data['pembayaran'] = $this->M_user->lelang_pembayaran($id_bidding);

      $data['id']=$id_bidding;
      $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
      $this->load->view('frontend/user/bidding_invoice');
      $this->load->view('frontend/user/footer');
   }

   function invoice_lelang_lunas($id_bidding=null)
   {
      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();

      $data['lelang'] = $this->M_user->lelang_invoice_lunas($id_bidding);
      $data['pembayaran'] = $this->M_user->lelang_pembayaran($id_bidding);

      $data['id']=$id_bidding;
      $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
      $this->load->view('frontend/user/bidding_invoice_lunas');
      $this->load->view('frontend/user/footer');
   }
   function simpan_perpanjang()
   {
      $id_bidding = $this->input->post('id');
      $batas_penawaran = $this->input->post('batas_penawaran');

      $data = array(
         'batas_penawaran' => $batas_penawaran
      );
      $this->db->where('id_bidding' , $id_bidding);
      $this->db->update('bidding' , $data);

      redirect(base_url().'user/proyek','refresh');
   }
//LELANG END===============================================================
//ULASAN START=============================================================   
   function ulasan($id_order = null, $id_perusahaan = null, $id_produk = null, $etalase = null)
   {
      if (!empty($id_order) && !empty($id_produk)) {
         $cek_order = $this->db->get_where('order', array('id_order'=> $id_order))->result();
         $cek_produk = $this->db->get_where('produk_view', array('id_produk'=> $id_produk))->result();
         if(count($cek_order) < 1 || count($cek_produk) < 1){redirect(base_url().'user/pembelian','refresh');}
      }else{redirect(base_url().'user/pembelian','refresh');}

      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();
      $data['order'] = $this->db->get_where('order', array('id_order'=> $id_order))->row();
      $data['produk'] = $this->db->get_where('produk_view', array('id_produk'=> $id_produk))->row();

      $data['id_order']=$id_order;
      $data['id_perusahaan']=$id_perusahaan;
      $data['id_produk']=$id_produk;
      $data['etalase']=$etalase;

      $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
      $this->load->view('frontend/user/ulasan_form');
      $this->load->view('frontend/user/footer');
   }

   function simpan_ulasan()
   {

      $rating=$this->input->post('rating');  
      $ulasan=$this->input->post('ulasan');  
      $id_user=$this->input->post('id_user');  
      $id_order=$this->input->post('id_order');  
      $id_perusahaan=$this->input->post('id_perusahaan');  
      $id_produk=$this->input->post('id_produk');
      $etalase=$this->input->post('etalase');    

      if ($this->M_user->simpan_ulasan($rating, $ulasan, $id_user, $id_order, $id_perusahaan, $id_produk, $etalase) == TRUE) {
          $this->M_user->simpan_rating_produk($id_produk, $etalase);
          $this->M_user->simpan_rating_perusahaan($id_perusahaan);

          $this->session->set_flashdata('notif' , true);
          $this->session->set_flashdata('teks_notif' , "Ulasan disimpan");
          redirect(base_url() . "user/pembelian");
      }else{
          $this->session->set_flashdata('notif' , false);
          $this->session->set_flashdata('teks_notif' , "Ulasan gagal disimpan");
          redirect(base_url() . "user/pembelian");
      }
   }
//ULASAN END=============================================================== 
//ITEM TIDAK TERSEDIA START================================================ 
   function load()
   {
      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();

      $data['plugin_v']='2';$this->load->view('frontend/user/header_user',$data);
      $this->load->view('frontend/user/item_notif');
      $this->load->view('frontend/user/footer');
   }
//ITEM TIDAK TERSEDIA END================================================== 


//TIDAK DIPAKAI START====================================================== 
   function u(){
      $this->db->select_avg('angka');
      $rating = $this->db->get('rating')->row();
      echo $rating->angka;
   }

   function tem_email()
   {
      $data['id_bidding']='1';
      $data['nama_bidding']= 'nama proyek';
      $data['kategori']= 'kategori proyek';
      $data['keterangan']= 'keterangan';
      $data['budget']= '100000000000';
      $data['dokumen']= 'ada dokumen';
      $data['ukuran_sistem']= '12';
      $data['batas_penawaran']= '2021-12-05';
      $data['area']= 'bandung, surabaya';
      $data['dibuat']= '2021-11-27';
      $data['id_perusahaan']='2';

      $this->load->view('frontend/template_email/bidding_email', $data);

      /* $content =  $this->load->view('frontend/template_email/bidding_email',array('ok'=>'ok'), true);

         $this->load->library('mailer');
            $recipient_email ="brajamusti570@gmail.com";
            $subject = 'Proyek Baru';
           // Ambil isi file content.php dan masukan ke variabel $content
            $sendmail = array(
                'email_penerima'=>$recipient_email,
                'subject'=>$subject,
                'content'=>$content
                  //'attachment'=>$attachment
            );
            $send = $this->mailer->send($sendmail);*/
   }

   function kirim_bidding()
   {
      $get_perusahaan = $this->M_user->tampil_perusahaan_send_bidding();
      // $areaBidding=implode(",", $area);
      $this->load->library('mailer');
      // foreach ($get_perusahaan as $key => $value) {
      $get_lelang=$this->db->get_where('bidding', array('id_bidding'=>'42'))->row();
      $get_area=$this->db->get_where('bidding_area', array('id_bidding'=>'42'))->result_array();
      foreach ($get_area as $key => $valueA) {
         $arr[]=$valueA['lokasi'];
      }

      $content =  $this->load->view('frontend/template_email/bidding_email',array('id_bidding'=>$get_lelang->id_bidding,'id_perusahaan'=>'tak ada','dibuat'=>$get_lelang->input_bidding,'nama_bidding'=>$get_lelang->nama_bidding,'kategori'=>$get_lelang->kategori,'keterangan'=>$get_lelang->keterangan,'budget'=>$get_lelang->budget,'ukuran_sistem'=>$get_lelang->ukuran_sistem, 'batas_penawaran'=>$get_lelang->batas_penawaran,'area'=> implode(",",$arr)), true);

         // foreach ($get_perusahaan as $key => $value) {
         //  $recipient_email = $value['link'];
      $subject = 'Lelang';
                       // Ambil isi file content.php dan masukan ke variabel $content
      $sendmail = array(
         'email_penerima'=>'jul_syaf@outlook.com',
         'subject'=>$subject,//$subject,
         'content'=>$content
         //'attachment'=>$attachment
      );
      $send = $this->mailer->send($sendmail);
      //}
   }
     
   function go()
   {
      $this->db->select('*');
      $this->db->from('perusahaan_pemasang'); 
      $this->db->join('perusahaan','perusahaan_pemasang.id_perusahaan = perusahaan.id_perusahaan'); 
      $this->db->join('perusahaan_area_operasi','perusahaan.id_perusahaan = perusahaan_area_operasi.id_perusahaan');   
      $this->db->order_by('id_pemasang', 'ASC');
      $query = $this->db->get()->result_array();

      foreach ($query as $key => $value) {
         echo $value['id_pemasang'].'-'.$value['nama_perusahaan'].'-'.$value['kabupaten'].'<br>';
         $this->db->insert('pemasang_area_kerja', array('id_pemasang'=>$value['id_pemasang'],'area_pemasang'=>$value['kabupaten'],'input_area_kerja'=>date('Y-m-d')));
      }
   }

   function notif_mail()
   {
      $this->load->library('mailer');

      $content =  $this->load->view('frontend/template_email/notif_email', array(), true);
      $recipient_email = 'brajamusti570@gmail.com';
      $subject = 'Lengkapi Perusahaan Anda';
      // Ambil isi file content.php dan masukan ke variabel $content
      $sendmail = array(
         'email_penerima'=>$recipient_email,
         'subject'=>$subject,
         'content'=>$content
        //'attachment'=>$attachment
      );
      $send = $this->mailer->send($sendmail);
   }
//TIDAK DIPAKAI END--====================================================== 
 }


?>