<?php 
if (!defined('BASEPATH'))exit('No direct script access allowed');

class Home extends CI_Controller
{
  function __construct()
  {
    parent::__construct();
    $this->load->database();
    $this->load->library('upload');
    $this->load->library('encryption');
    $this->load->helper('security');
    $this->load->helper('url');
    $this->load->library('session');
    $this->load->model('M_home');
    $this->load->model('M_user');
    $this->load->model('Website');

        //pengaturan bahasa
    $cek_lang = $this->session->userdata('lang');
    if (empty($cek_lang)) { $this->session->set_userdata('lang', 'indonesia');}
    else{ $this->session->set_userdata('lang', $cek_lang); }
        //_________________
    if ($this->session->userdata('dev')!='success') {
           // redirect(base_url().'maintenance');
    }

    /*cache control*/
    $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
    $this->output->set_header('Pragma: no-cache');

      //  $this->session->sess_destroy();
 }
 function coba(){
    $this->db->select("*");
    $kotaArray =  array('sabang','medan','padang','siak','jambi','lahat', 'bekasi','sambas','buol','palu','sigi');
    $this->db->where_in('kota', $kotaArray);
    $this->db->group_by('id_provinsi');
    $data= $this->db->get('wilayah_kota')->result_array();

    foreach ($data as $key => $value) {
     $ok[] = $value['id_provinsi'];
  }
        // echo implode(", ",$ok);

  $this->db->select("*");
       // $this->db->like('nama_provinsi', 'barat');
  $this->db->where_in('id_provinsi', $ok);
  $data_prov= $this->db->get('wilayah_provinsi')->result_array();

  foreach ($data_prov as $key1 => $valueProv) {
     echo $valueProv['nama_provinsi']."<br>";
  }
  rand(1000, 9999);
  date_default_timezone_set('Asia/Jakarta');
  mkdir('coba'.date("is"), 0777, true);
}
     //======================================HALAMAN AWAL=================================================
    function index()// halaman awal front end
    {

       $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
       $data['medsos'] = $this->Website->medsosweb();
       $data['artikel'] = $this->M_user->artikel_index();
       $data['iklan1'] = $this->M_user->tampil_iklan_banner('1');
            //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
       $data['plugin_v']='2';$this->load->view('frontend/header',$data);
       $this->load->view('frontend/index');
       $this->load->view('frontend/footer');
    }
    function cari_homepage()
    {
       $kategori = $this->input->post('cari_kategori');
       $lokasi = $this->input->post('lokasi');

       redirect(base_url().'home/'.$kategori.'/cari/'.$lokasi);
    }
    //=====================================================================================================
    //============================================GANTI BAHASA=============================================
    function ok(){
       $this->load->view('frontend/ok');
    }
    function lang($get_lang)//mengganti bahasa
    {
       $this->session->set_userdata('lang', $get_lang);
       redirect(base_url());
    }
    //=======================================================================================================
    //============================================Menu=======================================================
     function tentang()// halaman awal front end
     {
        //  $data['seo'] = $this->home->seo(); //menampilkan meta title, keyword, deskripsi
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();
        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
       // $this->load->view('frontend/top');
        $data['plugin_v']='2';$this->load->view('frontend/header',$data);
        $this->load->view('frontend/user/tentang');
        $this->load->view('frontend/footer');
     }

     function syarat_dan_ketentuan()
     {
       $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
       $data['medsos'] = $this->Website->medsosweb();
            //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
           // $this->load->view('frontend/top');
       $data['plugin_v']='2';$this->load->view('frontend/header',$data);
       $this->load->view('frontend/user/syaratKetentuan');
       $this->load->view('frontend/footer');
    }
    //=====================================================================================================

    function tentang_plts_atap()// halaman awal front end
    {
        //  $data['seo'] = $this->home->seo(); //menampilkan meta title, keyword, deskripsi
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();
        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
       // $this->load->view('frontend/top');
        $data['plugin_v']='2';$this->load->view('frontend/header',$data);
        $this->load->view('frontend/user/faq_plts_atap');
        $this->load->view('frontend/footer');
     }
    //=====================================================================================================
     function tentang_solarhub()// halaman awal front end
     {
        //  $data['seo'] = $this->home->seo(); //menampilkan meta title, keyword, deskripsi
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();
        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
       // $this->load->view('frontend/top');
        $data['plugin_v']='2';$this->load->view('frontend/header',$data);
        $this->load->view('frontend/user/faq_solarhub');
        $this->load->view('frontend/footer');
     }
    //=====================================================================================================
     function tentang_kalkulator_surya()// halaman awal front end
     {
        //  $data['seo'] = $this->home->seo(); //menampilkan meta title, keyword, deskripsi
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();
        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
       // $this->load->view('frontend/top');
        $data['plugin_v']='2';$this->load->view('frontend/header',$data);
        $this->load->view('frontend/user/faq_kalkulator_surya');
        $this->load->view('frontend/footer');
     }
    //=====================================================================================================
    //==========================================REGISTRASI++++++++=========================================
    function registrasi()// halaman register akun
    {
        //  $data['seo'] = $this->home->seo(); //menampilkan meta title, keyword, deskripsi
       $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
       $data['medsos'] = $this->Website->medsosweb();
        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
       $data['provinsi'] = $this->M_user->tampil_provinsi();
       $data['plugin_v']='2';$this->load->view('frontend/header',$data);
       $this->load->view('frontend/registrasi');
       $this->load->view('frontend/footer');
    }
    function ambil_data_kota()
    {
       $provinsi=$this->input->post('provinsi');
       $data=$this->M_user->tampil_cari_kota($provinsi)->result();
       echo json_encode($data);
    }
    function ambil_data_kecamatan()
    {
       $kabupaten=str_replace("_", " ", $this->input->post('kabupaten'));
       $data=$this->M_user->tampil_cari_kecamatan($kabupaten)->result();
       echo json_encode($data);
    }
    function ambil_data_kelurahan()
    {
       $kecamatan=str_replace("_", " ", $this->input->post('kecamatan'));
       $data=$this->M_user->tampil_cari_kelurahan($kecamatan)->result();
       echo json_encode($data);
    }
    function ambil_data_pos()
    {
       $kelurahan=str_replace("_", " ", $this->input->post('kelurahan'));
       $kecamatan=str_replace("_", " ", $this->input->post('kecamatan'));
       $kabupaten=str_replace("_", " ", $this->input->post('kabupaten'));
       $provinsi=str_replace("_", " ",$this->input->post('provinsi'));
       $data=$this->M_user->tampil_cari_kodepos($kelurahan, $kecamatan, $kabupaten, $provinsi)->row();
       echo json_encode($data);
    }
    function ajax_validate_email()//cek email saat register akun
    {
       $data = array(
         'email'=>$this->input->post('emailRegister'));
       $query = $this->db->get_where('user', $data);
       if ($query->num_rows() > 0) {
             //$row = $query->row();
          echo 1;
       }else{
        echo 0;
     }
  }

    function simpan_register()//penyimpan register akun
    {
      date_default_timezone_set('Asia/Jakarta');
      $this->load->library('mailer');
      $kode_verifikasi = rand(1000, 9999);
      $email_penerima = $this->input->post('emailRegister',TRUE);
      $subjek = 'kode_verifikasi';
      $pesan = $kode_verifikasi;
            //$attachment = $_FILES['attachment'];
         $content = $this->load->view('frontend/template_email/verifikasi_email', array('pesan'=>$pesan), true); // Ambil isi file content.php dan masukan ke variabel $content
         $sendmail = array(
            'email_penerima'=>$email_penerima,
            'subjek'=>$subjek,
            'content'=>$content
              //'attachment'=>$attachment
         );
        $send = $this->mailer->send($sendmail); // Panggil fungsi send yang ada di librari Mailer
        
        $this->session->set_userdata('simpan_kode_verifikasi' , $kode_verifikasi);
        $this->session->set_userdata('simpan_email' , $this->input->post('emailRegister',TRUE));

        $nama_depan = $this->input->post('nama_depan',TRUE);
        $nama_belakang = $this->input->post('nama_belakang',TRUE);
        $emailRegister = $this->input->post('emailRegister',TRUE);
        $telepon = $this->input->post('telepon',TRUE);
        $alamat = $this->input->post('alamat',TRUE);
        $kelurahan = str_replace("_", " ", $this->input->post('kelurahan',TRUE));
        $kecamatan = str_replace("_", " ", $this->input->post('kecamatan',TRUE));
        $kota = str_replace("_", " ", $this->input->post('kabupaten',TRUE));
        $provinsi = str_replace("_", " ", $this->input->post('provinsi',TRUE));
        $pos = $this->input->post('pos',TRUE);
        $password = sha1($this->input->post('password',TRUE));

        $folder = substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz123456789'), 0, 7);

        $new_folder = 'user_'.$folder.'_'.date("d").''.date("m").''.date("y").''.date("H").''.date("i").''.date("s");
        mkdir("upload_file/".$new_folder);
       //chmod("upload_file/".$new_folder, 0777,true);
        mkdir("upload_file/".$new_folder."/bidding");
       //chmod("upload_file/".$new_folder."/img",  0777,true);
        
        mkdir("upload_file/".$new_folder."/img");
       //chmod("upload_file/".$new_folder."/img",  0777,true);

        mkdir("upload_file/".$new_folder."/penawaran");
       //chmod("upload_file/".$new_folder."/img",  0777,true);
        
        mkdir("upload_file/".$new_folder."/img/foto_profil");
       //chmod("upload_file/".$new_folder."/img/foto_profil", 0777,true);
        
        mkdir("upload_file/".$new_folder."/img/perusahaan");
       //chmod("upload_file/".$new_folder."/img/perusahaan", 0777,true);

        mkdir("upload_file/".$new_folder."/img/perusahaan/produk");
       //chmod("upload_file/".$new_folder."/img/perusahaan/produk", 0777,true);
        
        mkdir("upload_file/".$new_folder."/img/perusahaan/pemasang");
        //chmod("upload_file/".$new_folder."/img/perusahaan/pemasang", 0777,true);

        mkdir("upload_file/".$new_folder."/img/perusahaan/portofolio");
       //chmod("upload_file/".$new_folder."/img/perusahaan/portofolio", 0777,true);
        
        mkdir("upload_file/".$new_folder."/img/perusahaan/banner");
       //chmod("upload_file/".$new_folder."/img/perusahaan/banner", 0777,true);

        if(isset($_FILES["gambarProfil"]["name"])){
           $config['upload_path'] = './upload_file/'.$new_folder.'/img/foto_profil/';
           $config['allowed_types'] = 'jpg|jpeg|png|gif';
           $config['file_name'] = 'profil_'.time().'.png';
           $this->upload->initialize($config);
           if(!$this->upload->do_upload('gambarProfil')){
             $this->upload->display_errors();
             return FALSE;
          }else{
             $data = $this->upload->data();
                //Compress Image
             $config['image_library']='gd2';
             $config['source_image']='./upload_file/'.$new_folder.'/img/foto_profil/'.$data['file_name'];
             $config['create_thumb']= FALSE;
             $config['maintain_ratio']= TRUE;
             $config['quality']= '100%';
             $config['width']= 720;
             $config['height']= 300;
             $config['new_image']= './upload_file/'.$new_folder.'/img/foto_profil/'.$data['file_name'];
             $this->load->library('image_lib', $config);
             $this->image_lib->resize();
             echo base_url().'./upload_file/'.$new_folder.'/img/foto_profil/'.$data['file_name'];
          }
       }

       $gambar = $data['file_name'];

       if ($this->M_home->simpan_register($nama_depan, $nama_belakang, $emailRegister, $telepon, $alamat, $kelurahan, $kecamatan, $kota, $provinsi, $pos, $password, $new_folder, $gambar) == TRUE) {


         redirect(base_url() . "home/simpan_kode_verifikasi");
      }else{
         $this->session->set_flashdata('notif' , false);
         $this->session->set_flashdata('teks_notif' , "Registrasi Gagal");
         redirect(base_url() . "home/registrasi");
      }
   }

    function simpan_kode_verifikasi()//menyimpan kode verifikasi ke databse setelah selesai register
    {
       $simpan_kode_verifikasi = $this->session->userdata('simpan_kode_verifikasi');
       $simpan_email = $this->session->userdata('simpan_email');

       $query = $this->db->get_where('user', array('email'=>$simpan_email));
       $id_userReg = $query->row();

        //$this->db->delete('user_verifikasi', array('id_user'=> $id_userReg->id_user,'status_verifikasi'=> 'true'));
       $this->session->set_userdata('id_userReg' , $id_userReg->id_user);

       date_default_timezone_set('Asia/Jakarta');

       $this->db->insert('user_verifikasi', array('id_user'=>$id_userReg->id_user, 'kode_verifikasi'=>$simpan_kode_verifikasi, 'tanggal'=> date('d/m/Y'), 'jam'=> date('H:i'), 'status_verifikasi'=>'false'));

       redirect(base_url() . "home/verifikasi");

    }
    function verifikasi()//halaman verifikasi OTP
    {
       $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
       $data['medsos'] = $this->Website->medsosweb();
        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

       $query = $this->db->get_where('user_verifikasi', array('id_user'=> $this->session->userdata('id_userReg'),'status_verifikasi'=> 'true'));
       if ($query->num_rows() > 0) {
         redirect(base_url() . "home/registrasi/");
      }else{
       $data['plugin_v']='2';$this->load->view('frontend/header',$data);
       $this->load->view('frontend/verifikasi');
       $this->load->view('frontend/footer');
    }
 }
    function input_verifikasi()// form verifikaksi kode dari email
    {
       date_default_timezone_set('Asia/Jakarta');
       $tgl_sekarang = date("d/m/Y");
       $jam_sekarang = date("H:i");
       $id_userReg = $this->session->userdata('id_userReg');

       $this->db->delete('user_verifikasi', array('id_user'=> $id_userReg,'status_verifikasi'=> 'true'));

       $kode_verifikasi = $this->input->post('kode_verifikasi',TRUE);

       $query = $this->db->get_where('user_verifikasi', array('id_user'=> $id_userReg,'kode_verifikasi'=> $kode_verifikasi));

        if ($query->num_rows() > 0) {//1. validasi kode verifikasi
            //[start=============================cek=============================================
         $waktu = $query->row();

         $date = new DateTime($waktu->jam);
         $date_plus = $date->modify("+30 minutes");
         $expired = $date_plus->format("H:i");

            // $this->session->set_flashdata('notif' , "TRUE");
            //$this->session->set_flashdata('teks_notif' , "Kode verifikasi BENAR");
            //redirect(base_url() . "home/verifikasi/");
            //$split_waktu = explode(':', $waktu->jam);// waktu kode verifikasi dari database
            //$split_waktu[1];
            //===============================================================================end]

            if ($waktu->tanggal == $tgl_sekarang && $jam_sekarang <= $expired) {// 2. cek tgl kode verifikasi
                if ($this->M_home->update_verifikasi($id_userReg, $kode_verifikasi) == TRUE) { // 3. update status kode verifikasi
                   $this->session->set_flashdata('notif' , "TRUE");
                   $this->session->set_flashdata('teks_notif' , "Registrasi berhasil, silahkan Log In");
                   redirect(base_url() . "home/registrasi/");
                }else{
                   $this->session->set_flashdata('notif' , "FALSE");
                   $this->session->set_flashdata('teks_notif' , "Registrasi Gagal");
                   redirect(base_url() . "home/verifikasi/");
                }
             }else{
              $this->session->set_flashdata('notif' , "REKODE");
              $this->session->set_flashdata('teks_notif' , "Kode verifikasi tidak berlaku");
              redirect(base_url() . "home/verifikasi/");
           }
        }else{
          $this->session->set_flashdata('notif' , "FALSE");
          $this->session->set_flashdata('teks_notif' , "Kode verifikasi salah");
          redirect(base_url() . "home/verifikasi/");
       }
    }
    function resimpan_kode_verifikasi()//menyimpan kode verifikasi ke databse setelah selesai register
    {
       $this->load->library('mailer');
       $kode_verifikasi = rand(1000, 9999);
       $email_penerima = $this->input->post('emailRegister',TRUE);
       $subjek = 'kode_verifikasi';
       $pesan = $kode_verifikasi;
            //$attachment = $_FILES['attachment'];
         $content = $this->load->view('frontend/template_email/verifikasi_email', array('pesan'=>$pesan), true); // Ambil isi file content.php dan masukan ke variabel $content
         $sendmail = array(
            'email_penerima'=>$email_penerima,
            'subjek'=>$subjek,
            'content'=>$content
              //'attachment'=>$attachment
         );
         $send = $this->mailer->send($sendmail); 

         $id_userReg = $this->session->userdata('id_userReg');

         date_default_timezone_set('Asia/Jakarta');

         $this->db->insert('user_verifikasi', array('id_user'=>$id_userReg, 'kode_verifikasi'=>$simpan_kode_verifikasi, 'tanggal'=> date('d/m/Y'), 'jam'=> date('H:i'), 'status_verifikasi'=>'false'));

         redirect(base_url() . "home/verifikasi");

      }
    //=======================================================================================================
    //==========================================LOGIN========================================================
    function validate_akun()//cek email dan password ketika login
    {
       $email = $this->input->post('email');
       $password = $this->input->post('password');

       $data = array('email' => $email, 'password' => sha1($password));
       $query = $this->db->get_where('user', $data);
       if ($query->num_rows() > 0) {
             //$row = $query->row();
          echo 1;
       }else{
        echo 0;
     }
  }
    function validate_login()//proses login dan mengecek apakah akun sudah terverifikasi 
    {
       $email = $this->input->post('email');
       $password = sha1($this->input->post('password'));
       $this->session->set_userdata('emailReg' , $email);

       $query = $this->db->get_where('user', array('email' => $email, 'password' => $password));
       $row = $query->row();
       if ($query->num_rows() < 1) {
         $this->session->set_flashdata('notif' , "FALSE");
         $this->session->set_flashdata('teks_notif' , "username atau password salah ");
         redirect(base_url() . "home/registrasi");
      }

      $this->session->set_userdata('id_userReg', $row->id_user);
      $query2 = $this->db->get_where('user_verifikasi', array('id_user'=> $row->id_user, 'status_verifikasi'=> 'true'));
      $query_id = $query2->row();

      if ($query2->num_rows() > 0) {
         $this->session->set_userdata('user_login', 'TRUE');
         $this->session->set_userdata('id_user', $row->id_user);
         $this->session->set_userdata('nama_depan', $row->nama_depan);
         $this->session->set_userdata('nama_belakang', $row->nama_belakang);
         $this->session->set_userdata('pass', $row->password);
         $this->session->set_userdata('email', $row->email);
         $this->session->set_userdata('telepon', $row->telepon);
         $this->session->set_userdata('alamat', $row->alamat);
         $this->session->set_userdata('kecamatan', $row->kecamatan);
         $this->session->set_userdata('kota', $row->kota);
         $this->session->set_userdata('provinsi', $row->provinsi);
         $this->session->set_userdata('pos', $row->pos);
         $this->session->set_userdata('biografi', $row->biografi);
         $this->session->set_userdata('status', $row->status);
         $this->session->set_userdata('tgl_registrasi', $row->tgl_registrasi);
         $this->session->set_userdata('folder', $row->folder);
         $this->session->set_userdata('foto_profil', $row->foto_profil);

         $get_id_perusahaan = $this->db->get_where('perusahaan', array('id_user'=>$row->id_user));
         $value_get_id = $get_id_perusahaan->row();
         if ($get_id_perusahaan->num_rows() > 0) {
           $this->session->set_userdata('id_perusahaan', $value_get_id->id_perusahaan);
           $this->session->set_userdata('nama_perusahaan', $value_get_id->nama_perusahaan);
           $this->session->set_userdata('tagline', $value_get_id->tagline);
           $this->session->set_userdata('alamat_perusahaan', $value_get_id->alamat_perusahaan);
           $this->session->set_userdata('kelurahan_perusahaan', $value_get_id->kelurahan_perusahaan);
           $this->session->set_userdata('kecamatan_perusahaan', $value_get_id->kecamatan_perusahaan);
           $this->session->set_userdata('kabupaten_perusahaan', $value_get_id->kabupaten_perusahaan);
           $this->session->set_userdata('provinsi_perusahaan', $value_get_id->provinsi_perusahaan);
           $this->session->set_userdata('pos_perusahaan', $value_get_id->pos_perusahaan);
           $this->session->set_userdata('latitude', $value_get_id->latitude);
           $this->session->set_userdata('longitude', $value_get_id->longitude);
           $this->session->set_userdata('deskripsi', $value_get_id->deskripsi);
           $this->session->set_userdata('pembayaran_cash', $value_get_id->pembayaran_cash);
           $this->session->set_userdata('pembayaran_kredit', $value_get_id->pembayaran_kredit);
           $this->session->set_userdata('status_perusahaan', $value_get_id->status_perusahaan);
           $this->session->set_userdata('jenis_perusahaan', $value_get_id->jenis_perusahaan);
           $this->session->set_userdata('rating_perusahaan', $value_get_id->rating_perusahaan);
           $this->session->set_userdata('input_perusahaan', $value_get_id->input_perusahaan);
        }
        redirect(base_url().'user'.$this->session->userdata('url_redirect'));

     }else{
      $this->db->delete('user_verifikasi', array('id_user'=> $row->id_user));
      $this->session->set_userdata('id_userReg', $row->id_user);

      $this->load->library('mailer');
      $kode_verifikasi = rand(1000, 9999);
      $email_penerima = $row->email;
      $subjek = 'Kode Verifikasi';
      $pesan = $kode_verifikasi;
                //$attachment = $_FILES['attachment'];
            $content = $this->load->view('frontend/template_email/verifikasi_email', array('pesan'=>$pesan), true); // Ambil isi file content.php dan masukan ke variabel $content
            $sendmail = array(
              'email_penerima'=>$email_penerima,
              'subjek'=>$subjek,
              'content'=>$content
                  //'attachment'=>$attachment
           );
            $send = $this->mailer->send($sendmail);

            date_default_timezone_set('Asia/Jakarta');
            $this->db->insert('user_verifikasi', array('id_user'=> $row->id_user, 'kode_verifikasi'=>$kode_verifikasi, 'tanggal'=> date('d/m/Y'), 'jam'=> date('H:i'), 'status_verifikasi'=>'false'));// input kode verifikasi baru

            redirect(base_url(). 'home/verifikasi');
         }
      }
      function google_login(){
       include_once APPPATH . "libraries/google-api-client/Google_Client.php";
       include_once APPPATH . "libraries/google-api-client/contrib/Google_Oauth2Service.php";
       include_once APPPATH . "config/google.php";

      if(isset($_GET['code'])){
         $gclient->authenticate($_GET['code']);
         $this->session->set_userdata('token', $gclient->getAccessToken());
         header('Location: ' . filter_var($redirect_url, FILTER_SANITIZE_URL));
      }

      if (!empty($this->session->userdata('token'))){
         $gclient->setAccessToken($this->session->userdata('token'));
      }

      if ($gclient->getAccessToken()) {

            // Get user profile data from google
         $gpuserprofile = $google_oauthv2->userinfo->get();

            $nama = $gpuserprofile['given_name']." ".$gpuserprofile['family_name']; // Ambil nama dari Akun Google
            $email = $gpuserprofile['email']; // Ambil email Akun Google nya

            // Buat query untuk mengecek apakah data user dengan email tersebut sudah ada atau belum
            // Jika ada, ambil id, username, dan nama dari user tersebut

            $queryy = $this->db->get_where('user', array('email'=>$email))->row();
            $user = $queryy;
           
           
            $cek_email = $this->db->get_where('user', array('email'=>$email))->result_array();
          
            if(count($cek_email) < 1){ // Jika User dengan email tersebut belum ada
                // Ambil username dari kata sebelum simbol @ pada email
              
               
              $folder = substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz123456789'), 0, 7);
              date_default_timezone_set('Asia/Jakarta');
              $new_folder = 'user_'.$folder.'_'.date("d").''.date("m").''.date("y").''.date("H").''.date("i").''.date("s");
              mkdir("upload_file/".$new_folder);
               //chmod("upload_file/".$new_folder, 0777,true);
              mkdir("upload_file/".$new_folder."/bidding");
               //chmod("upload_file/".$new_folder."/img",  0777,true);

              mkdir("upload_file/".$new_folder."/img");
               //chmod("upload_file/".$new_folder."/img",  0777,true);

              mkdir("upload_file/".$new_folder."/penawaran");
               //chmod("upload_file/".$new_folder."/img",  0777,true);

              mkdir("upload_file/".$new_folder."/img/foto_profil");
               //chmod("upload_file/".$new_folder."/img/foto_profil", 0777,true);

              mkdir("upload_file/".$new_folder."/img/perusahaan");
               //chmod("upload_file/".$new_folder."/img/perusahaan", 0777,true);

              mkdir("upload_file/".$new_folder."/img/perusahaan/produk");
               //chmod("upload_file/".$new_folder."/img/perusahaan/produk", 0777,true);

              mkdir("upload_file/".$new_folder."/img/perusahaan/pemasang");
                //chmod("upload_file/".$new_folder."/img/perusahaan/pemasang", 0777,true);

              mkdir("upload_file/".$new_folder."/img/perusahaan/portofolio");
               //chmod("upload_file/".$new_folder."/img/perusahaan/portofolio", 0777,true);

              mkdir("upload_file/".$new_folder."/img/perusahaan/banner");
               //chmod("upload_file/".$new_folder."/img/perusahaan/banner", 0777,true);


                $ex = explode('@', $email); // Pisahkan berdasarkan "@"
                $username = $ex[0]; // Ambil kata pertama

                $data = array(
                   'nama_depan' => $nama,
                   'nama_belakang' => '',
                   'email' => $email,

                   'status' => 'true',
                   'tgl_registrasi' => date('d/m/Y'),
                   'folder' => $new_folder,
                   'foto_profil' => 'profil_'.time().'.png',
                   'input_user' => date('Y-m-d')
                );
                $this->db->insert('user',$data);


                $query = $this->db->get_where('user', array('email' => $email));
                $user = $query->row();

                $this->db->insert('user_verifikasi', array('id_user'=>$user->id_user, 'kode_verifikasi'=> '0000', 'tanggal'=> date('d/m/Y'), 'jam'=> date('H:i'), 'status_verifikasi'=>'true'));



                $this->load->library('mailer');
                $kode_verifikasi = rand(1000, 9999);
                $email_penerima = $email;
                $subjek = 'Terdaftar Sebagai Akun Solarhub.id';
                $pesan = "Email anda telah terdaftar sebagai akun di solarhub.id";
                    //$attachment = $_FILES['attachment'];
                 $content = $this->load->view('frontend/template_email/verifikasi_email', array('pesan'=>$pesan), true); // Ambil isi file content.php dan masukan ke variabel $content
                 $sendmail = array(
                   'email_penerima'=>$email_penerima,
                   'subjek'=>$subjek,
                   'content'=>$content
                      //'attachment'=>$attachment
                );
                 $send = $this->mailer->send($sendmail); 

                 $query = $this->db->get_where('user', array('email' => $email));
                 $user = $query->row();


                 $this->session->set_userdata('user_login', 'TRUE');
                 $this->session->set_userdata('id_user', $user->id_user);
                 $this->session->set_userdata('nama_depan', $user->nama_depan);
                 $this->session->set_userdata('nama_belakang', $user->nama_belakang);
                 $this->session->set_userdata('pass', $user->password);
                 $this->session->set_userdata('email', $user->email);
                 $this->session->set_userdata('telepon', $user->telepon);
                 $this->session->set_userdata('alamat', $user->alamat);
                 $this->session->set_userdata('kecamatan', $user->kecamatan);
                 $this->session->set_userdata('kota', $user->kota);
                 $this->session->set_userdata('provinsi', $user->provinsi);
                 $this->session->set_userdata('pos', $user->pos);
                 $this->session->set_userdata('biografi', $user->biografi);
                 $this->session->set_userdata('status', $user->status);
                 $this->session->set_userdata('tgl_registrasi', $user->tgl_registrasi);
                 $this->session->set_userdata('folder', $user->folder);
                 $this->session->set_userdata('foto_profil', $user->foto_profil);
                 $this->session->set_userdata('foto_profil_gmail', $gpuserprofile['picture']);

                 redirect(base_url().'user'.$this->session->userdata('url_redirect'));
               
              }else{
                //$id = $user['id']; // Ambil id pada tabel user
                //$username = $user['username']; // Ambil username pada tabel user
                //$nama = $user['nama']; // Ambil username pada tabel user
                /*
           $_SESSION['user_first_name'] = $data['given_name'];$_SESSION['user_last_name'] = $data['family_name'];        $_SESSION['user_email_address'] = $data['email'];$_SESSION['user_gender'] = $data['gender'];$_SESSION['user_image'] = $data['picture'];
                */

            
           $this->session->set_userdata('user_login', 'TRUE');
           $this->session->set_userdata('id_user', $user->id_user);
           $this->session->set_userdata('nama_depan', $user->nama_depan);
           $this->session->set_userdata('nama_belakang', $user->nama_belakang);
           $this->session->set_userdata('pass', $user->password);
           $this->session->set_userdata('email', $user->email);
           $this->session->set_userdata('telepon', $user->telepon);
           $this->session->set_userdata('alamat', $user->alamat);
           $this->session->set_userdata('kecamatan', $user->kecamatan);
           $this->session->set_userdata('kota', $user->kota);
           $this->session->set_userdata('provinsi', $user->provinsi);
           $this->session->set_userdata('pos', $user->pos);
           $this->session->set_userdata('biografi', $user->biografi);
           $this->session->set_userdata('status', $user->status);
           $this->session->set_userdata('tgl_registrasi', $user->tgl_registrasi);
           $this->session->set_userdata('folder', $user->folder);
           $this->session->set_userdata('foto_profil', $user->foto_profil);
           $this->session->set_userdata('foto_profil_gmail', $gpuserprofile['picture']);

           $get_id_perusahaan = $this->db->get_where('perusahaan', array('id_user'=>$user->id_user));
           $value_get_id = $get_id_perusahaan->row();
           if ($get_id_perusahaan->num_rows() > 0) {
             $this->session->set_userdata('id_perusahaan', $value_get_id->id_perusahaan);
             $this->session->set_userdata('nama_perusahaan', $value_get_id->nama_perusahaan);
             $this->session->set_userdata('tagline', $value_get_id->tagline);
             $this->session->set_userdata('alamat_perusahaan', $value_get_id->alamat_perusahaan);
             $this->session->set_userdata('kelurahan_perusahaan', $value_get_id->kelurahan_perusahaan);
             $this->session->set_userdata('kecamatan_perusahaan', $value_get_id->kecamatan_perusahaan);
             $this->session->set_userdata('kabupaten_perusahaan', $value_get_id->kabupaten_perusahaan);
             $this->session->set_userdata('provinsi_perusahaan', $value_get_id->provinsi_perusahaan);
             $this->session->set_userdata('pos_perusahaan', $value_get_id->pos_perusahaan);
             $this->session->set_userdata('latitude', $value_get_id->latitude);
             $this->session->set_userdata('longitude', $value_get_id->longitude);
             $this->session->set_userdata('deskripsi', $value_get_id->deskripsi);
             $this->session->set_userdata('pembayaran_cash', $value_get_id->pembayaran_cash);
             $this->session->set_userdata('pembayaran_kredit', $value_get_id->pembayaran_kredit);
             $this->session->set_userdata('status_perusahaan', $value_get_id->status_perusahaan);
             $this->session->set_userdata('jenis_perusahaan', $value_get_id->jenis_perusahaan);
             $this->session->set_userdata('rating_perusahaan', $value_get_id->rating_perusahaan);
             $this->session->set_userdata('input_perusahaan', $value_get_id->input_perusahaan);
          }

       }

            //header("location: welcome.php");
      redirect(base_url().'user'.$this->session->userdata('url_redirect'));
    } else {
      $authUrl = $gclient->createAuthUrl();
      header("location: ".$authUrl);
   }
}

    //=======================================================================================================
function reset_step1(){
  $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
  $data['medsos'] = $this->Website->medsosweb();
  $this->load->view('frontend/reset_pass_email',$data);
}
    function reset_cek_email()//cek email dan password ketika login
    {
       $email = $this->input->post('email');

       $data = array('email' => $email);
       $query = $this->db->get_where('user', $data);
       if ($query->num_rows() > 0) {
          echo 1;
       }else{
        echo 0;
     }
  }
  function reset_step2()
  {
    if (isset($_POST['email'])) {
       $this->load->library('mailer');
       $kode_verifikasi = rand(1000, 9999);
       $email_penerima = $this->input->post('email',TRUE);
       $subjek = 'Kode Verifikasi Reset Password';
       $pesan = $kode_verifikasi;
                //$attachment = $_FILES['attachment'];
             $content = $this->load->view('frontend/template_email/verifikasi_email', array('pesan'=>$pesan), true); // Ambil isi file content.php dan masukan ke variabel $content
             $sendmail = array(
              'email_penerima'=>$email_penerima,
              'subjek'=>$subjek,
              'content'=>$content
                  //'attachment'=>$attachment
           );
             $send = $this->mailer->send($sendmail); 

             $get_user = $this->db->get_where('user',  array('email' => $email_penerima ));
             $id_user = $get_user->row();
             $data['id_user'] = $get_user->row()->id_user;

             $this->db->where('id_user',$id_user->id_user);
             $this->db->update('user_verifikasi' , array('kode_verifikasi' => $kode_verifikasi ));

             $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
             $data['medsos'] = $this->Website->medsosweb();
             $this->load->view('frontend/reset_pass_verifikasi',$data);
          }else{
            redirect(base_url().'home/reset_step1');
         }
      }
     function reset_cek_kode_verifikasi()//cek email dan password ketika login
     {
       $kode_verifikasi = $this->input->post('kode_verifikasi');
       $id_user = $this->input->post('id_user');

       $data = array('id_user' => $id_user,'kode_verifikasi' => $kode_verifikasi);
       $query = $this->db->get_where('user_verifikasi', $data);
       if ($query->num_rows() > 0) {
          echo 1;
       }else{
        echo 0;
     }
  }
  function reset_step3()
  {
    if (isset($_POST['kode_verifikasi'])) {
      $data['id_user'] = $this->input->post('id_user');
      $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
      $data['medsos'] = $this->Website->medsosweb();
      $this->load->view('frontend/reset_password',$data);
   }else{
      redirect(base_url().'home/reset_step1');
   }
}
function reset_finish()
{
 if (isset($_POST['id_user'])) {
   $id_user = $this->input->post('id_user');
   $password = sha1($this->input->post('password2'));

   $this->db->where('id_user',$id_user);
   $this->db->update('user' , array('password' => $password));
   $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
   $data['medsos'] = $this->Website->medsosweb();
   $this->load->view('frontend/reset_password_finish',$data);
}else{
   $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
   $data['medsos'] = $this->Website->medsosweb();
   $this->load->view('frontend/reset_password_finish',$data);
}



}
    //==========================================REGISTRASI & LOGIN===========================================
    //======================================HALAMAN tentang=================================================
function artikel()
{
  $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
  $data['medsos'] = $this->Website->medsosweb();
        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  if (empty($this->input->post('cari'))) {
    $data['artikel']=$this->M_user->tampil_artikel();
    $data['label_cari']="";
 }else{
    $data['artikel']=$this->M_user->tampil_artikel_cari($this->input->post('cari'));
    $data['label_cari']="Hasil pencarian<br>'".$this->input->post('cari')."'";
 }

 $data['artikel_terbaru']=$this->M_user->tampil_artikel_terbaru();

 $data['plugin_v']='2';$this->load->view('frontend/header',$data);
 $this->load->view('frontend/artikel');
 $this->load->view('frontend/footer');
}

function detail_artikel($id_artikel=null)
{
 if (empty($id_artikel)) {redirect(base_url().'home/artikel');}
   $get_artikel = $this->db->get_where('artikel', array('id_artikel'=>$id_artikel));
   if(count($get_artikel->result_array()) < 1){ redirect(base_url().'home/load');}
  $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
  $data['medsos'] = $this->Website->medsosweb();
        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  $data['artikel']=$this->M_user->tampil_artikel_detail($id_artikel);
  $data['artikel_terbaru']=$this->M_user->tampil_artikel_terbaru();
  $data['iklan2'] = $this->M_user->tampil_iklan_detail_pustaka();
  $data['iklan'] = $this->M_user->tampil_iklan_sidebar_pustaka();
  $data['plugin_v']='2';$this->load->view('frontend/header',$data);
  $this->load->view('frontend/artikel_detail');
  $this->load->view('frontend/footer');
}


function publikasi()
{
  $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
  $data['medsos'] = $this->Website->medsosweb();
  if (empty($this->input->post('cari'))) {
    $data['publikasi']=$this->M_user->tampil_publikasi();
    $data['label_cari']="";
 }else{
    $data['publikasi']=$this->M_user->tampil_publikasi_cari($this->input->post('cari'));
    $data['label_cari']="Hasil pencarian<br>'".$this->input->post('cari')."'";
 }

 $data['publikasi_terbaru']=$this->M_user->tampil_publikasi_terbaru();
        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 $data['plugin_v']='2';$data['plugin_v']='2';$this->load->view('frontend/header',$data);
 $this->load->view('frontend/publikasi');
 $this->load->view('frontend/footer');
}
function detail_publikasi($id_publikasi=null)
{
    if (empty($id_publikasi)) {redirect(base_url().'home/publikasi');}
   $get_publikasi = $this->db->get_where('publikasi', array('id_publikasi'=>$id_publikasi));
   if(count($get_publikasi->result_array()) < 1){ redirect(base_url().'home/load');}
  $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
  $data['medsos'] = $this->Website->medsosweb();

  $data['publikasi']=$this->M_user->tampil_publikasi_detail($id_publikasi);
  $data['publikasi_terbaru']=$this->M_user->tampil_publikasi_terbaru();
  $data['iklan'] = $this->M_user->tampil_iklan_sidebar_pustaka();
  $data['iklan2'] = $this->M_user->tampil_iklan_detail_pustaka();
        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  $data['plugin_v']='2';$data['plugin_v']='2';$this->load->view('frontend/header',$data);
  $this->load->view('frontend/publikasi_detail');
  $this->load->view('frontend/footer');
}
function publikasi_email_kirim()
{
  $id = $this->input->post('id',TRUE);
  $link = $this->input->post('link',TRUE);
  $nama = $this->input->post('nama',TRUE);
  $email = $this->input->post('email',TRUE);
  $institusi = $this->input->post('institusi',TRUE);

  $data = array(
    'id_publikasi' => $id,
        //'id_user'=> $this->session->userdata('id_user'),
    'nama' => $nama,
    'email' => $email,
    'institusi' => $institusi,
    'input_publikasi_download' => date('Y-m-d')
 );
  $this->db->insert('publikasi_download',$data);
    /*
    $content =  $this->load->view('frontend/template_email/publikasi_email', array('link'=> $link ), true);

    $this->load->library('mailer');
    $email_penerima =$email;
    $subjek = 'Publikasi';
     
    $sendmail = array(
        'email_penerima'=>$email_penerima,
        'subjek'=>$subjek,
        'content'=>$content
             
    );
    $send = $this->mailer->send($sendmail);


    $callback = array(
          'hasil' => 'email terkirim, silahkan buka e-mail' // Set array hasil dengan isi dari view.php yang diload tadi
      );
    echo json_encode($callback);
    */
    $callback = array(
          'hasil' => 'Berhasil didownload' // Set array hasil dengan isi dari view.php yang diload tadi
       );
    echo json_encode($callback);

 }

    //=====================================================================================================
 function produk($jenis=null,$lokasi=null,$ukuran=null)
 {
        //===================harus di pakai semua fungction controller======================
        //  $data['seo'] = $this->home->seo(); //menampilkan meta title, keyword, deskripsi
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();
        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        if (empty($jenis) && empty($lokasi)) {
            $loc = json_decode(file_get_contents("https://ipinfo.io/".$_SERVER['REMOTE_ADDR']."/json"));
            $data['jenis'] ='auto';
            $data['lokasi'] = $loc->city;
            //$data['lokasi'] =$this->session->userdata('kota');
        }else{
            $data['jenis'] = $jenis;
            $data['lokasi'] = $lokasi;
        }
        $data['ukuran'] = $ukuran;

        $data['cari'] = $this->input->get('cari');
        $data['kabupaten'] = $this->M_user->tampil_kota();
        $data['provinsi'] = $this->M_user->tampil_provinsi();
        $data['produk'] = $this->M_user->tampil_produk();
        $data['iklan'] = $this->M_user->tampil_iklan_produk();

        $data['plugin_v']='2';$this->load->view('frontend/header_1',$data);
        $this->load->view('frontend/produk');
        $this->load->view('frontend/footer');
        //$this->load->view('frontend/footer');

     }

     function produk_search()
     {
        //============================membuat array id perusahaan dari area operasi===1 
       $areaArray = $this->input->post('lokasi_kota');
       if (!empty($areaArray)) {
         $this->db->select("*");
         $this->db->where_in('kabupaten', $areaArray);
         $this->db->group_by('id_perusahaan');
         $data_area_operasi= $this->db->get('perusahaan_area_operasi')->result_array();

         if (count($data_area_operasi) > 0)
         {
           foreach ($data_area_operasi as $key => $valueAO) {
            $kab[] = $valueAO['id_perusahaan'];
         }
      }else{
         $kab ='x';
      }
   }else{
    $kab ='';
 }


 $nama_produk = $this->input->post('nama_produk');
 $lokasi_kota = $this->input->post('lokasi_kota');
        $lokasi_provinsi = '';//$this->input->post('lokasi_provinsi');
        $kategori = $this->input->post('kategori');    
       /* $sistem_on_grid = $this->input->post('sistem_on_grid');                           
        $sistem_off_grid = $this->input->post('sistem_off_grid');
        $sistem_hybrid = $this->input->post('sistem_hybrid');                             
        $pju = $this->input->post('pju');
        $panel = $this->input->post('panel');
        $inverter = $this->input->post('inverter');
        $kabel = $this->input->post('kabel');*/
        $harga_minimal = str_replace(".", "", $this->input->post('harga_minimal'));
        $harga_maximal = str_replace(".", "", $this->input->post('harga_maximal'));
        $pembayaran_cash = $this->input->post('pembayaran_cash');
        $pembayaran_kredit = $this->input->post('pembayaran_kredit');
        $garansi = $this->input->post('garansi');
        $ukuran_sistem = $this->input->post('ukuran_sistem');
        $rating = $this->input->post('rating');
        $sortir = $this->input->post('sortir');                       

        $produk = $this->M_user->search_produk($nama_produk, $kategori, $kab,/*$lokasi_provinsi,*/$harga_minimal, $harga_maximal, $pembayaran_cash, $pembayaran_kredit, $garansi, $ukuran_sistem, $rating, $sortir);


        $hasil = $this->load->view('frontend/produk_view1', array('produk'=>$produk,'kategori'=>$kategori,'lokasi_kota' => $lokasi_kota,'lokasi_provinsi' => $lokasi_provinsi,'harga_minimal' =>$harga_minimal,'harga_maximal' =>$harga_maximal,'pembayaran_cash' => $pembayaran_cash,'pembayaran_kredit' => $pembayaran_kredit,'garansi' =>$garansi,'ukuran_sistem' => $ukuran_sistem,'rating'=> $rating), true);

        $callback = array(
          'hasil' => $hasil // Set array hasil dengan isi dari view.php yang diload tadi
       );
        echo json_encode($callback); // konversi varibael $callback menjadi JSON

     }
     function produk_reset_search()
     {
       $nama_produk = $this->input->post('nama_produk');
       $sortir = $this->input->post('sortir');

       $produk = $this->M_user->search_reset_produk($nama_produk, $sortir);

       $hasil = $this->load->view('frontend/produk_view1', array('produk'=>$produk), true);
       $page = $this->load->view('frontend/user/produk_paging', array('produk'=>$produk), true);

       $callback = array(
        'hasil' => $hasil,
          'prod' => $page // Set array hasil dengan isi dari view.php yang diload tadi
       );
        echo json_encode($callback); // konversi varibael $callback menjadi JSON

     }

     function produk_detail($id_produk = null)
     {
       if (empty($id_produk)) {redirect(base_url().'home/produk');}

        $get_produk = $this->db->get_where('produk_view', array('id_produk'=>$id_produk, 'status_publis'=>'true', 'status_hapus'=>'false', 'status_perusahaan'=>'aktiv'));
      
        if(count($get_produk->result_array()) < 1){ redirect(base_url().'home/load');}
        //===================harus di pakai semua fungction controller======================
        //  $data['seo'] = $this->home->seo(); //menampilkan meta title, keyword, deskripsi
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();
        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        $data['produk']=  $get_produk->row();
        $data['ulasan']=  $this->M_user->ulasan_produk($id_produk);
        $byRekom1 = $this->M_home->rekomendasi_produk_perusahaan($id_produk, '1','cek_rekom','true');
        $byRekom2 = $this->M_home->rekomendasi_produk_perusahaan($id_produk, '2','cek_rekom','true');
        $byRekom3 = $this->M_home->rekomendasi_produk_perusahaan($id_produk, '3','cek_rekom','true');
        $byRekom4 = $this->M_home->rekomendasi_produk_perusahaan($id_produk, '4','cek_rekom','true');
        $byRekom5 = $this->M_home->rekomendasi_produk_perusahaan($id_produk, '5','cek_rekom','true');
        $byRekom6 = $this->M_home->rekomendasi_produk_perusahaan($id_produk, '6','cek_rekom','true');
        $byRekom7 = $this->M_home->rekomendasi_produk_perusahaan($id_produk, '7','cek_rekom','true');
        $byRekom8 = $this->M_home->rekomendasi_produk_perusahaan($id_produk, '8','cek_rekom','true');
        $byRekom9 = $this->M_home->rekomendasi_produk_perusahaan($id_produk, '9','cek_rekom','true');
        $byRekom10 = $this->M_home->rekomendasi_produk_perusahaan($id_produk, '10','cek_rekom','true');

        $cariRekom = array($byRekom1, $byRekom2, $byRekom3, $byRekom4, $byRekom5, $byRekom6, $byRekom7, $byRekom8, $byRekom9, $byRekom10);

        if (max($cariRekom)==$byRekom1) { $no_rekom ='1';}
        elseif (max($cariRekom)==$byRekom2) {$no_rekom ='2';}
        elseif (max($cariRekom)==$byRekom3) {$no_rekom ='3';}
        elseif (max($cariRekom)==$byRekom4) {$no_rekom ='4';}
        elseif (max($cariRekom)==$byRekom5) {$no_rekom ='5';}
        elseif (max($cariRekom)==$byRekom6) {$no_rekom ='6';}
        elseif (max($cariRekom)==$byRekom7) {$no_rekom ='7';}
        elseif (max($cariRekom)==$byRekom8) {$no_rekom ='8';}
        elseif (max($cariRekom)==$byRekom9) {$no_rekom ='9';}
        elseif (max($cariRekom)==$byRekom10) {$no_rekom ='10';}

        $data['rekomedasi_perusahaan']=  $this->M_home->rekomendasi_produk_perusahaan($id_produk, $no_rekom,'get_rekom', 'true');
   
          $byRekomAll1 = $this->M_home->rekomendasi_produk_perusahaan($id_produk, '1','cek_rekom','false');
         $byRekomAll2 = $this->M_home->rekomendasi_produk_perusahaan($id_produk, '2','cek_rekom','false');
         $byRekomAll3 = $this->M_home->rekomendasi_produk_perusahaan($id_produk, '3','cek_rekom','false');
         $byRekomAll4 = $this->M_home->rekomendasi_produk_perusahaan($id_produk, '4','cek_rekom','false');
         $byRekomAll5 = $this->M_home->rekomendasi_produk_perusahaan($id_produk, '5','cek_rekom','false');
         $byRekomAll6 = $this->M_home->rekomendasi_produk_perusahaan($id_produk, '6','cek_rekom','false');
         $byRekomAll7 = $this->M_home->rekomendasi_produk_perusahaan($id_produk, '7','cek_rekom','false');
         $byRekomAll8 = $this->M_home->rekomendasi_produk_perusahaan($id_produk, '8','cek_rekom','false');
         $byRekomAll9 = $this->M_home->rekomendasi_produk_perusahaan($id_produk, '9','cek_rekom','false');
         $byRekomAll10 = $this->M_home->rekomendasi_produk_perusahaan($id_produk, '10','cek_rekom','false');

         $cariRekomAll = array($byRekomAll1, $byRekomAll2, $byRekomAll3, $byRekomAll4, $byRekomAll5, $byRekomAll6, $byRekomAll7, $byRekomAll8, $byRekomAll9, $byRekomAll10);

         if(max($cariRekomAll)==$byRekomAll1) { $no_rekomAll ='1';}
         elseif (max($cariRekomAll)==$byRekomAll2) {$no_rekomAll ='2';}
         elseif (max($cariRekomAll)==$byRekomAll3) {$no_rekomAll ='3';}
         elseif (max($cariRekomAll)==$byRekomAll4) {$no_rekomAll ='4';}
         elseif (max($cariRekomAll)==$byRekomAll5) {$no_rekomAll ='5';}
         elseif (max($cariRekomAll)==$byRekomAll6) {$no_rekomAll ='6';}
         elseif (max($cariRekomAll)==$byRekomAll7) {$no_rekomAll ='7';}
         elseif (max($cariRekomAll)==$byRekomAll8) {$no_rekomAll ='8';}
         elseif (max($cariRekomAll)==$byRekomAll9) {$no_rekomAll ='9';}
         elseif (max($cariRekomAll)==$byRekomAll10) {$no_rekomAll ='10';}

         $data['rekomedasi']=  $this->M_home->rekomendasi_produk_perusahaan($id_produk, $no_rekomAll,'get_rekom', 'false');
        //$data['rekomedasi']=  $this->M_user->rekomendasi_produk($id_produk);

        $data['plugin_v']='2';$this->load->view('frontend/header_1',$data);
        $this->load->view('frontend/produk_detail');
        $this->load->view('frontend/footer');
     }


    //===================================================FITUR PERUSAAHAAN
//===================================================FITUR PERUSAAHAAN
     function perusahaan($jenis=null,$lokasi=null)
     {
       $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
       $data['medsos'] = $this->Website->medsosweb();
        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
       if (empty($jenis) && empty($lokasi)) {
            $loc = json_decode(file_get_contents("https://ipinfo.io/".$_SERVER['REMOTE_ADDR']."/json"));
            $data['jenis'] ='auto';
            $data['lokasi'] = $loc->city;
            //$data['lokasi'] =$this->session->userdata('kota');
        }else{
            $data['jenis'] = $jenis;
            $data['lokasi'] = $lokasi;
        }

       $data['cari'] = $this->input->get('cari');
       $data['kabupaten'] = $this->M_user->tampil_kota();
       $data['provinsi'] = $this->M_user->tampil_provinsi();
       $data['perusahaan'] = $this->M_user->tampil_perusahaan();
       $data['plugin_v']='2';$this->load->view('frontend/header_1',$data);
       $this->load->view('frontend/perusahaan');
       $this->load->view('frontend/footer');
    }

    function perusahaan_search()
    {
       $areaArray = $this->input->post('lokasi_kota');
       if (!empty($areaArray)) {
         $this->db->select("*");
         $this->db->where_in('kabupaten', $areaArray);
         $this->db->group_by('id_perusahaan');
         $data_area_operasi= $this->db->get('perusahaan_area_operasi')->result_array();

         if (count($data_area_operasi) > 0)
         {
           foreach ($data_area_operasi as $key => $valueAO) {
            $kab[] = $valueAO['id_perusahaan'];
         }
      }else{
         $kab ='x';
      }
   }else{
    $kab ='';
 }

 $nama_perusahaan = $this->input->post('nama_perusahaan');
 $lokasi_kota = $this->input->post('lokasi_kota');
        $lokasi_provinsi = '';//$this->input->post('lokasi_provinsi');
        $pembayaran_cash = $this->input->post('pembayaran_cash');
        $pembayaran_kredit = $this->input->post('pembayaran_kredit');
        $rating = $this->input->post('rating');
        $sortir = $this->input->post('sortir');                   

        $perusahaan = $this->M_user->search_perusahaan($nama_perusahaan, $kab,/* $lokasi_provinsi,*/$pembayaran_cash, $pembayaran_kredit, $rating, $sortir);


        $hasil = $this->load->view('frontend/perusahaan_search', array('perusahaan'=>$perusahaan,'lokasi_kota' => $lokasi_kota,'lokasi_provinsi' => $lokasi_provinsi,'pembayaran_cash' => $pembayaran_cash,'pembayaran_kredit' => $pembayaran_kredit,'rating'=> $rating), true);

        $callback = array(
           'hasil' => $hasil,

        );
        echo json_encode($callback); // konversi varibael $callback menjadi JSON

     }
     function perusahaan_reset_search()
     {
       $nama_perusahaan = $this->input->post('nama_perusahaan');

       $sortir = $this->input->post('sortir');                   

       $perusahaan = $this->M_user->search_reset_perusahaan($nama_perusahaan, $sortir);


       $hasil = $this->load->view('frontend/perusahaan_search', array('perusahaan'=>$perusahaan), true);

       $callback = array(
        'hasil' => $hasil,

     );
        echo json_encode($callback); // konversi varibael $callback menjadi JSON

     }

     function perusahaan_detail($id_perusahaan)
     {
        if (empty($id_perusahaan)) {redirect(base_url().'home/perusahaan');}

          $get_perusahaan = $this->db->get_where('perusahaan', array('id_perusahaan'=>$id_perusahaan, 'status_perusahaan'=>'aktiv'));
          if(count($get_perusahaan->result_array()) < 1){ redirect(base_url().'home/load');}

       $this->session->set_userdata('id_perusahaan_detail', $id_perusahaan);
       $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
       $data['medsos'] = $this->Website->medsosweb();
        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
       $data['banner'] = $this->M_user->tampil_banner($id_perusahaan);
       $data['perusahaan'] = $this->M_user->detail_perusahaan($id_perusahaan);

       $data['produk_terbaru'] = $this->M_user->detail_perusahaan_produk_terbaru($id_perusahaan);

       $data['chat_view'] =  $this->M_user->lihat_chat($id_perusahaan);
       $data['plugin_v']='2';$this->load->view('frontend/header_1',$data);
       $this->load->view('frontend/perusahaan_detail');
       $this->load->view('frontend/perusahaan_beranda');
       $this->load->view('frontend/footer');
    }
    
    function perusahaan_produk()
    {
       $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
       $data['medsos'] = $this->Website->medsosweb();
        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
       $data['perusahaan'] = $this->M_user->detail_perusahaan($this->session->userdata('id_perusahaan_detail'));
       $data['produk'] = $this->M_user->detail_perusahaan_produk($this->session->userdata('id_perusahaan_detail'));
       $data['chat_view'] =  $this->M_user->lihat_chat($this->session->userdata('id_perusahaan_detail'));
       $data['plugin_v']='2';$this->load->view('frontend/header_1',$data);
       $this->load->view('frontend/perusahaan_detail');
       $this->load->view('frontend/perusahaan_produk');
       $this->load->view('frontend/footer');
    }
    
    function perusahaan_produk_sortir()
    {
       $folder_user = $this->input->post('folder_user'); 
       $sortir = $this->input->post('sortir');                   
       $produk = $this->M_user->perusahaan_produk_sortir($this->session->userdata('id_perusahaan_detail'),$sortir);
       $hasil = $this->load->view('frontend/perusahaan_produk_view', array('produk'=>$produk, 'folder_user'=>$folder_user), true);

       $callback = array(
        'hasil' => $hasil,

     );
        echo json_encode($callback); // konversi varibael $callback menjadi JSON
     }
     function perusahaan_pemasang()
     {
       $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
       $data['medsos'] = $this->Website->medsosweb();
        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
       $data['perusahaan'] = $this->M_user->detail_perusahaan($this->session->userdata('id_perusahaan_detail'));
       $data['pemasang'] = $this->M_user->detail_perusahaan_pemasang($this->session->userdata('id_perusahaan_detail'));
       $data['chat_view'] =  $this->M_user->lihat_chat($this->session->userdata('id_perusahaan_detail'));
       $data['plugin_v']='2';$this->load->view('frontend/header_1',$data);
       $this->load->view('frontend/perusahaan_detail');
       $this->load->view('frontend/perusahaan_pemasang');
       $this->load->view('frontend/footer');
    }
    function perusahaan_pemasang_sortir()
    {
       $folder_user = $this->input->post('folder_user'); 
       $sortir = $this->input->post('sortir');                   
       $pemasang = $this->M_user->perusahaan_pemasang_sortir($this->session->userdata('id_perusahaan_detail'),$sortir);
       $hasil = $this->load->view('frontend/perusahaan_pemasang_view', array('pemasang'=>$pemasang, 'folder_user'=>$folder_user), true);

       $callback = array(
        'hasil' => $hasil,

     );
        echo json_encode($callback); // konversi varibael $callback menjadi JSON
     }

     function perusahaan_ulasan()
     {
       $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
       $data['medsos'] = $this->Website->medsosweb();
        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
       $data['perusahaan'] = $this->M_user->detail_perusahaan($this->session->userdata('id_perusahaan_detail'));
       $data['ulasan'] = $this->M_user->detail_perusahaan_produk($this->session->userdata('id_perusahaan_detail'));
       $data['chat_view'] =  $this->M_user->lihat_chat($this->session->userdata('id_perusahaan_detail'));
       $data['plugin_v']='2';$this->load->view('frontend/header_1',$data);
       $this->load->view('frontend/perusahaan_detail');
       $this->load->view('frontend/perusahaan_ulasan');
       $this->load->view('frontend/footer');
    }
    
  //===================================================FITUR PEMASANG
    function pemasang($jenis=null,$lokasi=null)
    {
        //===================harus di pakai semua fungction controller======================
        //  $data['seo'] = $this->home->seo(); //menampilkan meta title, keyword, deskripsi
        $data['lang'] = $this->Website->lang($this->session->userdata('lang')); //menampilkan meta title, keyword, deskripsi
        $data['medsos'] = $this->Website->medsosweb();
        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        if (empty($jenis) && empty($lokasi)) {
            $loc = json_decode(file_get_contents("https://ipinfo.io/".$_SERVER['REMOTE_ADDR']."/json"));
            $data['jenis'] ='auto';
            $data['lokasi'] = $loc->city;
            //$data['lokasi'] =$this->session->userdata('kota');
        }else{
            $data['jenis'] = $jenis;
            $data['lokasi'] = $lokasi;
        }

        $data['cari'] = $this->input->get('cari');
        $data['kabupaten'] = $this->M_user->tampil_kota();
        $data['provinsi'] = $this->M_user->tampil_provinsi();
        $data['pemasang'] = $this->M_user->tampil_pemasang();
        $data['plugin_v']='2';$this->load->view('frontend/header_1',$data);
        $this->load->view('frontend/pemasang');
        $this->load->view('frontend/footer');
     }

     function pemasang_search()
     {
        //============================membuat array id perusahaan dari area operasi===1 
        $areaArray = $this->input->post('lokasi_kota');

        if (!empty($areaArray)) {
            $this->db->select("*");
            $this->db->where_in('area_pemasang', $areaArray);
            $this->db->group_by('id_pemasang');
            $data_area_operasi= $this->db->get('pemasang_area_kerja')->result_array();

            if (count($data_area_operasi) > 0)
            {
                foreach ($data_area_operasi as $key => $valueAO) {
                  $kab[] = $valueAO['id_pemasang'];
                }
            }else{
                $kab ='x';
            }
        }else{
            $kab ='';
        }
        /*
       $areaArray = $this->input->post('lokasi_kota');
       if (!empty($areaArray)) {
         $this->db->select("*");
         $this->db->where_in('kabupaten', $areaArray);
         $this->db->group_by('id_perusahaan');
         $data_area_operasi= $this->db->get('perusahaan_area_operasi')->result_array();

         if (count($data_area_operasi) > 0)
         {
           foreach ($data_area_operasi as $key => $valueAO) {
            $kab[] = $valueAO['id_perusahaan'];
         }
      }else{
         $kab ='x';
      }
   }else{
    $kab ='';
 }*/
 $nama_teknisi = $this->input->post('nama_teknisi');
 $lokasi_kota = $this->input->post('lokasi_kota');
        $lokasi_provinsi = '';//$this->input->post('lokasi_provinsi');
        $keahlian = $this->input->post('keahlian');
        $harga_minimal = $this->input->post('harga_minimal');
        $harga_maximal = $this->input->post('harga_maximal');
        $rating = $this->input->post('rating');
        $sortir = $this->input->post('sortir');

        if (!empty($keahlian)) {
         $this->db->select("*");
         $this->db->where_in('keahlian', $keahlian);
         $this->db->group_by('id_pemasang');
         $dataKeahlian= $this->db->get('pemasang_keahlian')->result_array();
         if (count($dataKeahlian) > 0) {
           foreach ($dataKeahlian as $key => $valueKeahlian) {
             $keahlian_array[] = $valueKeahlian['id_pemasang'];
          }
       }else{
        $keahlian_array='x';
     }

  }else{
   $keahlian_array='';
}

$pemasang = $this->M_user->search_pemasang($nama_teknisi, $kab,/*$lokasi_provinsi,*/$keahlian_array, $harga_minimal, $harga_maximal, $rating, $sortir);

$hasil = $this->load->view('frontend/pemasang_search', array('pemasang'=>$pemasang, 'keahlian' =>$keahlian, 'lokasi_kota' => $lokasi_kota,'lokasi_provinsi' => $lokasi_provinsi,'harga_minimal' =>$harga_minimal,'harga_maximal' =>$harga_maximal,'rating'=> $rating), true);

$callback = array(
  'hasil' => $hasil,
         // Set array hasil dengan isi dari view.php yang diload tadi
);
        echo json_encode($callback); // konversi varibael $callback menjadi JSON

     }

     function pemasang_reset_search()
     {
       $nama_teknisi = $this->input->post('nama_teknisi');
       $sortir = $this->input->post('sortir');

       $pemasang = $this->M_user->search_reset_pemasang($nama_teknisi, $sortir);

       $hasil = $this->load->view('frontend/pemasang_search', array('pemasang'=>$pemasang), true);

       $callback = array(
        'hasil' => $hasil,
         // Set array hasil dengan isi dari view.php yang diload tadi
     );
        echo json_encode($callback); // konversi varibael $callback menjadi JSON

     }

     function pemasang_detail($id_pemasang)
     {

    if (empty($id_pemasang)) {redirect(base_url().'home/pemasang');}

      $get_pemasang = $this->db->get_where('pemasang_view', array('id_pemasang'=>$id_pemasang, 'status_publis_pemasang'=>'true', 'status_hapus_pemasang'=>'false','status_perusahaan'=>'aktiv'));
      $valPemasang=$get_pemasang->row();
      if(count($get_pemasang->result_array()) < 1){ redirect(base_url().'home/load');}

       $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
       $data['medsos'] = $this->Website->medsosweb();
        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
       $data['pemasang'] = $this->M_user->tampil_detail_pemasang($id_pemasang);
       // if(count($data['pemasang']) < 1){ redirect(base_url().'home/pemasang'); }
       $data['keahlian'] = $this->M_user->tampil_keahlian_pemasang($id_pemasang);
       $data['portofolio'] = $this->M_user->tampil_portofolio_pemasang($id_pemasang);
       $data['sertifikat'] = $this->M_user->tampil_sertifikat_pemasang($id_pemasang);
       $data['dataPerusahaan'] = $this->M_user->tampil_dataPerusahaan_pemasang($id_pemasang);
       $data['dataUser'] = $this->M_user->tampil_dataUser_pemasang($data['dataPerusahaan']->id_user);
       $data['ulasan']=  $this->M_user->ulasan_teknisi($id_pemasang);

       $data['plugin_v']='2';$this->load->view('frontend/header_1',$data);
       $this->load->view('frontend/pemasang_detail');
       $this->load->view('frontend/footer');
    }




    function email(){
      $this->load->library('mailer');
      $email_penerima = 'brajamusti570@gmail.com';
      $subjek = 'subjek ok';
      $pesan = 'pesan ok';
           // $attachment = $_FILES['attachment'];
            $content = 'xcxcxcc';//$this->load->view('content', array('pesan'=>$pesan), true); // Ambil isi file content.php dan masukan ke variabel $content
            $sendmail = array(
             'email_penerima'=>$email_penerima,
             'subjek'=>$subjek,
             'content'=>$content
              //'attachment'=>$attachment
          );
            if(empty($attachment['name'])){ // Jika tanpa attachment
              $send = $this->mailer->send($sendmail); // Panggil fungsi send yang ada di librari Mailer
            }else{ // Jika dengan attachment
              $send = $this->mailer->send_with_attachment($sendmail); // Panggil fungsi send_with_attachment yang ada di librari Mailer
           }
           echo "<b>".$send['status']."</b><br />";
           echo $send['message'];
           echo "<br /><a href='".base_url("index.php/email")."'>Kembali ke Form</a>";
        }
        function hapus_lelang()
        {
          echo "<a href='".base_url()."home/clear_lelang'>Bersihkan Data Bidding</a><br>";
          $get_bidding=$this->db->get('bidding')->result_array();
          echo "bidding<hr><br>";
          foreach ($get_bidding as $key => $valueBid) {
            echo $valueBid['nama_bidding'].'<br>';
         }
         echo "area<hr><br>";
         $get_bidding2=$this->db->get('bidding_area')->result_array();
         foreach ($get_bidding2 as $key => $valueBid2) {
            echo $valueBid2['lokasi'].'<br>';
         }
         echo "bukti<hr><br>";
         $get_bidding3=$this->db->get('bidding_bukti')->result_array();
         foreach ($get_bidding3 as $key => $valueBid3) {
            echo $valueBid3['id_bidding'].'<br>';
         }
         echo "pembayaran<hr><br>";
         $get_bidding4=$this->db->get('bidding_pembayaran')->result_array();
         foreach ($get_bidding4 as $key => $valueBid4) {
            echo $valueBid4['bukti'].'<br>';
         }
         echo "Ambil<hr><br>";
         $get_bidding5=$this->db->get('bidding_take')->result_array();
         foreach ($get_bidding5 as $key => $valueBid5) {
            echo $valueBid5['dokumen'].'<br>';
         }
         echo "Transfer<hr><br>";
         $get_bidding6=$this->db->get('bidding_transfer')->result_array();
         foreach ($get_bidding6 as $key => $valueBid6) {
            echo $valueBid6['status_transfer'].'<br>';
         }
      }
      function clear_lelang()
      {
       $this->db->truncate('bidding');   
       $this->db->truncate('bidding_area');
       $this->db->truncate('bidding_bukti');
       $this->db->truncate('bidding_pembayaran');
       $this->db->truncate('bidding_take');
       $this->db->truncate('bidding_transfer');
       redirect(base_url().'home/hapus_lelang');
    }
    function mox()
    {
       $this->load->library('mailer');
     
     $sendmail = array(
      'email_penerima'=>'brajamusti570@gmail.com',
      //'nama_kirim'=>'jae',
      'subjek'=>'E-mail',//$subjek,
      'content'=>'cpbaaaaa oy'
      //'copy'=>'copyright'
                              //'attachment'=>$attachment
                     );
     /*$to='julistiasyafari95@gmail.com';
     $name='joy';
     $subject='coba';
     $body='<p>coba ocba ocba</p>';
     $altBody='copy';*/
     //$send = $this->mailer->sendMail($to, $name, $subject, $body, $altBody);
     $send = $this->mailer->send($sendmail);
     if ($send) {
        echo "sukses";
     }else{
      echo "galala";
     }

  }
   function load()
    {
        $data['lang'] = $this->Website->lang($this->session->userdata('lang'));
        $data['medsos'] = $this->Website->medsosweb();

        $data['plugin_v']='2';$this->load->view('frontend/header',$data);
        $this->load->view('frontend/user/item_notif');
        $this->load->view('frontend/footer');
    }

}
?>